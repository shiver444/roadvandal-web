@echo off
rem Builds the web version and publishes it to GitHub Pages (roadvandal.crithlabs.com)
rem EDIT THE NEXT LINE: put your GitHub username instead of USERNAME
set GHUSER=shiver444

cd /d "%~dp0"
python -m pygbag --disable-sound-format-error --template web.tmpl --build main.py
if errorlevel 1 goto fail
copy /y assets\RubikDirt-Regular.ttf build\web\ >nul
copy /y assets\RubikWetPaint-Regular.ttf build\web\ >nul
copy /y favicon.png build\web\favicon.png >nul
echo roadvandal.crithlabs.com>build\web\CNAME
echo.>build\web\.nojekyll
cd build\web
if exist .git rmdir /s /q .git
git init
git add -A
git commit -m "web build"
git branch -M main
git remote add origin https://github.com/%GHUSER%/roadvandal-web.git
git push -u origin main --force
if errorlevel 1 goto fail
echo.
echo DONE - published. It can take a minute or two to appear.
pause
exit /b 0
:fail
echo.
echo SOMETHING FAILED - read the messages above.
pause
