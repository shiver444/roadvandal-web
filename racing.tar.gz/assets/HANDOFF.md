# ROAD VANDAL - handoff for a new chat (updated 2026-10-25)

Paste or attach this at the start of a new chat. It is everything Claude needs to carry on.

## 1. What this is
Pseudo-3D arcade racer in **pygame** (Road Rash feel, heavy car, a clock that only gives time at checkpoints).
Published in the browser at **https://roadvandal.crithlabs.com** (pygbag build, GitHub Pages).
Owner: Crith Labs. Code is MIT, assets are all rights reserved (softened for third-party music and AI-made audio, see section 8).
Playable level: **Level 1 = HALLO-VANDALISM** (Dead Hollow > Grave Road > Hangman's Hill). PINE ROAD exists but is locked.

## 2. How we work (important)
- The user is on **Windows, PyCharm, project at `D:\racing`** (venv `venv`). Claude works in a Linux cloud copy (`/home/claude/racing/`) and **cannot touch the user's PC**.
- The user is learning: **keep instructions very simple**. They said "simplify!!!!" and "always give me all rebuild commands too!".
- **Delivery rule:** copy changed files to `/mnt/user-data/outputs/u2/`, send each file one by one with SendUserFile (never a zip), and say the target folder: `D:\racing\`, `D:\racing\game\`, `D:\racing\game\levels\`, or `D:\racing\assets\`.
- **Rebuild and publish steps (give every time):**
  1. PyCharm: Commit, then Push (Ctrl+Shift+K) - this is only a code backup.
  2. Terminal in `D:\racing`: `.\deploy.bat` (builds with pygbag and force-pushes to GitHub Pages).
  3. Wait for "DONE - published".
  4. Test in a **private tab** (browsers cache hard, including the tab icon).
  - `deploy.bat` has `set GHUSER=USERNAME` - the user must put their GitHub username back after every replacement of that file.
- Game is 700x500 logical pixels, scaled. Tone/humour of the game: deadpan, CAPITALS, penalty jokes ("POOR KITTY! -10 SEC", "THAT WAS A PERSON! -4 SEC", "ZOMBIES AHEAD - STRIKE 'EM ALL!").

## 3. Files
```
main.py, run.bat, deploy.bat, web.tmpl, favicon.png, settings.json (local settings), IDEAS.txt (cloud only)
game/engine.py      ~5250 lines: road, physics, hazards, HUD, menus, touch controls, radio badge, main loop
game/audio.py       engine loops per car, music + radio STATIONS, sfx, ghost train, volume sliders
game/car_sprite.py  car pixel sprites drawn in code (37x30 art px, mirrored), corpse-wagon lid + swinging leg layer
game/sprites.py, crow_sprite.py, master_sprite.py   other sprites
game/webaudio.py    Web Audio shim for the browser build
game/webtouch.py    browser JS: canvas fit, fullscreen/landscape, backup input queue (RVPOP)
game/levels/        halloween.py (live), level1.py (Pine Road, locked)
assets/             music.ogg (MianN - Never Alone), ftf_labandon.ogg, engine_*.wav, ghost_train.*, sfx/hit_*.wav,
                    Rubik fonts (Dirt, SprayPaint, WetPaint), FreeMonoBold.ttf, LICENSE-ASSETS.txt
tools/botrun.py     headless bot test
```

## 4. Cars (CARS list in engine.py; stats 1-5)
| Car | top | pull | grip | brake | extra |
|---|---|---|---|---|---|
| IMPROZA | 4 | 4 | 4 | 3 | black rally sedan |
| YUGGO 45 | 2 | 3 | 3 | 2 | clock 0.97 |
| ZAPPO | 2 | 5 | 4 | 3 | clock 0.91, tiny EV |
| VALVO | 3 | 2 | 4 | 5 | armor 0.75, clock 0.97, forest-green SUV |
| CORPSE WAGON | 2 | 1 | 2 | 1 | clock 1.05, lid flies off at 24% damage, one leg swings from the casket (separate rotating shin layer) |

`car_clock()` scales start time and checkpoint bonus. `car_mod(stat)=1+(stat-4)*0.04`. Damage table: barrier 30, train 45, coffin/gravestone 24, tomb 22, car 20. At 100% damage top speed is 30% lower (`DAMAGE_SPEED_LOSS`, user is happy with it).
Bot pace (centre driving, seconds): Improza 180.4, Yuggo 196.5, Zappo 185.3, VALVO 191.4, Corpse Wagon 196.7.

## 5. Audio
- Engine sound follows speed in 40 variants; after a hit the revs step back by 0.12 and climb again in 14 frames (no restart). Constants `HOLD_T`, `CRASH_CUT` in audio.py.
- Three volume sliders (MUSIC / ENGINE / EFFECTS) in OPTIONS.
- **Radio:** `audio.STATIONS` = (station, track, file) - DARK.FM = MianN - Never Alone (`music.ogg`), NOISE RADIO = Fuck The Facts - L'abandon (`ftf_labandon.ogg`, lowered 2.3 dB). Key **R** or tap the badge. Names live in `RADIO_NAMES` in engine.py. Badge is a car-radio faceplate, bright for a few seconds after a change, then faint.
- **Loudness rule:** every new track is matched to MianN (-7.8 LUFS) with ffmpeg ebur128 before adding it. Convert to .ogg (libvorbis q3).
- Missing sounds the user wants: `hit_tree.wav`, `hit_sign.wav`.

## 6. Web build notes
- pygbag 0.9.3, custom template `web.tmpl` (loading screen with bar, "TAP TO PLAY", viewport/no-zoom rules, favicon). `deploy.bat` also copies fonts and favicon, writes CNAME and .nojekyll.
- Phone: auto landscape and fullscreen, LOD (`DRAW_DIST=520`, 7 physics steps), tap dedupe (mouse + touch duplicates), QUIT hidden on web, touch buttons incl. a pause pill.
- `window.chromakey` makes near-black canvas pixels transparent: never draw dark text straight on the canvas.
- **OPEN BUG - Mac Safari:** menu shows the animation but all input is ignored (debug line "engine 0 page 0", `BUILD = "input-test 2"` on the main menu, web only). iPhone Safari works. Waiting for the user to run in the Safari console on the Mac: `typeof RVPOP` and `RVPOP()`, and to try Chrome on the Mac. Remove the debug line when fixed.
- Android: optional PWA manifest could remove Chrome's fullscreen notice.

## 7. Open items / ideas
1. **Scoreboard** (next, being designed): see section 9.
2. Mac Safari input bug (above).
3. Audio rights: user has not said which AI tool made `engine_loops.wav`; the other engine/ghost/hit sounds need the same check, then rewrite `LICENSE-ASSETS.txt` with one honest line per audio file. The two music tracks are used with the artists' permission (user says they know the bands).
4. Balance: Zappo x0.91 (47 s left on a good phone run), Yuggo 0.97, VALVO 0.97 (untested), Corpse Wagon 1.05 (untested). Ask for "seconds left" from clean runs.
5. **Ghost radio idea** (see IDEAS.txt): when music is OFF, replace the occasional white-noise bursts with a subliminal voice radio - mostly static with something weird between. User will record the clips; match loudness, respect the effects slider.
6. Corpse wagon gimmick still open (none / lucky corpse / lighter after the crash / friendly zombies). Currently none.
7. More cars; "another thing near the end" the user will remember; hit_tree/hit_sign sounds.
8. News pop-up text for the website: user wants the game's own voice and "why click" feeling (drafts exist in the old chat; e.g. "FOR THREE MINUTES, YOU ARE THE WORST DRIVER IN THE WORLD. HALLOWEEN RACE: ROAD VANDAL. FLOOR IT. PLAY NOW.").
9. Tab icon: skull with a pink mohawk (`favicon.png`, 32x32). If the live site still shows the old icon it is browser cache or the file not published.

## 8. Licence
Crith Labs. Code MIT. Assets all rights reserved, except third-party music (used with permission) and AI-generated audio (to be described honestly in `assets/LICENSE-ASSETS.txt`).

## 9. Scoreboard - design under discussion
Decided so far: leave scores until after launch (done); nicknames up to **10 characters**.
Proposal: rank by **finish time**, show hits, a CLEAN tag for 0 hits, one board per level and car, hosted on **Supabase** (GitHub Pages is static only), only finished runs count, plausibility checks on the server (nothing faster than a sane minimum per car), insert-only rows. Phones have no keyboard in a canvas game, so name entry needs a JS prompt or an arcade-style letter picker.
Still to settle with the user: ranking rule (time only vs time + hit penalty), combined vs per-car boards, name entry method, profanity filter, where the SCORES button lives.

## 10. Testing without the user
Headless: `SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy`. A stub AUDIO object (needs `station = 0`) is used for bot runs; the reference bot run for level 1 finishes at frame 16617 ("level 1 end finish 16617"). Render a frame with `engine.draw(run, keys)` and save `engine.screen` to check HUD layouts. The old test scripts (`stallbot.py`, `carpace.py`, `prof.py`, ...) lived in a temporary folder and are gone in a new chat; `tools/botrun.py` is the permanent one.
