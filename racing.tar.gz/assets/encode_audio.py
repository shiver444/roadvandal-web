"""Road Vandal audio encoder - the one standard for every new sound / radio track (keeps the download small).
usage:  python encode_audio.py KIND input.(mp3|wav|ogg) output_name_without_ext [volume_dB]
KIND    radio  : a full radio song              -> vorbis q3  (~110 kbps)
        uw     : its muffled underwater version -> vorbis q2  (~96 kbps, it is low-passed anyway)
        sfx    : short effects, carols, voices  -> vorbis q5  (~160 kbps; they are small)
Output goes to assets/NAME.ogg. Optional volume_dB is applied before encoding (peak target about -1..-3 dB).
Budget: all of assets/ should stay around 40 MB; a new level should add no more than ~6 MB of audio."""
import subprocess, sys, os
Q = {"radio": "3", "uw": "2", "sfx": "5"}
kind, src, name = sys.argv[1:4]
vol = sys.argv[4] if len(sys.argv) > 4 else "0"
out = os.path.join("assets", name + ".ogg")
cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", src, "-af", "volume=%sdB" % vol, "-c:a", "libvorbis", "-q:a", Q[kind], out]
subprocess.run(cmd, check=True)
print(out, "%.2f MB" % (os.path.getsize(out) / 1048576))
