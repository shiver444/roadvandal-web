@echo off
rem Private web test with pygbag's own server (same template as deploy.bat). Nothing is published.
rem Open http://localhost:8000 and press Ctrl+F5 after every rebuild. Stop with Ctrl+C.
rem (On the loading page your Rubik fonts may be missing here: deploy.bat copies them after the build.)

cd /d "%~dp0"
set PY=python
if exist venv\Scripts\python.exe set PY=venv\Scripts\python.exe
%PY% -m pygbag --disable-sound-format-error --template web.tmpl main.py
pause
