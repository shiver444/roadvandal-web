"""Pixel-art roadside things for the racer: people, workers, cones, barriers, deer, trees.
Everything is drawn from rects in code, so there are no image files to ship.

    surf = sprites.get("worker", frame=1)          # art-pixel Surface (the game scales it)
    sprites.HEIGHT_M["worker"]                      # real-world height in metres
Person frames: 0 stand, 1 legs apart, 2 left foot up, 3 right foot up.
Worker extra frames: 4 / 5 = digging with a shovel.
"""
import math
import pygame

_CACHE = {}

HEIGHT_M = {"worker": 1.8, "ped": 1.75, "cop": 1.75, "medic": 1.75, "kid": 1.15, "smoker": 1.8, "sleeper": 1.4,
            "cone": 0.75, "barrier": 1.0, "deer": 1.4, "boar": 1.1, "piglet": 0.55, "cat": 0.5, "pine": 6.2, "maple": 4.3, "deadtree": 7.0,
            "stranger": 1.9, "druid": 1.85, "ghost": 2.0, "spider": 0.7, "web": 2.4, "witchland": 1.9, "tomb": 1.2, "ghoul": 1.75, "zombie": 1.75, "bat": 0.55, "costume": 1.75, "coffin": 0.7, "pumpkin": 0.55, "gravestone": 1.1}

OUTLINE = (16, 11, 10)
SKINS = [(222, 168, 128), (196, 140, 100), (150, 102, 72), (236, 190, 152)]


class _P:
    def __init__(self, w, h):
        self.s = pygame.Surface((w, h), pygame.SRCALPHA)
        self.w, self.h = w, h

    def px(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.s.set_at((x, y), (*c, 255))

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.px(x, y, c)

    def line(self, x0, y0, x1, y1, c):
        n = max(abs(x1 - x0), abs(y1 - y0), 1)
        for i in range(n + 1):
            self.px(round(x0 + (x1 - x0) * i / n), round(y0 + (y1 - y0) * i / n), c)


def _shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


def _finish(p, outline=True, shade_from=None, k=0.78):
    """right-side shading + 1px dark outline so the sprite reads against any background"""
    s = p.s
    w, h = s.get_size()
    if shade_from is not None:
        for y in range(h):
            for x in range(shade_from, w):
                c = s.get_at((x, y))
                if c[3]:
                    s.set_at((x, y), (*_shade(c[:3], k), 255))
    if not outline:
        return s
    out = pygame.Surface((w + 2, h + 2), pygame.SRCALPHA)
    for y in range(h):
        for x in range(w):
            if s.get_at((x, y))[3]:
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    out.set_at((x + 1 + dx, y + 1 + dy), (*OUTLINE, 255))
    for y in range(h):
        for x in range(w):
            c = s.get_at((x, y))
            if c[3]:
                out.set_at((x + 1, y + 1), c)
    return out


def _person(top=(160, 40, 40), bottom=(40, 50, 90), hair=(50, 34, 24), skin=SKINS[0], frame=0,
            dress=False, long_hair=False, hat=None, backpack=None, worker=False, smoker=False, dig=None, costume=None, uniform=None):
    p = _P(14, 28)
    ox = 0
    # --- legs
    leg = bottom if not (dress and True) else skin
    shoe = (30, 24, 22) if not worker else (150, 110, 50)
    legs = {0: ((4, 6, 25), (7, 9, 25)),
            1: ((3, 5, 25), (8, 10, 25)),
            2: ((4, 6, 24), (7, 9, 25)),
            3: ((4, 6, 25), (7, 9, 24))}[frame % 4]
    top_y = 20 if dress else 15
    for (x0, x1, bot) in legs:
        col = skin if dress else bottom
        p.rect(x0, top_y, x1, bot - 1, col)
        p.rect(x0 - (1 if x0 < 6 else 0), bot, x1 + (0 if x0 < 6 else 1), bot + 1, shoe)
        if worker:
            p.rect(x0, bot - 4, x1, bot - 4, (225, 225, 205))      # reflective ankle band
    # --- skirt / torso
    if dress:
        for i, y in enumerate(range(15, 20)):
            p.rect(3 - (i // 2), y, 10 + (i // 2), y, bottom)
    p.rect(3, 7, 10, 14, top)
    p.rect(3, 14, 10, 14, _shade(top, 0.7))
    # --- arms (swing opposite to legs)
    swing = {0: (0, 0), 1: (0, 0), 2: (1, -1), 3: (-1, 1)}[frame % 4]
    sleeve = top if not worker else (120, 124, 132)
    for side, sw in ((0, swing[0]), (1, swing[1])):
        ax = 1 if side == 0 else 11
        p.rect(ax, 7, ax + 1, 12 + sw, sleeve)
        p.rect(ax, 13 + sw, ax + 1, 14 + sw, skin)
    if worker:
        p.rect(3, 7, 10, 14, (244, 126, 24))                       # hi-vis vest
        p.rect(3, 9, 10, 9, (236, 236, 214))
        p.rect(3, 12, 10, 12, (236, 236, 214))
        p.rect(6, 7, 7, 14, (212, 100, 18))                        # zip
    if uniform == "cop":
        p.rect(3, 7, 10, 14, (38, 84, 168))                         # blue shirt, black belt, yellow badge
        p.rect(3, 7, 4, 8, (60, 110, 196))
        p.rect(3, 13, 10, 13, (20, 20, 26))
        p.rect(8, 9, 9, 10, (236, 200, 60))
        p.rect(6, 7, 7, 8, (230, 232, 238))                         # collar
    elif uniform == "medic":
        p.rect(3, 7, 10, 14, (52, 150, 104))                        # green paramedic jacket with reflective bands and a red cross
        p.rect(3, 10, 10, 10, (238, 236, 120))
        p.rect(3, 13, 10, 13, (238, 236, 120))
        p.rect(4, 8, 5, 9, (236, 236, 236))
        p.rect(4, 8, 5, 8, (210, 40, 36)); p.rect(4, 8, 4, 9, (210, 40, 36))
        p.rect(6, 7, 7, 14, (40, 120, 84))
    if backpack:
        p.rect(11, 8, 12, 13, backpack)
    # --- head
    p.rect(6, 6, 7, 6, skin)
    p.rect(4, 1, 9, 5, skin)
    p.rect(5, 0, 8, 0, hair)
    p.rect(4, 1, 9, 2, hair)
    p.px(4, 3, hair)
    p.px(9, 3, hair)
    if long_hair:
        p.rect(3, 2, 4, 9, hair)
        p.rect(9, 2, 10, 9, hair)
    p.px(5, 3, (24, 18, 16))
    p.px(8, 3, (24, 18, 16))
    p.px(6, 5, _shade(skin, 0.7))
    p.px(7, 5, _shade(skin, 0.7))
    if uniform == "cop":
        p.rect(3, 0, 10, 2, (24, 40, 92))                          # police cap with a badge and a peak
        p.rect(2, 3, 11, 3, (14, 22, 54))
        p.px(6, 1, (236, 200, 60)); p.px(7, 1, (236, 200, 60))
    elif uniform == "medic":
        p.rect(4, 0, 9, 1, (236, 236, 236))                        # white cap
        p.rect(3, 2, 10, 2, (210, 40, 36))
    if hat == "cap":
        p.rect(4, 0, 9, 2, (180, 50, 40))
        p.rect(3, 2, 10, 2, (140, 36, 30))
    if worker:
        p.rect(3, 0, 10, 2, (246, 206, 36))                        # hard hat
        p.rect(4, 0, 9, 0, (255, 232, 110))
        p.rect(2, 3, 11, 3, (214, 170, 24))                        # brim
    if smoker:
        p.rect(1, 7, 2, 8, sleeve)                                  # left arm bent up to the face
        p.rect(1, 4, 2, 6, sleeve)
        p.rect(2, 3, 3, 4, skin)
        p.px(3, 5, (240, 240, 230))
        p.px(4, 5, (240, 240, 230))
        p.px(5, 5, (255, 120, 30))                                  # glowing tip is at the front corner
    if costume == "sheet":                                         # somebody in a bedsheet: a ghost with feet
        sheet, shade = (240, 240, 232), (200, 202, 204)
        p.rect(2, 0, 11, 21, sheet)
        p.rect(10, 0, 11, 21, shade)
        for xx in (2, 11):
            p.s.set_at((xx, 0), (0, 0, 0, 0))
        for xx in range(3, 11, 2):
            p.rect(xx, 21, xx, 22, sheet)
        p.rect(4, 3, 5, 5, (20, 20, 24))
        p.rect(8, 3, 9, 5, (20, 20, 24))
        p.rect(6, 7, 7, 8, (30, 30, 34))
    elif costume == "pumpkin":                                     # pumpkin head on a black suit
        p.rect(3, 0, 10, 6, (238, 128, 18))
        p.rect(2, 1, 11, 5, (238, 128, 18))
        p.rect(9, 0, 10, 6, (190, 90, 10))
        p.px(6, 0, (70, 120, 40))
        p.px(7, 0, (70, 120, 40))
        p.rect(4, 2, 5, 3, (36, 18, 6))
        p.rect(8, 2, 9, 3, (36, 18, 6))
        p.rect(5, 5, 8, 5, (36, 18, 6))
        p.px(6, 5, (238, 128, 18))
    elif costume == "skeleton":                                    # black bodysuit with painted bones
        p.rect(3, 7, 10, 14, (22, 22, 28))
        for yy in (8, 10, 12):
            p.rect(4, yy, 9, yy, (230, 230, 220))
        p.rect(6, 7, 7, 14, (230, 230, 220))
        p.rect(4, 1, 9, 5, (236, 236, 226))
        p.rect(5, 2, 6, 3, (20, 20, 24))
        p.rect(8, 2, 9, 3, (20, 20, 24))
        p.rect(5, 5, 8, 5, (20, 20, 24))
        for xx in (5, 7):
            p.px(xx, 5, (236, 236, 226))
    elif costume == "horde":                                       # the real thing: grey-green, red eyes, arms out, shuffling
        p.rect(0, 6, 1, 10, (96, 132, 76))
        p.rect(12, 6, 13, 10, (96, 132, 76))
        p.rect(4, 0, 9, 1, (110, 110, 100))
        p.px(5, 3, (255, 40, 30))
        p.px(8, 3, (255, 40, 30))
        p.rect(5, 5, 8, 5, (60, 20, 20))
        p.rect(4, 8, 5, 10, (120, 30, 30))                         # torn, bloody shirt
        for xx in (3, 5, 8, 10):
            p.rect(xx, 12, xx, 16, (56, 52, 44))
    elif costume == "zombie":                                      # green, arms out front, shirt in ribbons
        p.rect(0, 6, 1, 10, (118, 156, 88))
        p.rect(12, 6, 13, 10, (118, 156, 88))
        p.rect(4, 0, 9, 1, (150, 150, 140))
        p.px(5, 3, (240, 240, 200))
        p.px(8, 3, (240, 240, 200))
        p.rect(5, 5, 8, 5, (70, 30, 30))
        for xx in (3, 5, 8, 10):
            p.rect(xx, 12, xx, 15, (70, 66, 56))
    if dig is not None:
        off = 0 if dig == 4 else 2
        p.rect(12, 2 + off, 12, 22 + off, (110, 78, 44))            # shovel handle
        p.rect(11, 22 + off, 13, 25 + off, (160, 164, 170))         # blade
    return _finish(p, shade_from=7)


def _kid(**kw):
    s = _person(**kw)
    return pygame.transform.scale(s, (int(s.get_width() * 0.66), int(s.get_height() * 0.66)))


def _cone():
    p = _P(8, 10)
    o = (240, 100, 20)
    p.rect(3, 0, 4, 1, o)
    p.rect(2, 2, 5, 3, o)
    p.rect(2, 3, 5, 3, (240, 240, 228))
    p.rect(2, 4, 5, 4, o)
    p.rect(1, 5, 6, 5, (240, 240, 228))
    p.rect(1, 6, 6, 7, o)
    p.rect(0, 8, 7, 9, (36, 30, 28))
    return _finish(p, shade_from=4, k=0.8)


def _barrier():
    w, h = 26, 11
    p = _P(w, h)
    for y in range(0, 5):
        for x in range(w):
            col = (216, 40, 30) if ((x + y) // 3) % 2 == 0 else (238, 238, 228)
            p.px(x, y, col)
    p.rect(0, 0, w - 1, 0, (150, 24, 18))
    p.rect(0, 4, w - 1, 4, (96, 96, 100))
    for x0 in (3, 21):
        p.rect(x0, 5, x0 + 1, h - 1, (70, 70, 76))
        p.rect(x0 - 1, h - 1, x0 + 2, h - 1, (50, 50, 54))
    return _finish(p)


def _sleeper():
    """worker asleep in an armchair, seen from the side (facing right), hard hat over his eyes"""
    p = _P(20, 17)
    red, dk, lt = (132, 58, 44), (92, 38, 30), (162, 78, 58)
    # armchair: tall back on the left, seat, armrest, legs
    p.rect(1, 1, 4, 11, red)                        # back
    p.rect(1, 1, 1, 11, lt)
    p.rect(1, 10, 11, 12, red)                      # seat cushion
    p.rect(1, 12, 11, 12, dk)
    p.rect(4, 8, 10, 9, dk)                         # armrest
    p.rect(1, 13, 2, 16, (60, 40, 30))              # chair legs
    p.rect(10, 13, 11, 16, (60, 40, 30))
    # man: slumped back, head dropped forward
    p.rect(5, 4, 8, 9, (244, 126, 24))              # vest torso
    p.rect(5, 6, 8, 6, (236, 236, 214))             # reflective band
    p.rect(5, 8, 8, 8, (236, 236, 214))
    p.rect(6, 2, 9, 4, SKINS[1])                    # head tipped forward
    p.rect(8, 3, 9, 4, _shade(SKINS[1], 0.8))       # nose / chin side
    p.rect(5, 0, 10, 2, (246, 206, 36))             # hard hat
    p.rect(9, 2, 12, 2, (214, 170, 24))             # brim pulled down over his face
    p.rect(4, 0, 4, 1, (214, 170, 24))
    p.rect(7, 6, 11, 7, (120, 124, 132))            # arm folded across, grey sleeve
    p.rect(11, 6, 12, 7, SKINS[1])                  # hand
    p.rect(6, 9, 14, 10, (48, 54, 72))              # thigh
    p.rect(13, 10, 15, 14, (48, 54, 72))            # shin
    p.rect(13, 14, 18, 15, (150, 110, 50))          # boot
    p.rect(13, 14, 18, 14, (190, 146, 70))
    return _finish(p, shade_from=9)


def _deer(frame):
    """facing right, 22 x 16. frame 0/1 gallop, 2 standing"""
    p = _P(22, 16)
    n, d, l, t = (158, 104, 58), (100, 62, 34), (222, 196, 156), (214, 200, 164)
    p.rect(4, 6, 15, 10, n)
    p.rect(4, 10, 15, 10, l)
    p.rect(2, 6, 4, 8, d)
    p.rect(14, 3, 17, 7, n)
    p.rect(16, 2, 20, 5, n)
    p.rect(20, 3, 21, 4, d)
    p.rect(17, 0, 17, 2, t)
    p.rect(19, 0, 19, 2, t)
    p.px(16, 0, t)
    p.px(20, 0, t)
    p.px(17, 4, (20, 14, 10))
    if frame == 2:
        for x in (5, 7, 13, 15):
            p.rect(x, 11, x, 15, d)
    elif frame == 0:
        p.rect(4, 11, 4, 13, d); p.rect(2, 13, 3, 15, d)
        p.rect(7, 11, 7, 15, d)
        p.rect(13, 11, 13, 15, d)
        p.rect(16, 11, 17, 13, d); p.rect(18, 13, 19, 14, d)
    else:
        p.rect(6, 11, 6, 14, d); p.rect(7, 14, 8, 15, d)
        p.rect(8, 11, 8, 15, d)
        p.rect(12, 11, 12, 15, d)
        p.rect(14, 11, 14, 14, d); p.rect(15, 14, 16, 15, d)
    return _finish(p, outline=True)


def _boar(frame, small=False):
    """a wild boar facing right, 28 x 16 (piglet: 13 x 8, striped). frame 0/1 trot, 2 standing"""
    if small:
        p = _P(13, 8)
        b, d, l = (176, 128, 84), (112, 76, 46), (232, 200, 150)
        p.rect(2, 2, 9, 5, b)
        p.rect(2, 2, 9, 2, d)
        p.rect(3, 3, 8, 3, l) if False else None
        p.rect(4, 2, 4, 5, l)
        p.rect(8, 2, 11, 5, b)
        p.rect(11, 3, 12, 4, (214, 150, 140))
        p.px(10, 2, (20, 14, 10))
        p.px(9, 1, d)
        p.px(1, 3, (214, 150, 140))
        if frame == 2:
            for x in (3, 5, 8, 9):
                p.rect(x, 6, x, 7, d)
        elif frame == 0:
            p.rect(3, 6, 3, 7, d); p.rect(5, 6, 6, 7, d); p.rect(8, 6, 8, 7, d); p.rect(10, 6, 11, 7, d)
        else:
            p.rect(2, 6, 3, 7, d); p.rect(5, 6, 5, 7, d); p.rect(8, 6, 9, 7, d); p.rect(10, 6, 10, 7, d)
        return _finish(p, outline=True)
    p = _P(28, 16)
    f, d, l, br = (84, 66, 58), (52, 40, 36), (120, 98, 84), (150, 122, 104)
    p.rect(3, 4, 20, 10, f)                         # heavy body, high shoulders
    p.rect(8, 2, 20, 4, f)
    for x in range(8, 21, 2):                       # bristly mane along the back
        p.px(x, 1, d)
        p.px(x + 1, 2, d)
    p.rect(3, 9, 20, 10, d)
    p.rect(5, 5, 14, 6, l)
    p.rect(19, 4, 25, 10, f)                        # head
    p.rect(24, 6, 27, 9, br)                        # snout
    p.px(27, 7, (30, 20, 20)); p.px(27, 8, (30, 20, 20))
    p.px(23, 5, (230, 210, 120))                    # eye
    p.px(24, 10, (236, 230, 210)); p.px(25, 10, (236, 230, 210)); p.px(25, 9, (236, 230, 210))    # tusk
    p.rect(19, 2, 21, 4, d)                         # ear
    p.rect(1, 5, 3, 6, d); p.px(0, 7, d)            # tail
    if frame == 2:
        for x in (5, 8, 16, 19):
            p.rect(x, 11, x + 1, 15, d)
    elif frame == 0:
        p.rect(4, 11, 5, 13, d); p.rect(3, 13, 4, 15, d)
        p.rect(8, 11, 9, 15, d)
        p.rect(15, 11, 16, 15, d)
        p.rect(19, 11, 20, 13, d); p.rect(20, 13, 21, 14, d)
    else:
        p.rect(6, 11, 7, 14, d); p.rect(7, 14, 8, 15, d)
        p.rect(9, 11, 10, 15, d)
        p.rect(14, 11, 15, 15, d)
        p.rect(17, 11, 18, 14, d); p.rect(18, 14, 19, 15, d)
    return _finish(p, outline=True)


def _cat(frame):
    """facing right, 16 x 10. frame 0 stretched sprint, 1 bunched sprint, 2 sitting"""
    p = _P(16, 10)
    f, d, l = (46, 44, 52), (26, 24, 30), (226, 222, 214)       # black-and-white cat
    if frame == 2:
        p.rect(4, 3, 9, 8, f); p.rect(8, 1, 11, 4, f); p.rect(8, 0, 8, 0, f); p.rect(11, 0, 11, 0, f)
        p.rect(9, 2, 9, 2, (230, 220, 80)); p.rect(10, 5, 10, 8, l); p.rect(1, 7, 4, 7, d)
        p.rect(4, 8, 10, 9, d)
        return _finish(p, outline=True)
    if frame == 0:
        p.rect(3, 3, 11, 5, f); p.rect(11, 2, 14, 5, f); p.rect(11, 1, 11, 1, f); p.rect(14, 1, 14, 1, f)
        p.px(13, 3, (230, 220, 80)); p.rect(12, 5, 14, 5, l)
        p.rect(0, 2, 2, 3, d); p.rect(0, 1, 0, 2, d)                     # tail streaming back
        p.rect(0, 6, 2, 6, f); p.rect(12, 6, 15, 6, f)                  # legs fully stretched
        p.rect(3, 6, 3, 6, d); p.rect(10, 6, 10, 6, d)
    else:
        p.rect(3, 2, 10, 5, f); p.rect(10, 1, 13, 4, f); p.rect(10, 0, 10, 0, f); p.rect(13, 0, 13, 0, f)
        p.px(12, 2, (230, 220, 80)); p.rect(11, 4, 13, 4, l)
        p.rect(0, 1, 2, 2, d); p.rect(0, 0, 0, 1, d)
        p.rect(3, 6, 5, 8, f); p.rect(8, 6, 11, 8, f)                    # legs tucked under
        p.rect(2, 8, 3, 8, d); p.rect(11, 8, 12, 8, d)
    return _finish(p, outline=True)


_MAPLE_COLS = (((250, 170, 56), (226, 118, 34), (178, 64, 28), (116, 38, 26)),      # orange
               ((240, 196, 70), (214, 148, 36), (166, 90, 28), (108, 56, 24)),        # yellow
               ((226, 90, 48), (188, 54, 34), (138, 36, 30), (92, 26, 28)),           # red
               ((236, 150, 52), (204, 96, 30), (154, 56, 28), (104, 36, 26)))         # rust


def _maple(variant=0):
    """autumn tree, 64 x 68, drawn like a game-art tree: round crown of overlapping scalloped leaf clusters, each with a dark rim,
    bright top-left, a flared plum-coloured trunk with branches reaching into the crown"""
    import random as _r
    rr = _r.Random(variant * 31 + 7)
    W_, H_ = 64, 68
    p = _P(W_, H_)
    c1, c2, c3, c4 = _MAPLE_COLS[variant % 4]
    rim = _shade(c4, 0.7)
    bark, bark_l, bark_d = (122, 52, 66), (166, 84, 92), (76, 32, 48)
    # trunk, flared at the foot
    for y in range(40, H_):
        f = (y - 40) / float(H_ - 41)
        hw = 3 + int(f * f * 5)
        for x in range(32 - hw, 32 + hw + 1):
            c = bark_l if x < 32 - hw * 0.4 else (bark_d if x > 32 + hw * 0.4 else bark)
            if (x * 3 + y * 5) % 13 == 0 and c != bark_l:
                c = bark_d
            p.px(x, y, c)
    for (x1, y1) in ((16, 34), (48, 33), (32, 24), (23, 26), (41, 26)):
        p.line(32, 46, x1, y1, bark)
        p.line(33, 46, x1 + 1, y1, bark_d)
    # leaf clusters (cx, cy, r), drawn back to front so each one overlaps the one behind it
    cl = [(32, 15, 10), (18, 20, 10), (46, 20, 10), (10, 30, 8), (54, 30, 8), (25, 25, 11), (40, 25, 11),
          (32, 31, 11), (17, 36, 8), (47, 36, 8), (30, 40, 7), (38, 38, 7)]
    cl = [(x + rr.randint(-1, 1), y + rr.randint(-1, 1), r) for x, y, r in cl]
    cl.sort(key=lambda t: t[1])
    for (bx, by, r) in cl:
        for y in range(by - r - 2, by + r + 3):
            for x in range(bx - r - 2, bx + r + 3):
                if not (0 <= x < W_ and 0 <= y < H_):
                    continue
                ang = math.atan2(y - by, x - bx)
                lim = r * (1.0 + 0.16 * math.sin(ang * 6 + bx * 0.7) + 0.07 * math.sin(ang * 11 + by))
                d = math.hypot(x - bx, y - by)
                if d > lim:
                    continue
                f = ((x - bx) * -0.55 + (y - by) * -0.8) / max(1.0, r)
                if d > lim - 1.2:
                    c = rim if f < 0.2 else c4
                elif f > 0.55:
                    c = c1
                elif f > 0.05:
                    c = c2
                elif f > -0.5:
                    c = c3
                else:
                    c = c4
                h = (x * 7 + y * 5 + variant * 3) % 8
                if h == 0 and f > -0.3 and d < lim - 2:
                    c = c1 if c != c4 else c
                elif h == 3 and f < 0.3 and d < lim - 2 and c != c1:
                    c = c3 if c in (c2, c3) else c
                p.px(x, y, c)
    return _finish(p, outline=False)


def _pine(variant=0):
    """layered conifer, 26 x 44. light on the left, shadow on the right, dark under every tier"""
    p = _P(26, 44)
    cx = 13
    lite, mid, dark, under = (66, 120, 52), (44, 92, 40), (26, 62, 30), (14, 36, 20)
    tiers = [(2, 10, 5), (9, 17, 8), (17, 25, 10), (25, 34, 12)]    # (top y, bottom y, max half-width)
    for ti, (y0, y1, hw) in enumerate(tiers):
        for y in range(y0, y1 + 1):
            f = (y - y0) / max(1, (y1 - y0))
            half = max(1, int(hw * (0.25 + 0.75 * f)))
            # ragged edge
            jag = ((y * 7 + ti * 3 + variant) % 3) - 1
            for x in range(cx - half - (1 if jag > 0 else 0), cx + half + (1 if jag < 0 else 0) + 1):
                c = lite if x < cx - half * 0.3 else (mid if x < cx + half * 0.35 else dark)
                if y >= y1 - 1:
                    c = under if x > cx - half * 0.6 else dark
                p.px(x, y, c)
    p.rect(cx - 1, 35, cx + 1, 43, (74, 46, 24))                   # trunk
    p.rect(cx + 1, 35, cx + 1, 43, (48, 30, 16))
    p.rect(cx - 3, 43, cx + 3, 43, (30, 20, 12))
    return _finish(p, outline=False)


def _deadtree():
    p = _P(24, 40)
    col, lit = (66, 46, 32), (96, 70, 48)
    p.rect(11, 14, 13, 39, col)
    p.rect(11, 14, 11, 39, lit)
    p.rect(9, 37, 15, 39, col)
    for (x0, y0, x1, y1) in ((11, 26, 4, 17), (4, 17, 2, 10), (4, 17, 7, 12), (13, 20, 20, 12), (20, 12, 22, 6),
                              (20, 12, 17, 8), (12, 14, 9, 5), (9, 5, 7, 1), (9, 5, 12, 2), (12, 32, 7, 27)):
        p.line(x0, y0, x1, y1, col)
        p.px(x0, y0 - 1, lit)
    return _finish(p, outline=False)


def _disc(p, cx, cy, r, c):
    for y in range(cy - r, cy + r + 1):
        for x in range(cx - r, cx + r + 1):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + r * 0.6:
                p.px(x, y, c)


def _wheel(p, cx, cy, r, frame, arch=True):
    if arch:
        _disc(p, cx, cy - 1, r + 1, (22, 18, 16))
    _disc(p, cx, cy, r, (14, 14, 16))
    _disc(p, cx, cy, max(1, r - 2), (150, 150, 156))
    k = 1 if frame else -1
    p.px(cx + k, cy, (70, 70, 76))
    p.px(cx, cy + k, (70, 70, 76))


def _fill_poly(p, pts, base, lt, dk, bands=(0.16, 0.62)):
    """fill a polygon with a stepped vertical gradient (light top, mid body, dark underside): pixel-art shading"""
    m = pygame.Surface((p.w, p.h), pygame.SRCALPHA)
    pygame.draw.polygon(m, (255, 255, 255, 255), pts)
    ys = [q[1] for q in pts]
    y0, y1 = min(ys), max(ys)
    for y in range(p.h):
        f = (y - y0) / max(1.0, y1 - y0)
        col = lt if f < bands[0] else (base if f < bands[1] else dk)
        for x in range(p.w):
            if m.get_at((x, y))[3]:
                p.px(x, y, col)


def _poly(p, pts, col):
    m = pygame.Surface((p.w, p.h), pygame.SRCALPHA)
    pygame.draw.polygon(m, (*col, 255), pts)
    for y in range(p.h):
        for x in range(p.w):
            if m.get_at((x, y))[3]:
                p.px(x, y, col)


def _wheel2(p, cx, cy, r, frame):
    _disc(p, cx, cy - 1, r + 2, (18, 16, 16))                          # the dark wheel arch
    _disc(p, cx, cy, r, (22, 22, 24))                                    # tyre
    _disc(p, cx, cy, max(2, r - 3), (172, 176, 184))                     # rim
    _disc(p, cx, cy, max(1, r - 5), (110, 114, 122))
    k = frame * 0.5
    for i in range(5):                                                   # spokes, turning
        an = k + i * 1.2566
        p.line(cx, cy, cx + round(math.cos(an) * (r - 3)), cy + round(math.sin(an) * (r - 3)), (70, 72, 80))
    p.px(cx, cy, (210, 212, 220))


def _driver(p, x, y, shirt):
    _disc(p, x, y, 3, (206, 150, 118))
    p.rect(x - 3, y - 3, x + 1, y - 2, (44, 30, 24))                    # hair
    p.rect(x - 3, y + 3, x + 3, y + 6, shirt)                            # shoulders
    p.px(x + 2, y, (30, 20, 16))                                          # eye


def _side_car(kind, color, frame=0):
    """a car seen from the side, facing right (flip it for the other way): the cars that cross the road at a junction.
    larger, shaded pixel art: highlight band, door seams, stripe, driver, spoked wheels in dark arches"""
    c = tuple(color)
    lt, dk = _shade(c, 1.22), _shade(c, 0.62)
    light_body = sum(c) > 560
    accent = (206, 46, 40) if light_body else (232, 232, 226)
    glass, glass_l = (36, 50, 64), (120, 150, 170)
    red, lamp = (214, 30, 22), (255, 236, 160)
    bump, bump_l = (60, 60, 66), (150, 152, 158)
    wf = frame * 2
    if kind == "sedan":
        p = _P(106, 34)
        _fill_poly(p, [(3, 25), (2, 16), (6, 13), (28, 12), (38, 4), (70, 4), (82, 12), (99, 14), (104, 18), (104, 25)], c, lt, dk)
        p.rect(3, 24, 103, 25, _shade(c, 0.5))                           # sill
        _poly(p, [(40, 6), (54, 6), (54, 12), (35, 12)], glass)
        _poly(p, [(57, 6), (69, 6), (79, 12), (57, 12)], glass)
        p.line(42, 7, 47, 11, glass_l); p.line(59, 7, 63, 11, glass_l)
        _driver(p, 64, 8, (190, 60, 52))
        for x in (36, 55, 80):                                            # door seams
            p.line(x, 13, x, 24, dk)
        p.rect(48, 16, 52, 16, lt); p.rect(68, 16, 72, 16, lt)           # handles
        p.rect(8, 18, 98, 19, accent)                                     # the stripe
        for x in range(8, 98, 6):
            p.px(x, 18, _shade(accent, 0.8))
        p.rect(0, 20, 4, 25, bump); p.rect(102, 20, 105, 25, bump_l)
        p.rect(2, 15, 4, 18, red); p.rect(101, 16, 104, 19, lamp)
        p.rect(82, 11, 85, 13, dk)                                        # mirror
        _wheel2(p, 22, 26, 7, wf)
        _wheel2(p, 85, 26, 7, wf)
    elif kind == "van":
        p = _P(112, 40)
        _fill_poly(p, [(3, 33), (2, 6), (6, 3), (80, 3), (96, 14), (108, 20), (110, 33)], c, lt, dk)
        p.rect(3, 32, 109, 33, _shade(c, 0.5))
        _poly(p, [(84, 6), (88, 6), (97, 15), (84, 15)], glass)
        _poly(p, [(66, 7), (82, 7), (82, 15), (66, 15)], glass)
        p.line(68, 8, 72, 14, glass_l); p.line(86, 8, 90, 13, glass_l)
        _driver(p, 76, 9, (60, 100, 170))
        _poly(p, [(10, 7), (30, 7), (30, 15), (10, 15)], glass)
        _poly(p, [(34, 7), (56, 7), (56, 15), (34, 15)], glass)
        for x in (32, 58, 82):
            p.line(x, 4, x, 31, dk)
        p.rect(8, 24, 104, 25, accent)
        p.rect(0, 28, 4, 33, bump); p.rect(108, 28, 111, 33, bump_l)
        p.rect(2, 20, 4, 25, red); p.rect(108, 22, 111, 25, lamp)
        _wheel2(p, 24, 34, 7, wf)
        _wheel2(p, 90, 34, 7, wf)
    elif kind == "truck":
        p = _P(140, 52)
        box = (232, 232, 224)
        _fill_poly(p, [(2, 2), (88, 2), (88, 38), (2, 38)], box, (252, 252, 248), (170, 172, 168), (0.1, 0.7))
        for x in (30, 60):
            p.line(x, 4, x, 36, (196, 196, 190))
        p.rect(8, 16, 82, 20, accent if not light_body else (206, 46, 40))
        p.rect(14, 10, 40, 12, _shade(c, 0.9))                           # lettering
        _fill_poly(p, [(90, 14), (112, 14), (128, 26), (136, 30), (136, 42), (90, 42)], c, lt, dk)
        _poly(p, [(94, 17), (110, 17), (122, 27), (94, 27)], glass)
        p.line(97, 18, 101, 25, glass_l)
        _driver(p, 100, 20, (80, 120, 70))
        p.line(92, 28, 92, 41, dk)
        p.rect(2, 38, 134, 41, (46, 46, 52))                            # chassis
        p.rect(0, 30, 3, 40, red); p.rect(134, 33, 137, 36, lamp)
        p.rect(133, 38, 138, 43, bump_l)
        _wheel2(p, 14, 43, 8, wf); _wheel2(p, 34, 43, 8, wf); _wheel2(p, 112, 43, 8, wf)
    else:                                                                  # tractor, 92 x 52
        green, gdk, glt = (64, 132, 70), (36, 88, 46), (104, 170, 96)
        p = _P(92, 52)
        _fill_poly(p, [(34, 24), (82, 26), (86, 36), (34, 36)], green, glt, gdk)             # bonnet
        p.rect(80, 28, 86, 34, (44, 44, 48))                                                  # grille
        _fill_poly(p, [(6, 6), (34, 6), (36, 36), (6, 36)], green, glt, gdk)                  # cab
        p.rect(4, 2, 36, 5, gdk)                                                              # roof
        _poly(p, [(9, 8), (31, 8), (32, 22), (9, 22)], glass)
        p.line(11, 9, 17, 20, glass_l)
        _driver(p, 20, 14, (200, 150, 40))
        p.rect(60, 12, 62, 24, (60, 60, 64))                                                  # exhaust
        p.rect(84, 30, 87, 33, lamp)
        _disc(p, 18, 38, 13, (20, 20, 22)); _disc(p, 18, 38, 8, (206, 62, 42)); _disc(p, 18, 38, 3, (70, 40, 30))
        for i in range(6):
            an = wf * 0.4 + i * 1.047
            p.line(18, 38, 18 + round(math.cos(an) * 12), 38 + round(math.sin(an) * 12), (30, 30, 34))
        _disc(p, 68, 44, 7, (20, 20, 22)); _disc(p, 68, 44, 4, (206, 62, 42))
        p.rect(30, 40, 62, 42, (60, 60, 66))
    return _finish(p)


def _traffic_car(kind, color):
    """other cars on the road, seen from behind. kind: sedan / van / truck"""
    c = tuple(color)
    dk, lt = _shade(c, 0.62), _shade(c, 1.25)
    glass = (24, 30, 40)
    red = (214, 30, 22)
    if kind == "bike":                               # motorbike seen from behind: rider hunched over, helmet, one fat rear tyre
        p = _P(9, 16)
        p.rect(3, 0, 5, 2, lt)                       # helmet
        p.rect(3, 2, 5, 2, (30, 30, 36))             # visor strip (seen from behind: dark neck)
        p.rect(1, 3, 7, 8, (36, 36, 44))             # leather jacket / shoulders
        p.rect(2, 3, 6, 4, _shade((36, 36, 44), 1.6))
        p.rect(0, 4, 1, 7, (30, 30, 36))             # elbows
        p.rect(7, 4, 8, 7, (30, 30, 36))
        p.rect(2, 9, 6, 10, c)                       # tail cowl in the bike colour
        p.rect(4, 9, 4, 9, red)                      # tail light
        p.rect(3, 11, 5, 15, (14, 14, 16))           # rear tyre
        p.rect(4, 11, 4, 12, (60, 60, 66))
        return _finish(p)
    if kind == "cyclist":                            # cyclist from behind: hi-vis top, helmet, thin wheel
        p = _P(8, 17)
        p.rect(2, 0, 5, 2, lt)                       # helmet
        p.rect(3, 3, 4, 3, (200, 150, 110))          # neck
        p.rect(1, 4, 6, 9, c)                        # jersey
        p.rect(1, 4, 6, 4, lt)
        p.rect(0, 5, 0, 8, (200, 150, 110))          # arms
        p.rect(7, 5, 7, 8, (200, 150, 110))
        p.rect(2, 10, 3, 13, (40, 44, 60))           # legs
        p.rect(4, 10, 5, 13, (40, 44, 60))
        p.rect(3, 9, 4, 10, (24, 24, 28))            # saddle
        p.rect(3, 11, 4, 16, (14, 14, 16))           # rear wheel
        p.px(3, 12, red)                             # reflector
        return _finish(p)
    if kind == "log":                                # one fallen log lying across the lane, bark and a pale cut end
        p = _P(22, 7)
        bark, bd, bl = (96, 62, 36), (62, 40, 24), (132, 92, 56)
        p.rect(1, 1, 20, 5, bark)
        p.rect(2, 0, 19, 0, bl)
        p.rect(1, 1, 20, 1, bl)
        p.rect(2, 6, 19, 6, bd)
        p.rect(1, 5, 20, 5, bd)
        for x in (4, 8, 13, 17):                     # ridges of bark
            p.rect(x, 2, x, 4, bd)
        p.rect(0, 1, 1, 5, (206, 164, 102))          # the cut end, with a ring
        p.px(0, 3, (150, 108, 62))
        return _finish(p)
    p = _P(22, 17)
    if kind == "logtruck":                           # a logging truck from behind: a stack of round log ends on a flatbed, chained down
        bark, ring, pale = (92, 60, 34), (150, 108, 62), (206, 164, 102)
        p.rect(2, 12, 19, 12, (50, 50, 56))          # flatbed
        p.rect(1, 3, 2, 12, (60, 60, 66))            # stakes
        p.rect(19, 3, 20, 12, (60, 60, 66))
        for row, (y, xs) in enumerate(((10, (4, 8, 12, 16)), (6, (6, 10, 14)), (2, (8, 12)))):
            for x in xs:
                _disc(p, x + 1, y, 2, bark)
                _disc(p, x + 1, y, 1, pale)
                p.px(x + 1, y, ring)
        p.rect(2, 8, 19, 8, (150, 150, 156))         # chain
        p.rect(2, 13, 4, 14, red)                    # tail lights
        p.rect(17, 13, 19, 14, red)
        p.rect(9, 13, 12, 14, (226, 226, 210))       # plate
    if kind == "sedan":
        p.rect(5, 0, 16, 5, c)                       # roof
        p.rect(6, 1, 15, 4, glass)                   # rear window
        p.rect(7, 1, 9, 1, (80, 100, 120))
        p.rect(2, 6, 19, 10, c)                      # boot / body
        p.rect(2, 6, 19, 6, lt)
        p.rect(2, 7, 5, 9, red)                      # tail lights
        p.rect(16, 7, 19, 9, red)
        p.rect(9, 8, 12, 9, (226, 226, 210))         # plate
        p.rect(2, 10, 19, 11, dk)                    # bumper
    elif kind == "hearse":
        blk, chrome = (26, 26, 32), (190, 192, 200)
        p.rect(2, 0, 19, 11, blk)                    # long black body
        p.rect(2, 0, 19, 1, (60, 60, 70))
        p.rect(4, 2, 17, 6, (200, 196, 180))         # curtained rear window
        p.rect(6, 3, 15, 6, (96, 62, 36))            # the coffin inside
        p.rect(6, 3, 15, 3, (130, 86, 50))
        p.rect(10, 2, 11, 6, (214, 178, 70))
        p.rect(2, 8, 4, 10, red)
        p.rect(17, 8, 19, 10, red)
        p.rect(8, 9, 13, 10, (226, 226, 210))
        p.rect(2, 11, 19, 11, chrome)
    elif kind == "van":
        p.rect(2, 0, 19, 11, c)                      # tall box body
        p.rect(2, 0, 19, 1, lt)
        p.rect(5, 2, 16, 5, glass)                   # rear window
        p.rect(10, 6, 11, 11, dk)                    # door split
        p.rect(2, 8, 4, 10, red)
        p.rect(17, 8, 19, 10, red)
        p.rect(8, 9, 13, 10, (226, 226, 210))
        p.rect(2, 11, 19, 11, dk)
    elif kind == "truck":                            # truck: big grey box on the back
        box = (196, 198, 200)
        p.rect(0, 0, 21, 10, box)
        p.rect(0, 0, 21, 0, (232, 234, 236))
        p.rect(10, 1, 11, 10, (150, 152, 156))       # doors
        p.rect(0, 3, 21, 3, (170, 172, 176))
        p.rect(0, 7, 21, 7, (170, 172, 176))
        p.rect(0, 11, 21, 12, (60, 60, 64))          # chassis
        p.rect(1, 9, 3, 10, red)
        p.rect(18, 9, 20, 10, red)
        p.rect(8, 11, 13, 12, (226, 226, 210))
    # tyres
    ty = 11 if kind not in ("truck", "logtruck") else 13
    p.rect(1, ty, 3, ty + 4, (14, 14, 16))
    p.rect(18, ty, 20, ty + 4, (14, 14, 16))
    return _finish(p, shade_from=11)


def _bat(frame):
    """a bat from the front: wings up or down"""
    p = _P(16, 9)
    b, d = (30, 26, 40), (14, 12, 20)
    p.rect(6, 3, 9, 7, b)
    p.px(6, 2, d); p.px(9, 2, d)                                   # ears
    p.px(7, 4, (255, 70, 60)); p.px(8, 4, (255, 70, 60))           # eyes
    p.px(7, 6, (230, 230, 220)); p.px(8, 6, (230, 230, 220))       # fangs
    if frame == 0:                                                 # wings up
        for i in range(6):
            p.rect(5 - i, 3 - i // 2, 5 - i, 6 - i // 3, b)
            p.rect(10 + i, 3 - i // 2, 10 + i, 6 - i // 3, b)
        p.rect(0, 5, 1, 7, d); p.rect(14, 5, 15, 7, d)
    else:                                                          # wings down
        for i in range(6):
            p.rect(5 - i, 4 + i // 2, 5 - i, 6 + i // 2, b)
            p.rect(10 + i, 4 + i // 2, 10 + i, 6 + i // 2, b)
    return _finish(p)


def _spider(frame):
    """a fat black spider seen from the front, legs twitching"""
    p = _P(18, 14)
    b, d = (22, 20, 28), (60, 56, 70)
    p.rect(6, 5, 11, 11, b)
    p.rect(7, 3, 10, 5, b)                                          # head
    p.px(7, 4, (255, 60, 50)); p.px(10, 4, (255, 60, 50))           # eyes
    p.px(8, 4, (255, 60, 50)); p.px(9, 4, (255, 60, 50))
    p.px(8, 9, (200, 30, 30)); p.px(9, 9, (200, 30, 30)); p.px(8, 10, (200, 30, 30)); p.px(9, 10, (200, 30, 30))   # red hourglass
    for k in range(4):
        up = (k + frame) % 2
        y0 = 4 + k * 2
        p.line(5, y0, 2 - up, y0 - 2 + up * 2, b); p.line(2 - up, y0 - 2 + up * 2, 0, y0 + 2 + up, b)
        p.line(12, y0, 15 + up, y0 - 2 + up * 2, b); p.line(15 + up, y0 - 2 + up * 2, 17, y0 + 2 + up, b)
    return _finish(p)


def _ghost(frame):
    """a sheet ghost with a wavy hem; drawn translucent in the game"""
    p = _P(16, 22)
    white, shade = (240, 244, 252), (190, 202, 224)
    for y in range(0, 17):
        if y == 0:
            x0, x1 = 5, 10
        elif y == 1:
            x0, x1 = 4, 11
        elif y == 2:
            x0, x1 = 3, 12
        else:
            x0, x1 = 2, 13
        p.rect(x0, y, x1, y, white)
        p.rect(x1 - 2, y, x1, y, shade)
    p.rect(0, 8, 1, 10, white)                                     # arms
    p.rect(14, 8, 15, 10, white)
    p.rect(0, 10, 1, 11, shade)
    for i, x in enumerate(range(2, 14, 2)):                       # hem ripples
        h = 4 if (i + frame) % 2 == 0 else 2
        p.rect(x, 17, x + 1, 17 + h, white if (i + frame) % 2 == 0 else shade)
    p.rect(4, 4, 5, 7, (16, 14, 26))                               # eyes
    p.rect(9, 4, 10, 7, (16, 14, 26))
    p.rect(6, 9, 8, 12, (16, 14, 26))                              # howling mouth
    return _finish(p, outline=False)


def _coffin():
    """a coffin lying along the road, seen from behind and above"""
    p = _P(14, 12)
    wood, lid, dk = (92, 58, 34), (128, 82, 46), (54, 32, 18)
    for y in range(12):
        half = 2 + (y * 4) // 11
        p.rect(7 - half, y, 6 + half, y, wood)
        p.rect(8 - half, y, 5 + half, y, lid)
        p.px(7 - half, y, dk)
        p.px(6 + half, y, dk)
    p.rect(3, 11, 10, 11, dk)
    p.rect(6, 3, 7, 9, (214, 178, 70))                              # gilt cross
    p.rect(4, 5, 9, 6, (214, 178, 70))
    return _finish(p)


def _pumpkin():
    p = _P(10, 9)
    o, d = (240, 130, 20), (178, 84, 10)
    p.rect(1, 2, 8, 7, o)
    p.rect(2, 1, 7, 8, o)
    p.rect(0, 3, 0, 6, d)
    p.rect(9, 3, 9, 6, d)
    p.rect(4, 2, 4, 7, d)
    p.rect(8, 2, 8, 7, d)
    p.rect(4, 0, 5, 1, (70, 120, 40))
    p.rect(2, 3, 3, 4, (255, 224, 80))                              # lit face
    p.rect(6, 3, 7, 4, (255, 224, 80))
    p.rect(2, 6, 7, 6, (255, 224, 80))
    p.px(3, 6, o)
    p.px(6, 6, o)
    return _finish(p)


def _gravestone(variant):
    p = _P(10, 13)
    st, lt, dk = (136, 140, 148), (170, 174, 180), (84, 88, 96)
    if variant == 0:                                                # rounded slab
        p.rect(1, 3, 8, 12, st)
        p.rect(2, 1, 7, 2, st)
        p.rect(3, 0, 6, 0, st)
        p.rect(1, 3, 2, 12, lt)
        p.rect(7, 3, 8, 12, dk)
        p.rect(3, 4, 6, 4, dk)
        p.rect(3, 6, 6, 6, dk)
        p.rect(3, 8, 5, 8, dk)
    elif variant == 1:                                              # cross
        p.rect(4, 0, 5, 12, st)
        p.rect(1, 3, 8, 4, st)
        p.rect(4, 0, 4, 12, lt)
        p.rect(5, 5, 5, 12, dk)
        p.rect(0, 11, 9, 12, dk)
    else:                                                           # leaning, cracked, mossy
        p.rect(1, 2, 8, 12, st)
        p.rect(2, 1, 7, 1, st)
        p.rect(1, 2, 2, 12, lt)
        p.rect(7, 2, 8, 12, dk)
        p.rect(4, 3, 4, 7, (50, 54, 60))
        p.rect(1, 10, 8, 12, (58, 98, 58))
    return _finish(p)


def _witch():
    """a witch on a broomstick from behind: slow, wobbly, completely unpredictable"""
    p = _P(14, 18)
    hat, cloak = (34, 22, 52), (88, 40, 128)
    for y in range(0, 5):
        p.rect(6 - y // 2, y, 7 + y // 2, y, hat)
    p.rect(1, 5, 12, 5, hat)
    p.rect(4, 6, 9, 8, (238, 234, 214))                             # platinum hair
    p.rect(3, 9, 3, 13, (238, 234, 214)); p.rect(10, 9, 10, 13, (238, 234, 214))
    p.rect(3, 9, 10, 14, cloak)
    p.rect(2, 11, 3, 14, _shade(cloak, 0.8))
    p.rect(10, 9, 10, 14, _shade(cloak, 0.7))
    p.rect(0, 12, 13, 12, (122, 86, 46))                            # the broom
    p.rect(10, 11, 13, 15, (214, 170, 70))                          # straw tail
    p.rect(11, 12, 13, 13, (170, 130, 50))
    p.rect(4, 15, 5, 17, (24, 20, 28))                              # boots
    p.rect(8, 15, 9, 17, (24, 20, 28))
    return _finish(p)


def _witch_land(frame):
    """a petite platinum blonde in a witch costume, just landed on her broom, facing you"""
    p = _P(20, 20)
    hat, cloak = (30, 20, 50), (96, 42, 140)
    blond, blond2 = (238, 234, 214), (206, 200, 178)
    for y in range(0, 6):
        p.rect(9 - y // 2, y, 10 + y // 2, y, hat)
    p.rect(3, 6, 16, 6, hat)
    p.rect(8, 6, 11, 6, (150, 90, 190))                             # hat band
    p.rect(5, 7, 14, 9, blond)                                      # platinum hair under the brim
    p.rect(4, 8, 5, 15, blond); p.rect(14, 8, 15, 15, blond)        # long, straight, falling past the shoulders
    p.rect(4, 12, 4, 15, blond2); p.rect(15, 12, 15, 15, blond2)
    p.rect(6, 8, 13, 12, (246, 214, 190))                           # fair face
    p.rect(6, 8, 13, 8, blond)                                      # fringe
    p.px(7, 10, (60, 90, 140)); p.px(12, 10, (60, 90, 140))         # blue eyes
    p.rect(9, 12, 10, 12, (200, 60, 80))                            # red lipstick
    p.rect(6, 13, 13, 17, cloak)                                    # little dress (short, she is petite)
    arm = 11 if frame else 14
    p.rect(3, arm, 5, 16, (246, 214, 190))
    p.rect(14, arm, 16, 16, (246, 214, 190))
    p.rect(0, 17, 19, 17, (122, 86, 46))                            # broom across the road
    p.rect(16, 16, 19, 19, (214, 170, 70))
    p.rect(7, 18, 8, 19, (30, 24, 30)); p.rect(11, 18, 12, 19, (30, 24, 30))
    return _finish(p)


_STRANGER_DATA = (
    "eNq9mwuMnNV1x8fenX3O7s7OzmNnZmffb6/ttY3fxhjHxjYxdigymBhBQrDb0FQ2GFoIwRsrNTRQuTGFOARaCqaKaokKREJC05JXmyKSlAY1DW"
    "pLSEVaNaUPKarUqFV1en7n3jO7xl57sdis9Gle33fv/57n/5x7N5G4uL9sNsslPT0V6emuSC7bIfl8TgqFglQqfYlf1J+IJHq6ehJgWLlimeze"
    "uV22bdkkmzaul02XrpP+vl7p6OiQgYGBXwieulTKsKxedYmMj43I6OiwjI4M2efhoUGVTVm6u7ukrbVVmpub5x0Pay+XirJ10zo5ds9Buf7qHb"
    "Jpw2pZOjEq2zatlSs3r5diISctqZSUi0VZsGDBvGFZuHBBoqmpSQb6e+SVr35B/u8//0H+52c/lX9+46/lBy9/SX7yN9+Ql06flF+76RpJKZ7W"
    "lhZZuHDhvNpOe3u7rF21XF5/+YvyH2/9QP79J6/L2z/6nvzbm38lP3r1q/LHn79fpg59RApq221tbcIz82o/dfXS19Mlf/H87yuO78qb339JXv"
    "/2c/J3r3xZXvnK0/KHJ6bk1ht/SVpbW6ShoXFe9bVq1WQi056Wtcsn5K3v/6n878/eEvn526qnr+n1dfmvf3pNvvPCk/Kp226RYr5Dcpl2GRkZ"
    "ec9xrFixwl6v2LxRPn5wv9x07VVy+vOflkO/eoscueuQ/Nkzj8k3n39K7jn8Udl39Xa5ec9OWTI6KFdv3SCXLl9iz+55D/FMxddP/PqtiX0f2C"
    "YHbrhGPvfAPbLjisulM9suvz11uxzav0/Sba2ydPG4bNu4WtZMjsuqJaNy90f2zpst83fjnl1y8oF75b/f/nv5xvNPyx997j5549WX5JFPH5Hb"
    "bt4jDx29XU6d+KRcv/N9hsdks2fPe46HMaemphJ7rtqe+PCeK+WHf/kl9alX5R9f+5r8/F9fl6c/e788fPSQfO/Lp+TEJ2+XsYEeWbN8aWK+8J"
    "jeLrvMXi9bt0q+9ezvyb/88M/lx699XU7/we/KnbfeKEcPfVi+8NBR2X/dVTKkMcrujc/Mxx92jf9e8b6N8q3nnpAfa7x56IEpWal66cxl5Jor"
    "L5fjnzgot1yr9rxoTGb6wnz9TU4uTtQmk3LbgQ/KM098Rq7esVmm1L/3f/ADcsmSMUGXG1ZMaFyukbHh4XnFMjA+nujv75Oa2qRs11z12WN3yk"
    "//9pvywNRh+dCe98vJ3zwsu9THc5k0spFMJiOLFy+eNzxDmr8HFA9zfezmvTJ1+IAcuf2AfErz6p5dV8h1OzfLqqXjMtrfbfekmpulVCrNS85Q"
    "npVYND4mQ4MDNtcN11ypOeIr0t9dksaGeqmrq5OO9ja59v2Xy/hgr93TpvGIfDcxMfGe4ejs7DSO0dPTLePjIzI40C+1yTq5ftcWefM7L8gTx+"
    "+Vu9S3rtAYuGvrpXJA7ai/UpKamhrDAu9Ab7lcTnp7exPvNt9z/7JlyxLd3d0Jxunr7TE+OqH+snTJIunr65Gk5tTtl66Ul597TL79xSflqd+Z"
    "kv17r5JfViwfUrkN9pTNnnO5rHLYvOV5+Af4eF8s5hM33HDDheOLxjuVh5TLJUE3ExPjxgG7uko6VptUusqKp1caGxulpblJjv3Gr8gb3/0Tef"
    "ozR+TJ40fkt+76qNrPmDTU1wk8qaR8rD3dpnm+Qerr66VFc36LciLWydWm+Jhztj99JsF8i1QWyGPR+Kh0V7qUD5Z0XcFn0jo+dqFxSJp1zgM3"
    "XSd3fewmuV9teufWjVJbW2v3tafTdi/v+Q5MYEQ+yKm9nd/T2PuseEZGBhJjyoexWXg5V6/aDXisbugK2JB9UufArpJqx6lUi9Qr16lTGaR0/c"
    "yf0Tk7C3mbF3nyDPPzTCbTbmvqUBmdj2NTvxiW/l6VS8Xm7+nuNp+tqM76DF+PtOt42GtW7QOcXPnIB1l7g/pbqdQpebVhPnd0ZOy3Dq2JwMPF"
    "XOCbDQ92XFR9Dw8PWYzBDrvVjrHfcrlsHH5AcYIR3SMDxnQ8+A8XczU2NpgPMF5nZ8Fk5Bi40CXjt2oNgj2dKz6RZypqK/19fSYD5kRGyKpLMR"
    "T0+d7ebn1ftt+SyVrFkVedFOwVTPgC8zWrreOXyLVU7LR5+d1lA5dFdq2qM3R5LvnoMwlwBPst2pylYin6e7fqusPGZt3IP6k5LB8xFPXyV2TS"
    "0pIyu+tSuSIfZIA83G7Al+0Ad7NhbzuHzmpq6hPEOubHFpBxPhd0Bh7eY5/oEpsAD2tmfsdR0nUUTR4t5gvI12MO92Iv2DWfucBFTZRMnh0j+Z"
    "01gQc74DM+go6QGzEJWYPP8SATdPJOPMgAPDzD/Fm1Yx8TWfFdSmXIeM2p5nPaNPqh3nX/Jl6A33SoGLAt8DEHNoI9M4fJpyqjgIvn6DOAD51w"
    "H+MTD8HBWvge/REnwfXwww9XscCxiO1Dg/2WpxiT2MWFrrAZMGXNR8Ja1R9N/tiz6TLiQS/YBOtC74zhtoNc+OxxFTnzOfsOPOo/iZL5c5/Nzf"
    "q5r7GxKcagIB/mYoyc/k58Rvbcy9pZYy6+Z83gQW/cU1Cb5nvwwAMsXqpPWL6N+juTJ9Uk8CvzUZVNwNNs4yIr7BI5BV9JWVxFPg0aZ7B7xkVW"
    "2Ad6SNYlzU/ReTrGGuZPqa2ApU71hbyIpzzTiB4qPVW/1/GqeHgWPGBxHyKPoi90YvapsmBc7jG7j/kx1MgNJgPiFa8mT+K0zt8c8TgXAZPLTe"
    "tYw3PgwIEE96MPcgVYsEewWIxRGyAeoTdslt+w61od03O2y4ffiG9873pzPODGBsh7tbU1di82hNz4nvvGlQ8/+OCDiapOVOfYgPMD8PAZHPyG"
    "jWVjDmKNrB/9p6POQrwN8umYMY/hUbx85jfGBrflkUwm2mqj1fqDg4OJTpUt8RtZ4CPgYf34AX6H7MkT6K6V2Kafz8CTDtyhJeqLdYB7Gk/WXr"
    "EtxuRZ7nO54Y/YFn6FTRDXiV/0JIsx3zDP6tVr7D0+bf6rz6Nr7mFM5jVOg65iHgj2E+TKGC4fz8Fr166178HA3M6D4FLkbe4jT5Bz8ZnGqCvl"
    "q/Lxu+82GaDPELezNg+yWrhwgY0PHvdZs49od2Bw2eXyecOFbO644w7TO8+Sk1kXOsZvuSdr/Chjr/gReue5NWvWyH333Wf3gwf5oAPWlVdcYK"
    "8zLpYyPTB3U1Nj1X+cDyE71wvjHj16VFasWG7v8R2XY119GAudkwNYM7ZFDOPe4aFhOXLkiM3JepBPR8Re1DhEPHT5ME6j8sPGaK9gDTm5PfKw"
    "4LOMq3xZRoNvW3wIPD9t8uEe4g340R29WzgF62WcdevW2f3YMfGQ8bkf/ODhYn7k4voCI3g8brN21sHvfL93714bg/mRgec7qxH03tHRUXsWf0"
    "cG2Bjj1ET/ymRCvqro79iCc1PXu+XqiMVjRI3O6/GXOXie39E1a/Acyly56CNcyIR4GHm+2fXw0IDph9/rde3UFTwDNwMnWFriWuuVJzeazdRo"
    "TV9ja0RWrgvuDXwjcC9+Bw+yR8bMg8z5nt83bNhgNRd8k7Xw+6DmeF7dV0IOC3mbcZB1e6xjuBjL7RVfZz6rd3QedAGenOJiPvMpvZBTNu538D"
    "38H51534q46ByOnIlNE2uw70y0GWJgm+JwvQV9NcqK5ctlctmkxYf+/n7DZLUH+tB1sK7AQZqD/0ROQHwJewohNpfy+TP4WOAjwf5GtMbArslb"
    "Xj8UYj2A7MDDOhl/cnLSZO88x/RseStt9gEOz4keH0O877L7uBjv0UcfPQNPPpNJWGzJU/f3mJxCTg91YKzdqvwc+6mpWWj1yOTkUstv+Ayy4T"
    "eTcT5X9S9wgNX0rVjBiFzwiWWrl52zBkPW6Nz3TFiD1Rtq9yF/t8Q82Wi21RL2cKr+yoXeDQ95JvKTwEdCjTxdd6WqPrd69epz4imXi+bfYayC"
    "OGcEI7yA+cDmccY5WEtrkAGfkQOxlns9F/I9z7tPcC9rDxw6M2u9vH37dvN9eF+n1VQFq0+DzDLmE3BXy5k6Z6x3bc5czA/GSfU3i+vFYqzZA5"
    "/1micT6xOeXbRoclY88Pq29uC3wV87LacRR/EtPpdibvf6o0nl3RH7Tc7JiEvkSmKsYdXfWJvlq1y2ytn4fi77LeiCZzoLcBGtr6JPMRZ2BTcy"
    "X5mRD7xO9t4BnCP4Yrutjfe5mNNqY2+kZmHNnLcHWD9zlGKvxfy0sxC4D7wk9lDAY3Vm9Gfj58bJau1e54289zyWND6fmVOfE/k5n7Q8Ugw1J3"
    "wcW2ad4MWmweDxBntBPo4v1AJ55bKBW3dG7m3ck3pH8bwz5szWv/ScwjhgKMYaiNg8036aYw71mMP70CNojvVrtppLspGzhhhYF/N77wXx0OdA"
    "P54Hra5QPMQNYh49BebyWst5QOjL1Zh985vXGB5vPCY6Z2oN8emCeKjFmN/jBHi83wQHwufBgE04HmTjXAheDo5QP7Tbs2bz2YDHOWXsCV0QT1"
    "4xOwfCV0IPJ+R38ojncfIdMmjQC9kEPEmbi3Wgj9DbLVZ7qmYHTY2R24Z8Nwf5mJ1YPa4yIWeUYg8DPF4rMZ/7iusLn4ox1/KX1xDg8tgNFsfD"
    "64Xw5HL04ntivAk8tmS9nZJxenKX2wO40NU0nmTofUWu6rWR+7y9xtjgcV0SckH59Fhvoi3wQvpNFpeLljvIx9SEGcXjvjVtz0E+xskjN3SfZ2"
    "7H5Tw+9l7OdxbC9ioqsc8GFrcd7Ih+L77q/TbnXo6H995/Agf6Yh2h19Aa9Egda/VgqJFWrlw5Kx6VfwJZkHfwI3gWeYery/y+YHhm9jKcn7p8"
    "WmP+sJihNlaKcbkl6hg/s7xn9pOyGnm2P9V/AjnQ6zA8yCfyw3LslYLBfaU++pZf2BIYvM8ZfDr0BVqifLAt73WYPrOz+7zKz3rQ3kc2DBFPiI"
    "udIc7FnDnTt/xiHuIy63L55Av5qr6QEVzB/UvnmBWP9V26Q9+AueEZxuXtzFOXxSPPs9iG753MvKgV2ttDruPV9I2sos97XHT7OV8MYg0ej5kf"
    "PL5HwXvrzeplfdqYo87GE3iR817k6H0jjxOZyMWds86W5zvw9cjh4fLYM36L/jjz5DULY4b67Gw8ZtMxBrmtYIe5uD+ArjOxB+V16Wx7YOgd3z"
    "I8+ur7TNZPUF9HR60xr3m96H7ucRF/c07oexXBP7JVG3L5BP7UKrPtxblegn+Xq7UXcjI8iiEde08zYzOvM99bTUoPyvw89E/wsZnycV6C/Gar"
    "L7yXWrJ+Ylfct8mLxwAwhDW3nhF7PL/7e4uJ8exf6EGEHor3Pb1Xbxwr1ADnrnes5irb/MZ11G5YFzaFzqxW18/W71Q/cpl4D8r15XuTVifFnm"
    "7o0c+I0zEGoU/i3jn2UxL4KP7FhT37utBVPuIIfdw6k4HLBLuGiy2IeDw2eb1BnGCcmTaUtn5ro3Pbszgz95tP2d5kwBTyUKG6BxVq5ND3AZPL"
    "w+QDnojP923ByBXWla3mCrjItI9Rg5fO8DHwFCPf8jjoPlqKvUN4CPOhM+wyxJ4F03jQ14LpvOG1K7957eX6apvho6FnkD8DD/GI/ddus5OS2X"
    "TwidCb6475zPqvKmM4p8cevvM+Kf0F50GpVNj7417fW53Jf/hMbG2KvaCDBw+etd/kMdD2wMrlauzBtlmb99oYhzn5HPrQoXdbq5fLq1r31CWr"
    "5yW8v2l9CcWQijyR7w8fPlzFo3wwgUzREbKwGB33aUux92w9n2RtlW+ybp/b9wB477wefs2FPNOR21HDpeO+gXPXoLNmYZ9g5v5Xt9VWwVbA5J"
    "wK+Thvtj5ktqNqF8wNRqup2NdK1lb70r4Xb9ywZZq3em1n+bU9Xc0bQ0NDMpMXdlntWbI9dt57rczF3iN5OxV7bV5/Yi+8NjRO77+AB6xeY3u/"
    "BTzGm1RGTZE7+/4g8hkbG5N38kLvsZa8J1UOfuax2fJk7OH6vgCX97kCxhrDE3hKvsotSnEPfTq3t1R5As9zP36FLYOffVv8nD3dzrh3j22bfa"
    "u+6iOvsTykuLw+Tibrqn3Aeuv7BLkFmYQ6mzjKuhyP8+dQpwUb4izV0qVLYy8zrTbba3IZGhoI9UHcN0F3vLrf+vq8hnf9O59xu/b6hLG87xj4"
    "c7bKn71uDDV2q+3HEYfwdXKC7afHeqAQz28E/lowmXpN5fHe+ha5XGLbtm12lSqlRLp12n9CTzzggbc6BwGD8zaXD+PjV/EMknFV/BzdhD5WqL"
    "2Mk1Gza9xnDWbP+jo0NHaemjKX8L0RfN16iXGP2f2dy+sCMIJl5slJPrebzYReBrjQE7EHuwx7kB1VzqI6Oe9Z19DbDX26UId1Vrl8sPGQ28G0"
    "cePGWc+VTU5O2tmxFp23yfbsStZ/9N6O94WKGiNm+xseHk44drcver3Itynu4xBj5tLfmNl3MQ4XdUusdS4Wez/n1VfIWaF/aT1berJxP+Rizo"
    "z39/cncnFfBp5CPOQVn47+ft6zwLZH19gQe3ipuO+clHZdy5o1a941HtZQrpQtT6fjuZTQB2A/pmEO5ydLtkcTzmWFer+xMfSRL0Y+2CR9BdZH"
    "LKxUKtV9LOrYC/2Zf6itDgwMmM6ML0bec3H/a7HQ+P10r69QPb+zb9++OZz9X2U6c96LDdJLIwddDB5kmsmkYxzNhP+BiT3MuZ75tPM6PT1hv7"
    "G5OZ4TyF7UudXdu3cnvL+PfDjb4Wet5npeN5msN/k4X/Fe58Wc9+XcJPEiF89RwBGtN9qcOm8snClfP0PFOeW2eFYMvydPvduz+9iLnYXVcTiT"
    "2BHP2LDOufSNNf8kPFeMjY6E9cTzFfl89l0JSLmj+aifw+nSq5kcHm1bc/scdJVMwFt8j3PxxLjlQTvvp3Kay7l6+IfH5XLsY3bH84bGKYhxTX"
    "CN+gv7p+JhPzb0GsP5NsZijeEcSjNxO3H69OlZztKOWH162aXrZfmypcaDbN807qUR51Mai8rFrBQLHVYvzbZG7JX/W6mU8/ZMS2vYO2MvHb53"
    "ySXL7TUd91HPNUYN/Q3lP1u3bpEN69faPi32Y9yEM3CZFunr1pqxQr+9uTrGiRMnbH7wvfDCC7rePfH8YKssWTQkg72dUsxnAiaV+eTSJbJ1y2"
    "bjy2nj9vR8i2fh6a10ykBvUUqdWod1cTY3Y/MWCxmpFNmPCL3LdFuL7N69S06dOiXHjx9PnDr1TIJ9o2cffzbx1FNPGb5HHjkpl1++SeVTtL2w"
    "zlybDPYov+uihqK3WLA5shrfSjp+uTN3lm9ynnjZklHZtH5Stm1eJSuWDEqlpH6uY7S1pmTN2rVyYP9+6kj2reTxxx+XhxQPz+r7qh089thjiZ"
    "MnTyrGk3LnnXcQy2X1mrVat3TL8iVDsnL5uOzctl42rpmQgR5dt+o1NyOHIGfGXL9+PWcA1beHTZYVzj0rZxwZHZUtW7bIvffeKy+++GLiXLHM"
    "9eX1wUwf47tjx47B1aW/f8DO0U1MTNj45CONRbJjx47qM/8PGDaWXg=="
)


def _stranger():
    """the man in the long black coat (pixel art from the reference sheet, stored as compressed raw pixels so there is no image file to ship),
    with a faint violet rim so he still reads against a dark road"""
    import zlib
    import base64
    raw = zlib.decompress(base64.b64decode(_STRANGER_DATA))
    img = pygame.image.frombuffer(raw, (36, 104), "RGBA").copy()
    w, h = img.get_size()
    out = pygame.Surface((w + 2, h + 2), pygame.SRCALPHA)
    for y in range(h):
        for x in range(w):
            if img.get_at((x, y))[3]:
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    out.set_at((x + 1 + dx, y + 1 + dy), (84, 70, 120, 255))
    out.blit(img, (1, 1))
    return out


def _druid(frame=0):
    """the forest druid: floppy moss-green hat with a feather, bushy grey beard to his belt, a patched green robe, a wicker basket of mushrooms on his back and a staff
    topped with a purple mushroom. frame 1: he lifts a mushroom to show you"""
    p = _P(32, 56)
    hat, hat2, band = (84, 100, 54), (58, 74, 38), (176, 62, 48)
    robe, robe2, patch = (62, 104, 66), (44, 78, 52), (150, 108, 60)
    beard, beard2 = (236, 236, 230), (190, 190, 190)
    skin, skin2 = (226, 178, 142), (190, 140, 108)
    wick, wick2 = (178, 130, 66), (128, 92, 46)
    # basket on his back (behind the body, peeks out on the right)
    by = 24 - (1 if frame else 0)
    p.rect(21, by, 28, by + 12, wick)
    for q in range(22, 29, 2):
        p.line(q, by + 1, q, by + 11, wick2)
    p.rect(21, by + 4, 28, by + 4, wick2); p.rect(21, by + 8, 28, by + 8, wick2)
    for dx, c in ((22, (205, 52, 48)), (25, (240, 238, 226)), (27, (205, 52, 48))):
        p.rect(dx, by - 3, dx + 1, by - 1, c)
    # robe
    for y in range(24, 51):
        x0 = 8 - (1 if y > 33 else 0) - (1 if y > 42 else 0)
        x1 = 23 + (1 if y > 33 else 0) + (1 if y > 42 else 0)
        p.rect(x0, y, x1, y, robe if (y // 4) % 2 == 0 else robe2)
    p.rect(11, 40, 14, 44, patch)                                          # a patch on the robe
    p.rect(8, 33, 23, 33, (150, 118, 70))                                   # rope belt
    p.rect(8, 21, 23, 25, (112, 82, 54))                                    # leafy shoulder cape
    for q in range(8, 24, 3):
        p.rect(q, 26, q + 1, 26, (112, 82, 54))
    # arms
    p.rect(5, 23, 8, 34, robe); p.rect(5, 35, 7, 36, skin)                  # left arm, hand
    if frame:
        p.rect(23, 17, 26, 26, robe); p.rect(24, 14, 26, 16, skin)         # right arm up
        p.rect(23, 9, 27, 13, (205, 52, 48)); p.rect(25, 12, 25, 14, (240, 238, 226))   # the mushroom he shows
        p.px(24, 10, (240, 238, 226)); p.px(26, 10, (240, 238, 226))
    else:
        p.rect(23, 25, 26, 34, robe); p.rect(24, 35, 26, 36, skin)
    # beard
    for y in range(19, 41):
        t_ = (y - 19) / 21.0
        half = int(6 - 4.5 * t_ ** 1.2)
        p.rect(16 - half, y, 15 + half, y, beard if (y % 3) else beard2)
    p.line(14, 28, 14, 36, beard2); p.line(17, 26, 17, 34, beard2)
    # face
    p.rect(12, 12, 19, 19, skin)
    p.rect(19, 15, 20, 17, skin2)                                           # nose
    p.px(13, 14, (30, 24, 20)); p.px(17, 14, (30, 24, 20))                  # eyes
    p.rect(12, 12, 14, 12, beard); p.rect(16, 12, 18, 12, beard)           # eyebrows
    p.rect(11, 17, 19, 18, beard)                                           # moustache
    p.rect(9, 14, 11, 19, beard2); p.rect(20, 14, 22, 19, beard2)          # hair at the sides
    # hat: wide brim, floppy cone with a bend, a band and a feather
    p.rect(7, 10, 24, 11, hat2)
    p.rect(9, 9, 22, 9, hat)
    for y in range(2, 9):
        x0 = 11 + (8 - y) // 3
        x1 = 20 - (8 - y) // 4
        p.rect(x0, y, x1, y, hat if y % 2 else hat2)
    p.rect(17, 0, 22, 2, hat); p.rect(21, 1, 23, 3, hat2)                   # the tip flops over
    p.rect(10, 8, 21, 8, band)
    p.line(22, 8, 27, 3, (240, 232, 204)); p.line(23, 8, 28, 4, (214, 204, 176))   # feather
    # staff with a purple mushroom cap
    p.line(3, 8, 3, 54, (110, 76, 44)); p.line(4, 8, 4, 54, (86, 58, 34))
    p.rect(0, 4, 7, 7, (170, 60, 200)); p.rect(1, 3, 6, 3, (200, 100, 226)); p.px(2, 5, (130, 250, 232)); p.px(5, 6, (130, 250, 232))
    p.rect(2, 8, 5, 8, (226, 218, 196))
    # boots
    p.rect(10, 50, 14, 54, (70, 50, 36)); p.rect(17, 50, 21, 54, (70, 50, 36))
    p.rect(9, 54, 14, 54, (46, 32, 22)); p.rect(17, 54, 22, 54, (46, 32, 22))
    return _finish(p)
def get(name, frame=0, flip=False, **kw):
    key = (name, frame, flip, tuple(sorted(kw.items())))
    if key in _CACHE:
        return _CACHE[key]
    if name == "worker":
        s = _person(top=(244, 126, 24), bottom=(48, 54, 72), skin=SKINS[1], frame=frame if frame < 4 else 0,
                    worker=True, dig=frame if frame >= 4 else None)
    elif name in ("ped", "kid"):
        look = kw.get("look", 0)
        top = kw.get("shirt", (160, 40, 40))
        skin = SKINS[look % len(SKINS)]
        args = dict(top=top, bottom=[(40, 50, 90), (60, 52, 44), (36, 36, 40), (90, 70, 120)][look % 4],
                    hair=[(50, 34, 24), (210, 170, 70), (26, 22, 22), (140, 70, 40)][look % 4], skin=skin,
                    frame=frame, dress=(look % 3 == 1 and name == "ped"), long_hair=(look % 3 == 1),
                    hat="cap" if look % 4 == 2 else None,
                    backpack=(70, 90, 60) if look % 4 == 3 else None)
        s = _kid(**args) if name == "kid" else _person(**args)
    elif name in ("cop", "medic"):
        look = kw.get("look", 0)
        s = _person(top=(38, 84, 168) if name == "cop" else (52, 150, 104), bottom=(22, 30, 64) if name == "cop" else (36, 84, 66),
                    skin=SKINS[look % len(SKINS)], hair=(40, 30, 24), frame=frame, uniform=name)
    elif name == "druid":
        s = _druid(frame)
    elif name == "stranger":
        s = _stranger()
    elif name == "smoker":
        s = _person(top=(244, 126, 24), bottom=(48, 54, 72), skin=SKINS[2], worker=True, smoker=True)
    elif name == "sleeper":
        s = _sleeper()
    elif name == "cone":
        s = _cone()
    elif name == "barrier":
        s = _barrier()
    elif name == "deer":
        s = _deer(frame)
    elif name == "boar":
        s = _boar(frame)
    elif name == "piglet":
        s = _boar(frame, True)
    elif name == "pine":
        s = _pine(frame)
    elif name == "maple":
        s = _maple(frame)
    elif name == "cat":
        s = _cat(frame)
    elif name == "ghost":
        s = _ghost(frame % 2)
    elif name == "coffin":
        s = _coffin()
    elif name == "pumpkin":
        s = _pumpkin()
    elif name == "gravestone":
        s = _gravestone(frame % 3)
    elif name == "witch":
        s = _witch()
    elif name == "bat":
        s = _bat(frame % 2)
    elif name == "spider":
        s = _spider(frame % 2)
    elif name == "witchland":
        s = _witch_land(frame % 2)
    elif name == "zombie":
        s = _person(top=(96, 92, 74), bottom=(56, 52, 44), skin=(96, 132, 76), frame=frame, costume="horde")
    elif name == "costume":
        look = kw.get("look", 0) % 4
        cs = ("sheet", "pumpkin", "skeleton", "zombie")[look]
        top = {"sheet": (200, 60, 60), "pumpkin": (30, 28, 40), "skeleton": (22, 22, 28), "zombie": (96, 92, 74)}[cs]
        skin = (118, 156, 88) if cs == "zombie" else SKINS[look % len(SKINS)]
        s = _person(top=top, bottom=(30, 30, 40) if cs != "zombie" else (70, 66, 56), skin=skin,
                    frame=frame, costume=cs)
    elif name == "deadtree":
        s = _deadtree()
    elif name == "traffic":
        s = _traffic_car(kw.get("kind", "sedan"), kw.get("color", (180, 40, 40)))
    elif name == "xcar":
        s = _side_car(kw.get("kind", "sedan"), kw.get("color", (180, 40, 40)), frame % 2)
    else:
        raise KeyError(name)
    if flip:
        s = pygame.transform.flip(s, True, False)
    _CACHE[key] = s
    return s


if __name__ == "__main__":
    import os
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    pygame.init()
    pygame.display.set_mode((10, 10))
    items = [("worker", 0, {}), ("worker", 2, {}), ("worker", 4, {}), ("smoker", 0, {}),
             ("ped", 0, dict(look=0, shirt=(160, 40, 40))), ("ped", 1, dict(look=1, shirt=(40, 120, 70))),
             ("ped", 2, dict(look=2, shirt=(200, 170, 50))), ("ped", 3, dict(look=3, shirt=(90, 60, 140))),
             ("kid", 1, dict(look=0, shirt=(60, 120, 200))), ("sleeper", 0, {}), ("cone", 0, {}),
             ("barrier", 0, {}), ("deer", 0, {}), ("deer", 2, {})]
    sheet = pygame.Surface((1500, 290))
    sheet.fill((110, 70, 45))
    x = 8
    for name, fr, kw in items:
        s = get(name, fr, **kw)
        z = 7 if name in ("worker", "smoker", "ped", "kid") else 5
        big = pygame.transform.scale(s, (s.get_width() * z, s.get_height() * z))
        sheet.blit(big, (x, 282 - big.get_height()))
        x += big.get_width() + 10
    pygame.image.save(sheet, "sprites_preview.png")
    sheet2 = pygame.Surface((520, 340))
    sheet2.fill((40, 30, 20))
    x = 10
    for name, fr in (("pine", 0), ("pine", 1), ("deadtree", 0), ("maple", 0), ("maple", 1), ("maple", 2), ("maple", 3)):
        s = get(name, fr)
        big = pygame.transform.scale(s, (s.get_width() * 6, s.get_height() * 6))
        sheet2.blit(big, (x, 335 - big.get_height()))
        x += big.get_width() + 20
    pygame.image.save(sheet2, "trees_preview.png")
    print("saved")
