"""Level 3: ROAD RAGE ISLAND (working name). A causeway between two seas on a sunny morning, fog banks drifting in off the water.
Leaving the road is not an option: the water ends your run. Keep it a RACE, not a skill test: wide road, clear warnings, few tricks."""
from ..config import LS

ZONES = [
    ("HARBOUR ROAD", 0, 0.6),
    ("THE CAUSEWAY", 5000, 0.9),
    ("STORM BRIDGE", 9400, 0.5),
    ("LIGHTHOUSE POINT", 12300, 0.75),
]

# what each zone throws at you: beach things on land, flying fish on the causeways (a beach event that falls on the sea turns into fish)
EVENTS = [
    ["crabs", "beach", "sand", "surfers", "ballkid", "beach", "umbrella", "crabs", "ballkid", "sand"],
    ["fish", "fish", "fish"],
    ["fish", "fish"],
    ["surfers", "crabs", "beach", "umbrella", "ballkid", "sand", "umbrella"],
]

SEA_RANGES = [(5200.0, 12000.0)]          # one long causeway from the harbour to the lighthouse; everywhere else is dry land
_LH = [False]
_LB = [-1]


def _scen_island(s, zi, r, rng):
    """what stands beside the road: cottages and palms on land, boats, buoys and rocks where the road runs through the sea"""
    amt = 1.0 if any(a - 168 < s < b + 168 for a, b in SEA_RANGES) else 0.0
    if not amt and any(a - 260 < s <= a - 168 or b + 168 <= s < b + 260 for a, b in SEA_RANGES):
        return "weed", rng.uniform(8, 14)                # where land turns into sea: only beach grass, no houses or palms
    if amt:                                              # the sea wall: boulders, weeds and white marker posts, a fishing boat far out now and then
        if int(s // 26.0) != _LB[0]:                     # a white post with a red band every 26 m
            _LB[0] = int(s // 26.0)
            return "ibollard", rng.uniform(2.6, 4.6)
        return ("weed" if r < 0.12 else "riprap"), rng.uniform(11.0, 16.0)
    if zi == 0:
        return ("cottage" if r < 0.34 else ("palm" if r < 0.66 else ("lamp" if r < 0.82 else "umbrella"))), rng.uniform(20, 44)
    return ("palm" if r < 0.52 else ("umbrella" if r < 0.74 else "cottage")), rng.uniform(22, 48)


ISL_EVENTS = [(1700, "gulls"), (3700, "guard"), (4300, "gulls"), (10200, "marlin"), (9500, "ghost0"), (10590, "ghost1"), (10930, "ghost2"), (11230, "ghost3"), (11800, "ghost4"), (11950, "ghost5"), (12800, "gulls"), (13000, "treasure"), (13500, "divers"), (14700, "gulls"), (15300, "divers"), (14300, "shades"), (15900, "guard"), (16450, "lastgull")]

THEME3 = dict(isl_events=ISL_EVENTS, bike_cut=(0.16, 0.62), rail_bases=(), no_overpass=True, no_gas=True, ads=["hd1", "darkfm", "hotel", "beer"], gap=((420, 760), (520, 860), (480, 800), (420, 760)),
              
    no_night=True, sunrun=(12300.0, 14000.0, 15200.0, 16000.0), glare=(13300.0, 14100.0, 15200.0, 15900.0), bb_end=4700.0, tod=[(0, (255, 255, 255)), (99999, (255, 255, 255))],
    sea=dict(shoulder=0.12, kerb=((196, 190, 176), (176, 170, 158)), foam=(236, 244, 248), ranges=SEA_RANGES, fade=240.0,
             land=((112, 158, 82), (104, 150, 76))),
    sky_bands=((92, 160, 224), (140, 198, 240), (196, 228, 248), (246, 240, 214)), sun=(250, 226, 150),
    ground=((4, 56, 100), (3, 52, 94)), road=((118, 116, 112), (112, 110, 106)),
    haze=(190, 224, 240), haze_k=(0.2, 0.06), fog_dist=1400.0, scen_off=dict(lighthouse=(140, 220), palm=(10, 70), umbrella=(12, 60), swave=(60, 120), riprap=(165, 200), weed=(16, 60), ibollard=(38, 62), fishboat=(160, 260)), wet=((5300.0, 8200.0),), storm=(9200.0, 9800.0, 11500.0, 12100.0), lightning=True, bridge=(11450.0, 16.0), backdrop=(("town", -30, 320), ("lhisle", 480, 120)), backdrop_drift=dict(town=-0.022, lhisle=0.025),
    ridge=((150, 186, 206), (120, 160, 184)), horizon=((214, 234, 246), (240, 248, 252)),
    edge=((240, 238, 228), (206, 204, 196)), dash=(246, 240, 214), scenery_pos=_scen_island, scenery=lambda zi, r, rng: ("palm", 30),
    traffic=("sedan", "sedan", "van", "truck"), xcar_kinds=("sedan", "van"),
    no_cats=True, no_finale_family=True, no_cross=True, no_fork=True, no_slide=True, no_finale_car=True, clear_curve=0.8,
    music="music", dark_file="quick_fix", dark_song="MianN - Quick Fix (instrumental)", stations=("music", "beach_radio"), extra_time=6.0,
    start_talker="lifeguard", start_quips=("THE SUN IS PRETTY STRONG TODAY.",),
    town="HARBOUR ROAD", hill="LIGHTHOUSE POINT", radio="DARK.FM",
)

Y, R, G, P, O = (230, 190, 50), (240, 90, 70), (120, 230, 110), (190, 150, 255), (240, 150, 60)

RULES = [
    ("WATCH OUT", [
        ("sign:gull", R, "SEAGULLS AND FLYING FISH", "Small hits, but they add up."),
        ("sign:crab", R, "CRABS, SURFERS, BEACH KIDS", "They wander across. Don't hit them."),
        ("sign:sand", R, "SAND DRIFTS", "Slow and slippery."),
        ("sign:diver", R, "DIVERS   heavy damage", "Masks on, can't see you. Honk.")]),
    ("THE BRIDGE", [
        ("sign:fish", R, "THE MARLIN   heavy damage", "It jumps across the road. Stay near the edge."),
        ("sign:ramp", R, "BRIDGE OUT", "Floor it to jump the gap. Too slow: you swim."),
        ("sign:treasure", G, "TREASURE   +10 SEC", "Grab it and nothing hurts for a while.")]),
]

LEVEL = dict(
    name="ROAD RAGE ISLAND", sub="SUN'S OUT, SEA'S IN YOUR WAY, GULLS HAVE OPINIONS.", seed=11, theme=THEME3, sea=True, locked=True, unlock_text="COMING SOON", unlock_at=1793980260, new=True,
    zones=list(ZONES), events=[list(e) for e in EVENTS],
    rules=RULES,
    info="",
)
