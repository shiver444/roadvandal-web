"""Level 5: MUD KNIGHT (working name). A muddy medieval road to a castle: river ford, leper colony, siege camp. No cars on this road.
Sprites: assets/med_sprites.png + .json (names m_*)."""
from ..config import LS

ZONES = [
    ("THE MUD ROAD", 0, 0.8),
    ("THE RIVER FORD", 4800, 0.9),
    ("LEPER COLONY", 9200, 0.7),
    ("THE SIEGE CAMP", 12600, 0.85),
]

EVENTS = [
    ["wetleaf", "mpeas", "mlogx", "mwolf", "mgeese", "mcartx", "mhorse", "mpeas", "wetleaf", "mlogx"],
    ["wetleaf", "mpeas", "mlitter", "wetleaf", "mcartx", "mwitch", "wetleaf", "mgeese", "mlogx"],
    ["ped", "ped", "wetleaf", "ped", "mwolf", "mwitch", "ped", "mlitter", "ped"],
    ["rockfall", "mhorse", "mcartr", "mspear", "mram", "mwolf", "mwitch"],
]


_W = {
    0: (("mpine", .30), ("moak", .10), ("mdead", .06), ("mpost", .07), ("mfence", .12), ("mrocks", .07), ("xhut", .05), ("mcattail", .04), ("mgrass", .10), ("mcrows", .05), ("mtorch", .04)),
    1: (("mcattail", .26), ("mpine", .22), ("mgrass", .12), ("mgeese", .06), ("mfisher", .05), ("moak", .08), ("mstones", .06), ("mrocks", .07), ("mlog", .04), ("mfence", .04)),
    2: (("xhut", .22), ("mbell", .10), ("mcart", .10), ("mdead", .15), ("mcrows", .10), ("mpine", .12), ("mtorch", .06), ("mfence", .10), ("mrocks", .05), ("mpot", .06)),
    3: (("mtent", .22), ("mfire", .10), ("mshields", .10), ("mwagon", .08), ("mladder", .05), ("mcatapult", .06), ("mdead", .10), ("mtorch", .08), ("mpost", .08), ("mbanner", .08), ("mpine", .04)),
}


def _scen_med(zi, r, rng):
    """what stands beside the road in each stretch"""
    acc = 0.0
    for k, w in _W[zi]:
        acc += w
        if r < acc:
            return k, rng.uniform(16, 34)
    return _W[zi][-1][0], rng.uniform(16, 34)


THEME5 = dict(
    night=True, moon=True, sky=True, tod=[(0, (190, 170, 190)), (99999, (186, 168, 188))],
    ground=((86, 62, 32), (80, 58, 30)), road=((84, 50, 40), (80, 47, 38)), road_tex=("t_road_a", "t_road_b", "t_road_c"), ground_tex="t_ground", no_edge_lines=True, no_dash=True, edge_tex="t_edge", tex_dim=(235, 222, 240), tex_dist=170.0, road_m=8.0, ground_m=7.0, edge_m=1.6, haze=(96, 78, 112), haze_k=(0.6, 0.2),
    fog_dist=1000.0, fog=(96, 80, 112), ridge=((62, 48, 76), (42, 32, 54)), horizon=((110, 84, 112), (168, 128, 128)),
    edge=((70, 44, 30), (64, 40, 28)), dash=(84, 50, 40), scenery=_scen_med,
    scen_off={"mfisher": (8, 15), "mgeese": (8, 16), "mcattail": (9, 34), "mgrass": (8, 30), "mstones": (9, 20), "mcrows": (10, 30), "mpost": (9, 14), "mtorch": (9, 14), "mbanner": (9, 14), "mfence": (9, 13), "mlog": (9, 20), "mrocks": (9, 30), "mtent": (9, 22), "mwagon": (9, 20), "mcart": (9, 18), "mcatapult": (11, 22), "mfire": (8, 16), "mshields": (9, 16), "mladder": (9, 15), "mpot": (8, 14)},
    hut_sprites=("m_hut",), island=("pine", "mdead", "rock"), lamp=((255, 190, 110), (255, 170, 80)),
    backdrop=(("m_hills", -24, 749), ("m_castle2", 350, 300)), backdrop_par=dict(m_hills=21), backdrop_grow=dict(m_castle2=(11500.0, 16500.0, 60, 560, 700.0)),
    car_colors=[(120, 90, 60)], traffic=("sedan",), no_traffic=True,
    reskin={"ped": (tuple("m_lep_walk%d" % i for i in range(6)), ("m_lep_idle0", "m_lep_idle1", "m_lep_ring"), True), "kid": (tuple("m_lep_walk%d" % i for i in range(6)), ("m_lep_idle0", "m_lep_idle1", "m_lep_ring"), True)},
    reskin_step={"ped": 5, "kid": 5},
    reskin_h={"ped": 1.15, "kid": 1.05},
    reskin_dist={"ped": 0.21, "kid": 0.21}, reskin_anim={"ped": (12, 0.012, 1.5), "kid": (12, 0.012, 1.5)},
    reskin_sign={"ped": "m_lep_ring"},
    impact_text={"ped": "THAT WAS A LEPER!", "kid": "THAT WAS A LEPER!"},
    patch_names=("m_pud_l", "m_pud_m", "m_pud_s"), ford_tex=("t_ford_a", "t_ford_b"), ford_zones=(1,), ford_len=14.0, ford_wide=11.0, ford_wob=1.6, ford_fade=0.2, ford_drag=0.035, rock_sprite=True, wet_n=2, wet_step=7.0, wet_full=True, ice_patch=(80, 96, 120), wet_msg="", glyph_txt={"slip": "FORD", "sand": "MUD"},
    honk_peds=True, mud_drag=0.0035, mud_cap=0.42, mud_heavy=(12170.0, 12730.0), puddle_sink=0.012, extra_time=10.0, plague_clock=0.4, cp_skip=(10500.0,), cp_bonus=34.0, witch_cure_sec=22.0, car_splash=True, no_crosswalk=True, cp_clear=260.0, no_gas=True, no_overpass=True, no_cats=True, no_cross=True, no_fork=True, no_slide=True, no_tow=True, no_finale_car=True, no_hearse=True, no_finale_family=True,
    bb_max=4, wood_boards=True, plague=True, plague_rate=0.032, med_cp=True, ground_blur=True, ads=["bards", "bronmace", "bardfest"], rail_bases=(),
    start_talker="bron", start_quips=("Hail, traveller! Find my mace!", "Good morrow! My mace is lost!", "Oi! My mace is in the mud. Find it!"),
    music="music", stations=("music", "bard_radio"), dark_file="dirty_techno", dark_song="MianN - Dirty Techno (instrumental)", start=350.0, mace=(7270.0, 0.0, 12540.0, -0.62), fin_court=True, l5_audio=True, plain_end=True, end_mist=(14700.0, 15850.0, 16470.0, 0.95), mwitch_at=(11000.0, 15210.0), forest_bonus=9.0, forest_cap=0.55, forest_drag=0.003, brake_snd="m_skid", gap=((170, 300), (230, 340), (200, 320), (280, 420)), clear_curve=0.82,
    town="THE MUD ROAD", hill="THE CASTLE", radio="DARK.FM")

Y, R, G, P, O = (230, 190, 50), (240, 90, 70), (120, 230, 110), (190, 150, 255), (240, 150, 60)

RULES = [
    ("MUD AND PLAGUE", [
        ("sign:slip", R, "RIVER FORD   deep water", "Slow down in the water."),
        ("none", R, "PUDDLES   they drag at the car", "Steer around them."),
        ("sign:ped", R, "LEPERS CROSSING", "Honk to warn them. Don't touch them."),
        ("none", R, "WOLVES, KNIGHTS AND CARTS", "Everything on this road bites.")]),
    ("THE SIEGE", [
        ("none", R, "SIEGE CAMP", "Watch for flying rocks."),
        ("none", G, "HERMITS AND WITCHES", "Some of them can help. Be polite.")]),
]

LEVEL = dict(
    name="MUD KNIGHT", sub="MUD, PLAGUE AND A MISSING MACE.", seed=31, theme=THEME5, locked=True, unlock_text="COMING SOON", unlock_at=1798758000, new=True, medieval=True,
    zones=list(ZONES), events=[list(e) for e in EVENTS],
    rules=RULES,
    info="",
)
