"""Level registry. To add a level: write game/levels/<name>.py with a LEVEL dict, import it here and add it to ORDER.
Set locked=True in a level to hide it from the level picker until you unlock it."""
from . import level1, halloween, island

ORDER = [halloween, level1, island]                       # level numbers are the positions (1, 2, ...); seeds keep each road the same.
# Halloween is level 1; Pine Road is locked (hidden) until you unlock it
LEVELS = {i + 1: m.LEVEL for i, m in enumerate(ORDER)}
