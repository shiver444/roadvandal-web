"""Level 2: PINE TRIP. Autumn forest at golden hour that turns to dusk: falling trees, deer, crossroads with cars from both sides, roadworks."""
from ..config import LS

ZONES = [
    ("PINE ROAD", 0, 0.55),
    ("THE PASS", 3500 * LS, 0.95),
    ("GRIMHOLT", 7300 * LS, 0.75),
]

# what each zone throws at you, in order (so every kind shows up, but the order is not obvious)
EVENTS = [
    ["deer", "wetleaf", "absurd", "faltree", "amb", "deer", "family", "wetleaf", "faltree", "deer", "police", "faltree", "family", "deer", "work"],
    ["wetleaf", "faltree", "deer", "family", "absurd", "wetleaf", "faltree", "police", "deer", "amb", "faltree", "deer", "family"],
    ["ped", "amb", "ped", "police", "ped", "work", "ped", "absurd", "ped", "amb"],
]


def _scen_autumn(zi, r, rng):
    """what stands beside the road: maples and pines in the forest, rocks in the pass, lamps and factories in town"""
    if zi == 0:
        return ("maple" if r < 0.52 else ("pine" if r < 0.90 else "rock")), rng.uniform(16, 34)
    if zi == 1:
        return ("rock" if r < 0.34 else ("pine" if r < 0.74 else "maple")), rng.uniform(25, 55)
    return ("lamp" if r < 0.34 else ("factory" if r < 0.58 else ("maple" if r < 0.82 else "rock"))), rng.uniform(22, 48)


THEME1 = dict(scenery=_scen_autumn, early_tree=True, no_cats=True, dark_file="vicious_dance", dark_song="MianN - Vicious Dance", no_finale_car=True, no_slide=True, tunnel=9000, first_inter=720.0, leaves=True, xcars=True, inter_gap=(1200, 1900), event_pad=230, rail_bases=(), clear_curve=0.82, straight_p=0.12, gap=((420, 700), (420, 700), (380, 620)),
              xcar_kinds=("sedan", "sedan", "sedan", "van", "truck"), start_talker="druid", start_quips=("DON'T EAT THE PURPLE ONES.", "WHATEVER YOU DO... NOT THE PURPLE ONES.", "THE PURPLE ONES, KID. LEAVE THEM.", "PURPLE ONES. DON'T. I'M SERIOUS.", "I'M JUST SAYING: NO PURPLE ONES."), logtrucks=(6350, 7750), stations=("music", "overplayed"), fog=(138, 104, 88), fog_bumps=((5650, 6150), (8000, 8450)), fog_banks_only=True, curve_zones=((10650, 14350, 0.6),), curve_scale=0.55, curve_tau=16.0, curve_look=22.0, curve_blend=32.0)

Y, R, G, P, O = (230, 190, 50), (240, 90, 70), (120, 230, 110), (190, 150, 255), (240, 150, 60)

# the rulebook shown before the countdown (no spoilers!): pages of (icon, colour, heading, detail)
RULES = [
    ("WATCH OUT", [
        ("deer", R, "DEER AND BOARS", "They don't care about your car."),
        ("sign:tree", R, "FALLING TREES   heavy damage", "Watch the warning signs."),
        ("sign:emv", R, "EMERGENCY SCENES   -10 SEC", "Slow down, stay clear."),
        ("none", P, "DON'T EAT THE PURPLE ONES", "That is all we will say.")]),
]


LEVEL = dict(
    name="PINE TRIP", sub="GOLDEN LEAVES, FALLING TREES, ZERO BRAKES.", seed=0, theme=THEME1, locked=False,  trippy=True, unlock_text="UNLOCKS 1 NOVEMBER",
    zones=list(ZONES), events=[list(e) for e in EVENTS],
    rules=RULES,
    info="",
)
