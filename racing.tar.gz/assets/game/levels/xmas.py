"""Level 4: NORTH POLE POSITION (working name). A snowy Christmas night: ice, snowbanks, elf grog stands, elves.
Shell: placeholder hazards from other levels until the real ones are built."""
from ..config import LS

ZONES = [
    ("CANDY CANE LANE", 0, 0.8),
    ("FROZEN LAKE", 5000, 0.9),
    ("ELF TOWN", 9400, 0.7),
    ("THE NORTH POLE", 12300, 0.85),
]

EVENTS = [
    ["deer", "ped", "ped", "deer", "treat", "ghoul", "sand", "ped"],
    ["wetleaf", "deer", "sand", "wetleaf", "ped", "wetleaf", "deer", "ped", "sand", "wetleaf"],
    ["treat", "deer", "sand", "treat", "deer", "treat", "sand", "deer"],          # elf town: elves and reindeer only, no snowmen, no kids
    ["ped", "deer", "wetleaf", "ghoul", "treat", "sand", "deer", "ped", "ped"],
]


def _scen_xmas(zi, r, rng):
    """what stands beside the road (all drawn from the Christmas sprite atlas)"""
    if zi == 0:                                                    # candy cane lane: pines, candy canes, snowmen
        k = "xpine" if r < 0.46 else ("xlamp" if r < 0.64 else ("xsnowman" if r < 0.76 else ("xtree" if r < 0.90 else "xpresents")))
        return k, rng.uniform(16, 34)
    if zi == 1:                                                    # frozen lake: ponds, ice trees, snowbanks
        k = "xbank" if r < 0.30 else ("xicetree" if r < 0.52 else ("xpond" if r < 0.68 else ("xpine" if r < 0.90 else "xsign")))
        return k, rng.uniform(20, 44)
    if zi == 2:                                                    # elf town: cottages, lamps, trees
        k = "xhut" if r < 0.30 else ("xlamp" if r < 0.52 else ("xtree" if r < 0.72 else ("xpresents" if r < 0.84 else ("xsnowman" if r < 0.92 else "xpine"))))
        return k, rng.uniform(18, 38)
    k = "xtree" if r < 0.38 else ("xpine" if r < 0.62 else ("xlamp" if r < 0.80 else ("xhut" if r < 0.90 else "xpresents")))
    return k, rng.uniform(16, 34)


THEME4 = dict(
    night=True, moon=True, sky=True, sky_xmas=True, tod=[(0, (205, 215, 255)), (99999, (200, 212, 255))],
    ground=((214, 224, 238), (204, 216, 232)), road=((78, 80, 96), (72, 74, 90)), haze=(120, 140, 190), haze_k=(0.6, 0.15),
    fog_dist=900.0, fog=(110, 130, 180), ridge=((70, 90, 140), (50, 66, 110)), horizon=((120, 150, 200), (170, 196, 232)),
    edge=((236, 240, 248), (200, 210, 226)), dash=(240, 244, 250), scenery=_scen_xmas,
    ads=["hacker", "nohonk", "gt1", "bron", "gt2", "hacker", "gt1", "nohonk", "bron", "gt2", "hacker", "gt1", "nohonk", "bron"], ad_order=True, no_gas=True, far_hill=True, far_trees=True, sparkle=True, mist=((164, 184, 226), 74, 46, 140, 160), traffic_end=2200.0, one_sled=True, deer_alt="ped", horde_msg="SNOWMEN! SLALOM 'EM ALL!", horde_msg_d=260.0,
    island=("xpine", "xtree", "xsnowman"), lamp=((255, 220, 150), (255, 200, 110)),
    backdrop=(("aurora", -24, 749), ("bg_mount", -24, 749), ("bg_village", -24, 749), ("workshop", 478, 190)), backdrop_grow=dict(workshop=(15850.0, 16590.0, 90, 190, 300.0)), backdrop_lift=dict(aurora=34), backdrop_par=dict(aurora=12, bg_mount=21), traffic_skin=dict(bike="snowmobile", cyclist="skier"), 
    car_colors=[(200, 40, 40), (40, 120, 60), (230, 230, 240), (30, 60, 120), (180, 140, 40)],
    traffic=("sedan", "sedan", "van", "truck"),
    reskin={"deer": (("dr_w0", "dr_w1", "dr_w2", "dr_w3"), ("dr_stand", "dr_graze"), True),
            "zombie": (("sm_f0", "sm_f1", "sm_f2", "sm_f3"), ("sm_f0",), False),
            "ghoul": (("sm_s0", "sm_s1", "sm_s2", "sm_s3"), ("sm_s0",), True),
            "ped": (("kd_r0", "kd_r1", "kd_r2", "kd_r3"), ("kd_r0",), True), "kid": (("kd_r0", "kd_r1", "kd_r2", "kd_r3"), ("kd_r0",), True),
            "costume": (("el_w0", "el_w1", "el_w2", "el_w3"), ("el_stand",), True)},
    reskin_step={"deer": 4, "zombie": 9, "ghoul": 9, "ped": 5, "kid": 5, "costume": 4},
    reskin_h={"deer": 0.8, "zombie": 1.0, "ghoul": 1.0, "ped": 0.65, "kid": 0.9, "costume": 0.6},
    reskin_anim={"deer": (8, 0.03, 0.0), "ped": (10, 0.04, 0.0), "kid": (10, 0.04, 0.0), "costume": (8, 0.04, 0.0), "zombie": (18, 0.0, 0.0), "ghoul": (18, 0.0, 0.0)},
    reskin_sign={"deer": "dr_stand", "zombie": "sm_f0", "ped": "kd_r0", "ghost": "el_stand"},
    impact_text={"deer": "REINDEER!", "zombie": "SNOWMAN!", "ghoul": "SNOWMAN!", "ped": "WATCH IT!", "kid": "SNOWBALL KID!", "costume": "THAT WAS AN ELF!"},
    xmas_finish=True, naughty_list=True, finale_bend=(580.0, -1.0, 100.0), finale_hill=(1800.0, 820.0, 100.0, 50.0, 90.0), finale_ice=0.7, start_talker="elf", start_quips=("DON'T GET HOOKED ON ELF GROG.",), snow_throw=True, snow_lines=True, no_tow=True, throw_areas=(330.0, 1700.0, 4700.0, 9800.0, 10900.0, 11900.0), throwers=True, splat_msg="SNOWBALL SPLAT - SLIPPERY!", ped_elf=1.0, elf_types=True, elf_mug_from=9400.0, ice_patch=(168, 204, 232), drift_sprites=True, drift_msg="SNOWDRIFT!", wet_msg="BLACK ICE - SLIPPERY!", honk_peds=True, cp_clear=260.0, xmas_traffic=True, no_hearse=True, no_finale_family=True, glyph_txt={"sand": "SNOWDRIFT", "slip": "BLACK ICE"}, no_cats=True, no_overpass=True, bike_cut=(0.46, 0.52), grog_at=(5900.0, 12700.0), carol_at=(3300.0, 10100.0, (-130.0, -1, True)), drift_sound="snow_whoosh",
    snow=True, ice=((2400.0, 4600.0), (6200.0, 8600.0), (13000.0, 15000.0)),
    music="music", stations=("music", "carol_radio", "elf_radio"), dark_file="the_hacker", dark_song="MianN - The Hacker", gap=((300, 520), (300, 520), (300, 520), (300, 520)), clear_curve=0.82, no_cross=True, no_fork=True, no_slide=True, no_finale_car=True,
    rail_bases=(), town="CANDY CANE LANE", hill="THE NORTH POLE", radio="DARK.FM")

Y, R, G, P, O = (230, 190, 50), (240, 90, 70), (120, 230, 110), (190, 150, 255), (240, 150, 60)

RULES = [
    ("WINTER ROAD", [
        ("sign:slip", R, "BLACK ICE   very slippery", "Steer early, brake gently."),
        ("sign:sand", R, "SNOWDRIFTS", "Slow and slippery."),
        ("none", R, "SNOWBALL KIDS", "Keep your eyes open."),
        ("none", R, "REINDEER AND SNOWMEN", "They cost seconds and damage.")]),
    ("ELVES AND GROG", [
        ("sign:ped", R, "ELVES CROSSING", "Honk to warn them."),
        ("none", G, "ELF GROG STAND", "Pass close on his side."),
        ("none", R, "CAROLERS", "Let them sing. Don't hit them.")]),
]

LEVEL = dict(
    name="NORTH POLE POSITION", sub="SNOW, ICE AND A LOT OF ELF GROG.", seed=23, theme=THEME4, locked=True, unlock_text="COMING SOON", unlock_at=1796079600, xmas=True, new=True,
    zones=list(ZONES), events=[list(e) for e in EVENTS],
    rules=RULES,
    info="",
)
