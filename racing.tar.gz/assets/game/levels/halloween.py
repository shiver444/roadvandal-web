"""Level 1: HALLO-VANDALISM. Pure data: zones, what happens in each, and the look of the level."""
from ..config import LS


def _scen2(zi, r, rng):
    """halloween roadside: what stands beside the road in each zone"""
    if zi == 0:                                              # dead hollow: a dark wood
        kind = "deadtree" if r < 0.5 else ("pine" if r < 0.72 else ("pumpkin" if r < 0.84 else ("gravestone" if r < 0.94 else "rock")))
        return kind, rng.uniform(16, 34)
    if zi == 1:                                              # graveyard shift
        kind = ("gravestone" if r < 0.42 else ("deadtree" if r < 0.62 else ("pumpkin" if r < 0.74 else
                ("lamp" if r < 0.84 else ("crypt" if r < 0.90 else "rock")))))
        return kind, rng.uniform(14, 30)
    kind = "lamp" if r < 0.28 else ("house" if r < 0.38 else ("deadtree" if r < 0.60 else ("pumpkin" if r < 0.80 else "gravestone")))
    return kind, rng.uniform(20, 42)                         # haunted hill


THEME2 = dict(
    night=True, moon=True, sky=True, tod=[(0, (200, 200, 255)), (99999, (196, 196, 252))],
    ground=((16, 20, 22), (20, 26, 26)), road=((70, 68, 84), (64, 62, 78)), haze=(54, 40, 84), haze_k=(0.95, 0.2),
    fog_dist=430.0, fog_bump=(8500.0, 12700.0), fog=(58, 44, 88), ridge=((34, 22, 54), (20, 14, 34)), horizon=((80, 56, 110), (120, 86, 150)),
    edge=((196, 204, 150), (150, 160, 112)), dash=(206, 212, 170), lightning=True, scenery=_scen2,
    ads=["crowbar", "fm", "funeral", "crowbar"],
    island=("gravestone", "deadtree", "pumpkin"), lamp=((150, 232, 170), (110, 255, 150)),
    car_colors=[(30, 30, 36), (70, 40, 90), (120, 40, 40), (40, 70, 60), (200, 190, 170), (90, 90, 100), (180, 100, 30)],
    traffic=("sedan", "sedan", "hearse", "van", "truck"), witch=True, slide_banner="STEEP DESCENT - FOG",
    music="music", gap=((300, 520), (230, 400), (300, 520)), start=760.0, ambient=True, bats=True, opener=True,
    mud=(2300 * LS + 60, 5600 * LS - 80), slide_range=(10500, 14500), slide_target=12000, first_straight=170 * LS, straight_p=0.12, clear_curve=0.82, fear=(), witch_at=(5300.0, 12300.0), bend_len=(120, 220), alt_p=0.92, flip=True, slide_extra=120.0, slide_min=170, throwers=True, rail_bases=(4700.0, 6900.0), extra_time=0.0, cp_bonus=16.0, cp_after_slide=True, rail_curve=0.7, bb_curve=0.75, spiders=True, ghost_train=True,
    train_slogans=(), crow=True, no_cross=True, no_fork=True, town="GRAVE ROAD", hill="HANGMAN'S HILL", radio="HAUNTED RADIO")


Y, R, G, P, O = (230, 190, 50), (240, 90, 70), (120, 230, 110), (190, 150, 255), (240, 150, 60)

# the rulebook shown before the countdown: pages of (icon, colour, heading, detail). Shown after the basics page.
RULES = [
    ("GOOD AND BAD", [
        ("zombie", G, "ZOMBIES   +1 SEC each", "Drive into them."),
        ("witchland", G, "THE GOOD WITCH   +8 sec and repairs", "Drive beside her."),
        ("cat", R, "CATS, PEOPLE, OTHER CARS", "They cost seconds and damage."),
        ("train", R, "THE TRAIN   huge damage", "Bell and red lights: brake.")]),
]


LEVEL = dict(
    name="HALLO-VANDALISM", sub="DEAD HOLLOW  >  GRAVE ROAD  >  HANGMAN'S HILL", seed=7, theme=THEME2, locked=False, spooky=True, track="MianN - Never Alone",
    zones=[("DEAD HOLLOW", 0, 0.9), ("GRAVE ROAD", 2300 * LS, 0.8), ("HANGMAN'S HILL", 5600 * LS, 0.95)],
    events=[["horde", "ghost", "costume", "work", "horde", "ghost", "costume"],
            ["ghoul", "ghoul", "horde", "ghoul", "costume", "ghoul", "ghost", "horde", "ghoul"],
            ["treat", "ghost", "treat", "horde", "work", "costume", "bats", "coffin", "treat", "horde"]],
    rules=RULES,
    info="fog, ghosts to drive through, costumed people to avoid",
)
