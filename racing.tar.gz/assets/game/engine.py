"""
The racing engine: pseudo-3D road, car handling, hazards, HUD, menus.
Levels live in game/levels/ (one file each) and are only data: road zones, events and a theme.
"""
import bisect
import math
import random
import sys

import pygame
import json
import os
import asyncio
import types
from . import car_sprite
from . import crow_sprite
from . import webtouch
from . import audio
from . import sprites
from . import config
from . import scores
try:
    from . import master_sprite
except ImportError:
    master_sprite = None

pygame.init()
W, H = 700, 500
screen = pygame.display.get_surface() or pygame.display.set_mode((W, H), pygame.SCALED)      # SCALED: fullscreen stretches evenly, keeps the shape
pygame.display.set_caption(config.TITLE)
clock = pygame.time.Clock()
_FONT_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "FreeMonoBold.ttf")


def _font(size):
    if sys.platform == "emscripten":                         # the browser has no system fonts: use the one shipped with the game
        try:
            return pygame.font.Font(_FONT_FILE, size + 2)
        except Exception:
            pass
    try:
        return pygame.font.SysFont("monospace", size, bold=True)
    except Exception:                                        # web builds have no system fonts
        return pygame.font.Font(None, size + 6)


def _face(name, size, fallback):
    try:
        return pygame.font.Font(os.path.join(os.path.dirname(_FONT_FILE), name), size)
    except Exception:
        return fallback


font = _font(13)
font_mid = _font(18)
font_big = _face("RubikSprayPaint-Regular.ttf", 38, _font(40))      # headings: spray-paint look
font_title = _face("RubikDirt-Regular.ttf", 54, _font(40))          # ROAD VANDAL logo: gritty
font_spook = _face("RubikWetPaint-Regular.ttf", 28, font_mid)       # HALLO-VANDALISM: dripping paint


def level_name(L, x, y):
    """Level name under the logo; the Halloween level gets dripping orange paint with a purple glow."""
    if L.get("spooky"):
        for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (0, 3)):
            sf = font_spook.render(L["name"], True, (90, 30, 140))
            screen.blit(sf, (x - sf.get_width() // 2 + dx, y + dy))
        sf = font_spook.render(L["name"], True, (255, 130, 20))
        screen.blit(sf, (x - sf.get_width() // 2, y))
    elif L.get("trippy"):
        for dx, col in ((-3, (230, 60, 170)), (3, (60, 220, 200))):
            sf = font_big.render(L["name"], True, col)
            screen.blit(sf, (x - sf.get_width() // 2 + dx, y + 2))
        text(L["name"], font_big, (255, 190, 70), x, y, "center")
    else:
        text(L["name"], font_mid, (240, 200, 70), x, y, "center")

# ------------------------------------------------------------------ view
HORIZON_BASE = int(H * 0.30)
ROAD_L, ROAD_R = 70, 630        # road edges at the bottom of the screen: the whole road and the car stay in view
VAN_W = 28                      # half road width at the vanishing point
Z1 = 8.0                        # metres from camera to the bottom-of-screen ground point
DRAW_DIST = 520.0 if sys.platform == "emscripten" else 700.0               # how far ahead we draw (metres)
M_PER_FRAME = 1.8               # metres per frame at full speed (108 m/s) - fast enough to feel like 260
KMH = 260                       # HUD speed at full throttle

# ------------------------------------------------------------------ car feel (locked in)
# engine: strong pull off the line, fading towards top speed (like real drag-limited acceleration),
# with a short power dip at every gear change. 0->200 km/h takes ~9 s, full 260 takes ~14 s.
ACCEL_TOP, ACCEL_FADE = 0.0058, 0.0008      # accel = TOP - FADE*speed  (per frame)
GEARS = 6
SHIFT_FRAMES = 6
SHIFT_POWER = 0.45
# rolling resistance + air drag: lifting off at full speed sheds ~half the speed in ~5 s, a slow roll lasts long
DRAG_ROLL, DRAG_AIR = 0.0008, 0.0016
# brakes: pedal pressure builds over ~0.4 s, full stop from top speed takes ~3.5 s, grip fades near standstill
BRAKE_BUILD = 0.05
BRAKE_MAX = 0.0055
BRAKE_LOW_GRIP = 0.45
# steering: the wheel turns gradually (slower at speed), lets go faster than it turns in, and the car only
# follows through tyre grip: it needs speed to turn, answers lazily at first, and slides more when fast.
WHEEL_IN = 0.13                 # wheel travel per frame while a key is held (at standstill)
WHEEL_IN_FAST = 0.085          # ... at full speed (heavier, more deliberate)
WHEEL_OUT = 0.17                # self-centring when you let go
STEER_MAX = 7.4                 # max sideways px/frame at full lock
STEER_MIN_SPEED = 0.08          # below this the car barely turns
GRIP_SLOW, GRIP_FAST = 0.34, 0.20   # how quickly sideways motion follows the wheel (lower = more slide)
CURVE_PUSH = 2.4
OFF_CAP = 0.30                  # off road you slow down to this, never to a dead stop
OFF_DRAG = 0.02

# ------------------------------------------------------------------ level
# name, starts at (m), strongest curve allowed in the zone
LVL_SEED = 0                     # different seed per level -> different road
LEVEL = 1
THEME = {}                       # look and content of the current level (empty = the pine road level)
BESTS = {}
LS = config.LS                   # level length scale (faster car -> longer road, same ~3 min run)
from .levels import level1 as _level1
ZONES = list(_level1.ZONES)                   # defaults, replaced by build_world() for the chosen level
LEVEL_TARGET = 10500 * LS


START_TIME = 50.0               # seconds on the clock at the start
CP_BONUS = 38.0                 # seconds added at every checkpoint
CP_REPAIR = 25.0                # damage repaired at every checkpoint
CHECKPOINTS = [LEVEL_TARGET * k / 6.0 for k in range(1, 6)]
DAMAGE = {"cone": 2, "barrier": 30, "worker": 14, "smoker": 14, "sleeper": 14, "ped": 14, "kid": 16, "deer": 18, "cat": 6,
          "car": 20, "train": 45, "costume": 12, "coffin": 24, "pumpkin": 2, "gravestone": 24, "zombie": 1, "bat": 2, "witch": 14, "tomb": 22, "ghoul": 10, "xcar": 24, "faltree": 26, "boar": 22, "piglet": 8, "emv": 26, "rock": 16, "log": 24}
DAMAGE_SPEED_LOSS = 0.30        # at 100% damage the car tops out 30% lower


def zone_index(s):
    idx = 0
    for k, z in enumerate(ZONES):
        if s >= z[1]:
            idx = k
    return idx


TUNNEL = None                                           # (start, end) of the tunnel, if this level has one
RADIO_S = None                                          # where the police stop just after the tunnel is (its radio chatter plays around it)


def build_level():
    global TUNNEL, RADIO_S
    TUNNEL = None
    RADIO_S = None
    """List of (start_m, length_m, curve, hill). Fixed seed = same level every run."""
    rng = random.Random(1994 + LVL_SEED)
    first = THEME.get("first_straight", 500.0 * LS)
    secs = [(0.0, first, 0.0, 0.0)]
    s = first
    side = 1
    rm = lm = 0.0                                       # metres of right / left curves so far (keep them balanced)
    while s < LEVEL_TARGET:
        zi = zone_index(s)
        maxc = ZONES[zi][2]
        if rng.random() < THEME.get("straight_p", 0.28):
            length, curve, hill = rng.uniform(220, 420) * LS, 0.0, rng.uniform(-0.1, 0.2)
        else:
            if THEME.get("flip"):
                side = -side                            # strictly left, right, left...: no long one-way bend that looks like a slanted straight
            elif rng.random() < THEME.get("alt_p", 0.8):
                side = -1 if rm > lm else 1             # next bend goes to the side that has had fewer metres
            mag = rng.uniform(0.4 * maxc, maxc)
            length = rng.uniform(*THEME.get("bend_len", (200, 340))) * LS
            if zi == 1 and rng.random() < 0.2:          # hairpin, only in the pass
                mag, length = maxc * 1.1, rng.uniform(110, 160) * LS
            curve, hill = side * mag, rng.uniform(-0.25, 0.25)
        secs.append((s, length, curve, hill))
        if curve > 0:
            rm += length
        elif curve < 0:
            lm += length
        s += length
    secs.append((s, 450.0 * LS, 0.0, 0.0))
    s += 450.0 * LS
    # one long, strong left-hander in the pass that also drops downhill (the car slides through it)
    cands = [i for i, (s0, ln, c, h) in enumerate(secs) if c < -0.4 and ln >= THEME.get("slide_min", 280) and THEME.get("slide_range", (5800, 10000))[0] <= s0 <= THEME.get("slide_range", (5800, 10000))[1]]
    slide = None
    if cands and not THEME.get("no_slide"):
        i = min(cands, key=lambda i: abs(secs[i][0] - THEME.get("slide_target", 8200)))
        s0, ln, c, h = secs[i]
        ln += THEME.get("slide_extra", 300.0)            # a long mountain descent: climb to a crest, then all the way down
        secs[i] = (s0, ln, -1.0, -1.1)
        if i > 0:
            ps0, pln, pc, _ph = secs[i - 1]
            secs[i - 1] = (ps0, pln, pc, 0.9)           # rise before the crest
        pos = s0 + ln
        for j in range(i + 1, len(secs)):               # everything after moves back by the added length
            _a, jl, jc, jh = secs[j]
            secs[j] = (pos, jl, jc, jh)
            pos += jl
        s = pos
        slide = (s0, s0 + ln)
    if THEME.get("tunnel"):                              # one long straight, flat stretch for the tunnel
        tgt = THEME["tunnel"]
        i = min(range(1, len(secs) - 1), key=lambda i: abs(secs[i][0] + secs[i][1] / 2.0 - tgt))
        s0, ln, c, h = secs[i]
        ln = max(ln, 760.0)
        secs[i] = (s0, ln, 0.0, 0.0)
        pos = s0 + ln
        for j in range(i + 1, len(secs)):
            _a, jl, jc, jh = secs[j]
            secs[j] = (pos, jl, jc, jh)
            pos += jl
        s = pos
        TUNNEL = (s0 + 150.0, s0 + ln - 60.0)
    return secs, s, slide


SECS, LEVEL_LEN, SLIDE = build_level()


def slide_k(pos):
    """0..1: how slippery the road is under the car (ramps in and out)"""
    if SLIDE is None:
        return 0.0
    return max(0.0, min(1.0, (pos - SLIDE[0] + 10) / 80.0, (SLIDE[1] + 40 - pos) / 80.0))
SEC_STARTS = [sec[0] for sec in SECS]


def mud_k(pos):
    """0..1: how deep in the muddy graveyard road the car is (ramps in and out)"""
    m = THEME.get("mud")
    if not m:
        return 0.0
    return max(0.0, min(1.0, (pos - m[0]) / 60.0, (m[1] - pos) / 60.0))


def curve_target(pos):
    """the bend the camera should be turning into. a level can look a little ahead and ramp into the next section's bend over its last stretch
    (THEME curve_look / curve_blend, metres), so the road does not lag behind the camera on S-bends"""
    look, tw = THEME.get("curve_look", 0.0), THEME.get("curve_blend", 0.0)
    sc = THEME.get("curve_scale", 1.0)                      # how strongly the picture bends: the S-bends of a level can be made gentler to look at
    for z0, z1, zs in THEME.get("curve_zones", ()):          # calmer camera in busy stretches (fork, wide road)
        if z0 - 150 < pos < z1 + 150:
            f = min(1.0, (pos - z0 + 150) / 300.0, (z1 + 150 - pos) / 300.0)
            sc *= 1.0 + (zs - 1.0) * f * f * (3.0 - 2.0 * f)
    p = pos + look
    i = max(0, min(len(SECS) - 1, bisect.bisect_right(SEC_STARTS, p) - 1))
    cur = SECS[i][2]
    if tw > 0.0 and i + 1 < len(SECS):
        d = SECS[i][0] + SECS[i][1] - p
        if d < tw:
            x = max(0.0, min(1.0, 1.0 - d / tw))
            return (cur + (SECS[i + 1][2] - cur) * x * x * (3.0 - 2.0 * x)) * sc
    return cur * sc


def section_at(s):
    i = max(0, min(len(SECS) - 1, bisect.bisect_right(SEC_STARTS, s) - 1))
    return SECS[i]


def build_scenery():
    rng = random.Random(77 + LVL_SEED)
    out = []

    # warning signs before the hard corners
    for (s0, length, curve, hill) in SECS:
        if abs(curve) >= 0.7:
            d = 1 if curve > 0 else -1
            dists = (190 * LS, 90 * LS) if abs(curve) >= 0.95 else (190 * LS,)
            for back in dists:
                if s0 - back > 20:
                    out.append(dict(s=s0 - back, side=-d, kind="sign", dir=d, off=12, k=1.0))

    s = 60.0
    while s < LEVEL_LEN - 120:
        zi = zone_index(s)
        side = rng.choice((-1, 1))
        r = rng.random()
        k = rng.uniform(0.8, 1.25)
        if THEME.get("scenery"):
            kind, step = THEME["scenery"](zi, r, rng)
        elif zi == 0:
            kind = "pine" if r < 0.88 else "rock"
            step = rng.uniform(16, 34)
        elif zi == 1:
            kind = "deadtree" if r < 0.30 else ("rock" if r < 0.70 else "pine")
            step = rng.uniform(25, 55)
        else:
            kind = "lamp" if r < 0.40 else ("factory" if r < 0.70 else ("deadtree" if r < 0.85 else "rock"))
            step = rng.uniform(22, 48)
        o = dict(s=s, side=side, kind=kind, k=k, off=rng.uniform(6, 90))
        if kind in ("pine", "maple", "deadtree"):
            o["off"] = max(o["off"], 15.0 if kind != "maple" else 11.0)                       # a tree never stands on the road, crown and all
        if kind == "lamp":
            o["off"] = 10
        if kind in ("pumpkin", "gravestone"):
            o["off"] = rng.uniform(3, 44)
            o["v"] = rng.randint(0, 2)
        if kind == "factory":
            o.update(off=rng.uniform(50, 170), w=rng.uniform(180, 280), h=rng.uniform(110, 190),
                     lit=[rng.random() < 0.4 for _ in range(8)])
            step += 60
        if kind == "house":
            o.update(off=rng.uniform(50, 150), w=rng.uniform(190, 270), h=rng.uniform(150, 230),
                     lit=[rng.random() < 0.45 for _ in range(8)])
            step += 90
        if kind == "crypt":
            o.update(off=rng.uniform(30, 90), w=rng.uniform(100, 150), h=rng.uniform(70, 110), lit=[False] * 8)
            step += 50
        out.append(o)
        s += step

    # billboards, filling stations and overpasses
    brng = random.Random(333 + LVL_SEED)
    ads = THEME.get("ads", ["crowbar", "circus", "assholism", "fm"])
    bag = []
    s = 1100.0
    while s < LEVEL_LEN - 500:
        if not bag:
            bag = ads[:]
            brng.shuffle(bag)
        # only on straights, so the board is in view for a long way before you reach it
        lim = s + 1000
        while s < lim and (max(abs(section_at(s - d)[2]) for d in range(-10, 281, 40)) > THEME.get("bb_curve", 0.42)
                           or near_intersection(s, 160) or near_fork(s, 200)):
            s += 30
        if s < LEVEL_LEN - 500 and s < lim:
            out.append(dict(s=s, side=brng.choice((-1, 1)), kind="billboard", off=brng.uniform(7, 12), k=1.0,
                            ad=bag.pop(), phone="555-%04d" % brng.randint(100, 9899)))
        s += brng.uniform(650, 1000)
    for base in (2600.0, 6500.0, 9800.0, 14600.0):                 # filling stations
        gs = base + brng.uniform(0, 200)
        if not (near_intersection(gs, 150) or near_fork(gs, 200)):
            out.append(dict(s=gs, side=brng.choice((-1, 1)), kind="gas", off=brng.uniform(26, 40), k=1.0))
    for base in (4300.0, 8600.0, 12300.0):                          # overpasses
        os_ = _clear_spot(base + brng.uniform(0, 300))
        for _ in range(30):
            if not (near_intersection(os_, 260) or near_fork(os_, 300)):
                break
            os_ = _clear_spot(os_ + 80)
        out.append(dict(s=os_, side=0, kind="overpass", off=0, k=1.0))

    # keep the view to a billboard / station clear of trees on its side
    props = [(o["s"], o["side"]) for o in out if o["kind"] in ("billboard", "gas")]
    out = [o for o in out if not (o["kind"] in ("pine", "deadtree", "rock", "lamp", "factory", "house", "crypt", "pumpkin", "gravestone") and
                                  any(sd == o["side"] and ps - 140 < o["s"] < ps + 20 for ps, sd in props))]
    if THEME.get("mud"):
        m0, m1 = THEME["mud"]
        out = [o for o in out if not (o["kind"] in ("overpass", "gas", "billboard") and m0 - 100 < o["s"] < m1 + 100)]
        out.append(dict(s=m0 + 10.0, side=0, kind="gate", off=0, k=1.0))
        grng = random.Random(333 + LVL_SEED)
        fs = m0 + 30.0
        while fs < m1 + 40:                                          # iron fence along both sides of the cemetery road
            for sd in (-1, 1):
                out.append(dict(s=fs, side=sd, kind="fence", off=4.0, k=1.0))
            fs += 11.0
        gs = m0 - 1000.0                                             # the woods turn into a graveyard bit by bit
        while gs < m0:
            if grng.random() < (gs - (m0 - 1000.0)) / 1000.0 * 0.9:
                out.append(dict(s=gs, side=grng.choice((-1, 1)), kind="gravestone", k=grng.uniform(0.8, 1.2), off=grng.uniform(8, 40), v=grng.randint(0, 2)))
            gs += 22.0
        gs = m0
        while gs < m1:                                               # rows of stones, crosses, crypts and lanterns
            r_ = grng.random()
            kind = "gravestone" if r_ < 0.70 else ("crypt" if r_ < 0.76 else ("lamp" if r_ < 0.86 else "deadtree"))
            o_ = dict(s=gs, side=grng.choice((-1, 1)), kind=kind, k=grng.uniform(0.85, 1.25), off=grng.uniform(9, 55))
            if kind == "gravestone":
                o_["v"] = grng.randint(0, 2)
            if kind == "crypt":
                o_["w"] = grng.uniform(60, 90)
                o_["h"] = grng.uniform(70, 100)
                o_["off"] = grng.uniform(20, 70)
            out.append(o_)
            gs += grng.uniform(6, 13)
        for fsx in THEME.get("fear", ()):
            pass
    if SLIDE is not None:
        for back in (460.0, 210.0):
            out.append(dict(s=SLIDE[0] - back, side=-1, kind="sign", dir=0, off=12, k=1.0, glyph="slip"))
    out.append(dict(s=LEVEL_LEN, side=0, kind="finish", off=0, k=1.0))
    out.sort(key=lambda o: o["s"])
    return out



# ------------------------------------------------------------------ hazards
PXM = 78.0                       # screen px per metre at the bottom of the screen (the car is ~1.9 m = 148 px)
WIDTH_M = {"tomb": 0.9, "barrier": 4.2, "sleeper": 1.4, "cat": 0.95, "deer": 2.1, "boar": 2.0, "piglet": 0.9, "coffin": 1.2}
# speed kept after an impact, and what the HUD shouts
IMPACT = {"cone": (0.88, "CONE!"), "barrier": (0.18, "ROADWORKS!"), "worker": (0.45, "WATCH THE WORKERS!"),
          "smoker": (0.45, "HE WAS ON BREAK!"), "sleeper": (0.4, "WAKE UP CALL!"), "ped": (0.45, "PEDESTRIAN!"),
          "kid": (0.5, "WATCH IT!"), "deer": (0.3, "DEER!"), "cat": (0.82, "POOR KITTY!"),
          "costume": (0.45, "THAT WAS A PERSON!"), "zombie": (0.95, "ZOMBIE!"), "bat": (0.98, "BAT!"), "witch": (0.5, "YOU HIT THE GOOD WITCH!"), "tomb": (0.22, "TOMBSTONE!"), "ghoul": (0.7, "GHOUL!"), "coffin": (0.3, "COFFIN!"), "pumpkin": (0.88, "SPLAT!"),
          "xcar": (0.22, "T-BONED!"), "faltree": (0.20, "FALLEN TREE!"), "rock": (0.30, "ROCKFALL!"),
          "boar": (0.3, "BOAR!"), "piglet": (0.55, "OH NO, PIGLETS!"), "emv": (0.2, "EMERGENCY SCENE!")}
HALF_W = {"cone": 0.05, "barrier": 0.43, "worker": 0.08, "smoker": 0.08, "sleeper": 0.17, "ped": 0.08,
          "kid": 0.07, "deer": 0.22, "cat": 0.05, "costume": 0.08, "coffin": 0.22, "ghost": 0.14, "pumpkin": 0.07, "zombie": 0.08, "bat": 0.11, "witch": 0.17, "tomb": 0.10, "ghoul": 0.09, "pad": 1.2, "spider": 0.12, "web": 0.7, "xcar": 0.46, "faltree": 0.7, "rock": 0.26, "wetleaf": 0.05, "boar": 0.2, "piglet": 0.1, "emv": 0.40, "shroom": 0.12, "druid": 0.08}
CROSSWALKS = []


def section_at_calm(s):
    return max(abs(section_at(s)[2]), abs(section_at(s - 150)[2]), abs(section_at(s + 80)[2])) <= THEME.get("clear_curve", 0.62)


def _clear_spot(s):
    """push an event forward until it sits on a calm straight"""
    while max(abs(section_at(s)[2]), abs(section_at(s - 150)[2]), abs(section_at(s + 80)[2])) > THEME.get("clear_curve", 0.62):
        s += 40
    return s


def _calm_near(s, reach=200.0, lim=None):
    """nearest calm straight within `reach` metres of s (either side), or None"""
    lim = THEME.get("clear_curve", 0.62) if lim is None else lim
    d = 0.0
    while d <= reach:
        for c in (s + d, s - d):
            if max(abs(section_at(c)[2]), abs(section_at(c - 150)[2]), abs(section_at(c + 80)[2])) <= lim:
                return c
        d += 20.0
    return None


def _gap_spot(out, base, need, skip_kinds=("ghost", "thrower", "pshot")):
    """middle of the first stretch after `base` that has no event for `need` metres"""
    pts = [h["s"] for h in out if h.get("hz") and h["kind"] not in skip_kinds]
    for b in THEME.get("rail_bases", ()):
        pts += [b - 560.0, b + 300.0]
    pts = sorted(pts)
    for a, b in zip(pts, pts[1:]):
        if b - a >= need and (a + b) / 2.0 >= base:
            c_ = _calm_near((a + b) / 2.0, lim=1.0)
            if c_ is not None:
                return c_
    return None


def _hz(kind, s, lx, **kw):
    o = dict(hz=True, kind=kind, s=s, lx=lx, side=0, off=0, k=1.0, hw=HALF_W.get(kind, 0.08), solid=True,
             hit=False, hit_t=0, vx=0.0, trig=None, started=False, lx_end=None, anim=0, face=1, bob=0,
             plan=None, pi=0, pause_t=0, moving=False, vx_hit=0.0)
    o.update(kw)
    o["_init"] = dict(lx=o["lx"], vx=o["vx"], trig=o["trig"], solid=o["solid"], anim=o["anim"], face=o["face"], plan=o["plan"], s=o["s"])
    return o


def reset_hazards():
    """put every hazard back as the level builds it (called whenever a run starts)"""
    for o in HAZ:
        o.update(o["_init"])
        o["dust"] = 0
        o["hit"] = False
        o["hit_t"] = 0
        o["started"] = False
        o["pi"] = 0
        o["pause_t"] = 0
        o["moving"] = False
        o["spooked"] = False
        o.pop("awake", None)
        if "yielded" in o:
            o["yielded"] = 0
        o["knock_t"] = 0
        o["used"] = False
        o["chill"] = 0
        if o["kind"] == "spider":
            o["alt"] = 1.0
        if o["kind"] in ("faltree", "rock"):
            o["fall"] = 0.0
            o.pop("landed", None)
        if o["kind"] == "ghoul":
            o["rise"] = 0.0
        if o["kind"] == "thrower":
            o["throws"], o["nextt"] = 0, 0
        if o["kind"] == "pshot":
            o["u"] = 1.0 if o["ph0"] == "splat" else 0.0
            o["phase"] = o["ph0"]
        if o["kind"] == "witch":
            o["alt"], o["wait"], o["leaving"], o["solid"], o["helped"] = 1.0, 0, False, False, False
        if "hi" in o:
            HAZ_S[o["hi"]] = o["s"]
            OBJ_S[o["oi"]] = o["s"]


def _warn(s, glyph, rng):
    return dict(s=s, side=rng.choice((-1, 1)), kind="sign", dir=0, off=12, k=1.0, glyph=glyph)


STREET_HALF = 9.0                # a cross street is 18 m deep
INTERSECTIONS = []


def build_intersections():
    rng = random.Random(8080 + LVL_SEED)
    out = []
    if THEME.get("no_cross"):                       # this level has no side streets
        return out
    s = THEME.get("first_inter", 1500.0)
    while s < LEVEL_LEN - 900:
        s = _clear_spot(s)
        if TUNNEL and TUNNEL[0] - 500 < s < TUNNEL[1] + 160:
            s = TUNNEL[1] + 200.0
            continue
        out.append(s)
        s += rng.uniform(*THEME.get("inter_gap", (1900, 3100)))
    return out


INTERSECTIONS = build_intersections()


def near_intersection(s, pad):
    for i in INTERSECTIONS:
        if abs(s - i) < pad:
            return True
    return False


# ---- forks: the road splits into two roadways round an island, then joins up again
FORK_LEN = 720.0
FORK_RAMP = 130.0
FORK_MAX = 0.30                  # island half-width as a fraction of the road half-width


def build_forks():
    rng = random.Random(6161 + LVL_SEED)
    out = []
    if THEME.get("no_fork"):                          # no split road with an island in this level
        return out
    s = 6600.0
    while s < LEVEL_LEN - 1500 and not out:
        ok = False
        while not ok and s < LEVEL_LEN - 1500:
            ok = all(abs(section_at(s + d)[2]) < 0.66 for d in range(-100, int(FORK_LEN) + 100, 100))
            if ok and any(-200 < i - s < FORK_LEN + 200 for i in INTERSECTIONS):
                ok = False
            if ok and TUNNEL and s < TUNNEL[1] + 300 and s + FORK_LEN > TUNNEL[0] - 800:
                ok = False                                # not on top of the tunnel
            if not ok:
                s += 60
        if ok:
            out.append(s)
        s += FORK_LEN + rng.uniform(2300, 3600)
    return out


FORKS = build_forks()

# ---- wide sections: the road doubles up into a four-lane highway (two roads side by side)
WIDE_MAX = 2.0                   # far-field width multiple in a four-lane stretch (the near edge stays on screen)
WIDE_RAMP = 140.0
WIDE_FAR = 2.1                   # half-width at the horizon, times the standard one
WIDE_NEAR = 1.17                 # half-width at the bottom of the screen, times the standard one


def build_wides():
    """list of (start, length): long four-lane stretches, standard road in between (Road Rash style)"""
    rng = random.Random(3131 + LVL_SEED)
    out = []
    s = 1800.0
    while s < LEVEL_LEN - 2500:
        length = rng.uniform(1400.0, 2300.0)
        if TUNNEL and s < TUNNEL[1] + 300 and s + length > TUNNEL[0] - 800:
            s = TUNNEL[1] + 300.0                       # a four-lane stretch never swallows the tunnel
            continue
        # never straddle the island fork
        if any(f - 250 < s + length and s - 250 < f + FORK_LEN for f in FORKS):
            s = max(s, max(f + FORK_LEN + 250 for f in FORKS if f - 250 < s + length))
            continue
        out.append((s, length))
        s += length + rng.uniform(1500.0, 2600.0)
    return out


WIDES = build_wides()


def wide_f(sw):
    for (w0, wl) in WIDES:
        u = sw - w0
        if 0 <= u <= wl:
            if u < WIDE_RAMP:
                k = u / WIDE_RAMP
            elif u > wl - WIDE_RAMP:
                k = (wl - u) / WIDE_RAMP
            else:
                k = 1.0
            k = k * k * (3 - 2 * k)
            return 1.0 + (WIDE_MAX - 1.0) * k
    return 1.0


def wide_k(sw):
    """0 standard road .. 1 full four-lane road"""
    return (wide_f(sw) - 1.0) / (WIDE_MAX - 1.0)


def near_wide(s, pad):
    return False


def fork_w(sw):
    """island half-width (fraction of the road) at world distance sw; 0 when there is no fork"""
    for f in FORKS:
        u = sw - f
        if 0 <= u <= FORK_LEN:
            if u < FORK_RAMP:
                return FORK_MAX * u / FORK_RAMP
            if u > FORK_LEN - FORK_RAMP:
                return FORK_MAX * (FORK_LEN - u) / FORK_RAMP
            return FORK_MAX
    return 0.0


def near_fork(s, pad):
    for f in FORKS:
        if f - pad < s < f + FORK_LEN + pad:
            return True
    return False


# ---- movement plans: list of (target lx, speed per frame, pause frames afterwards)
DEER_MODES = ["road", "cross", "balk", "road", "stay", "cross", "balk", "road"]


def _deer_plan(rng, side, mode):
    """returns (start_lx, plan, trig). side = which edge it waits on."""
    r = {"cross": 0.1, "balk": 0.4, "stay": 0.6, "road": 0.9}[mode]
    if r < 0.32:                                        # classic: runs across
        return 1.4 * side, [(-1.5 * side, 0.020, 0)], rng.uniform(64, 90)
    if r < 0.52:                                        # starts out, loses its nerve, jumps back
        mid = side * rng.uniform(0.85, -0.2)
        return 1.4 * side, [(mid, 0.022, rng.randint(15, 45)), (1.5 * side, 0.032, 0)], rng.uniform(90, 135)
    if r < 0.64:                                        # just stands at the roadside
        return 1.32 * side, None, None
    # standing ON the road, nobody knows what it'll do
    lx0 = rng.uniform(-0.55, 0.55)
    d = 1 if lx0 >= 0 else -1
    q = rng.random()
    if q < 0.30:
        plan = [(1.5 * d, 0.030, 0)]                    # bolts to the near side
    elif q < 0.50:
        plan = [(-1.5 * d, 0.026, 0)]                   # bolts across to the far side
    elif q < 0.70:
        plan = [(lx0 + 0.45 * d, 0.030, rng.randint(10, 25)), (lx0 - 0.25 * d, 0.030, 45), (1.5 * d, 0.030, 0)]    # skittish hops, then off
    else:
        plan = None                                     # frozen in the headlights
    return lx0, plan, rng.uniform(70, 120)


def _ped_plan(rng, side):
    sp = rng.uniform(0.0065, 0.0105)
    r = rng.random()
    if r < 0.34:
        return 1.3 * side, [(-1.45 * side, sp, 0)], rng.uniform(150, 260), "walk"
    if r < 0.54:                                        # dawdles in the road (phone, shoelace...)
        return 1.3 * side, [(rng.uniform(-0.5, 0.5), sp, rng.randint(40, 110)), (-1.45 * side, sp, 0)], \
            rng.uniform(150, 260), "dawdle"
    if r < 0.70:                                        # changes their mind and goes back
        return 1.3 * side, [(side * rng.uniform(-0.3, 0.6), sp, rng.randint(10, 40)), (1.35 * side, sp * 1.4, 0)], \
            rng.uniform(150, 250), "turnback"
    if r < 0.85:                                        # late runner
        return 1.3 * side, [(-1.45 * side, 0.019, 0)], rng.uniform(70, 105), "runner"
    return 1.15 * side, None, None, "waiter"            # waits at the kerb, never crosses


# what each zone throws at you, in order (so every kind shows up, but the order is not obvious)
EVENT_CYCLE = [list(e) for e in _level1.EVENTS]


def _family(rng, s, sd, T=165.0, n=3):
    """a mother boar leads her piglets across the road in a line; the last one may dawdle in the middle of the lane"""
    out = [_hz("boar", s, 1.45 * sd, plan=[(-1.6 * sd, 0.014, 0)], trig=T, face=-sd)]
    dawdle = set()
    q = rng.random()
    if q < 0.55:                                           # most families: one little one stops to look at you (any of them, not always the last)
        dawdle.add(rng.randint(1, n))
        if q < 0.12:
            dawdle.add(rng.randint(1, n))
    for i in range(1, n + 1):
        plan = [(-1.6 * sd, 0.016, 0)]
        if i in dawdle:
            plan = [(sd * rng.uniform(-0.45, 0.6), 0.016, rng.randint(30, 90)), (-1.6 * sd, 0.022, 0)]
        out.append(_hz("piglet", s + 2.0 * i, 1.45 * sd + sd * 0.05 * i, plan=plan, trig=T - 15.0 * i, face=-sd))
    return out


def _scene(rng, s, kind):
    """an accident with an ambulance, or a police stop, on one side of the road: pass on the open side. hitting any of it costs 10 seconds"""
    out = []
    if kind == "amb":
        sd = rng.choice((-1, 1))
        out.append(_hz("emv", s, sd * 1.06, v="amb", hw=0.40))
        out.append(_hz("emv", s + 20.0, sd * 1.12, v="wreck", tilt=sd * rng.uniform(14, 24), hw=0.42))
        out.append(_hz("ped", s + 11.0, sd * 0.82, who="medic", look=rng.randint(0, 3), anim=rng.randint(0, 60), scene=True))
        out.append(_hz("ped", s + 14.0, sd * 1.22, who="medic", look=rng.randint(0, 3), anim=rng.randint(0, 60), scene=True))
        if rng.random() < 0.7:                              # a paramedic hurries out into the lane for something, then back
            out.append(_hz("ped", s + 8.0, sd * 0.78, who="medic", look=rng.randint(0, 3), scene=True,
                           plan=[(-sd * 0.25, 0.011, 40), (sd * 0.8, 0.011, 0)], trig=rng.uniform(95, 130), face=-sd))
    else:
        sd = 1 if rng.random() < 0.8 else -1
        out.append(_hz("emv", s, sd * 1.06, v="pol", hw=0.40))
        out.append(_hz("emv", s + 16.0, sd * 1.04, v="stop", hw=0.42))
        out.append(_hz("ped", s + 9.0, sd * 0.80, who="cop", look=rng.randint(0, 3), anim=rng.randint(0, 60), scene=True))                 # the officer
        out.append(_hz("ped", s + 15.0, sd * 0.70, shirt=(190, 170, 60), look=rng.randint(0, 3), anim=rng.randint(0, 60), scene=True))      # the driver
        if rng.random() < 0.6:                              # a second officer steps out into the lane to wave you down, then back
            out.append(_hz("ped", s + 5.0, sd * 0.78, who="cop", look=rng.randint(0, 3), scene=True,
                           plan=[(-sd * 0.3, 0.011, 45), (sd * 0.8, 0.011, 0)], trig=rng.uniform(95, 130), face=-sd))
    return out


def build_hazards():
    global RADIO_S
    rng = random.Random(404 + LVL_SEED)
    out = []
    counters = [0, 0, 0]
    deer_count = [0]
    horde_id = [0]
    s = THEME.get("start", 1000.0)
    while s < LEVEL_LEN - 800:
        s = _clear_spot(s)
        if near_intersection(s, THEME.get("event_pad", 380)) or near_fork(s, 360):
            s += 200 if THEME.get("event_pad") else 420
            continue
        zi = zone_index(s)
        cycle = EVENT_CYCLE[zi]
        kind = cycle[counters[zi] % len(cycle)]
        counters[zi] += 1
        length = 120.0

        if TUNNEL and TUNNEL[0] - 460 < s < TUNNEL[1] + 120:
            s = TUNNEL[1] + 130.0                        # nothing but the dark inside, and the approach is kept clear
            counters[zi] -= 1
            continue
        if kind == "deer" and (wide_f(s) > 1.0 or wide_f(s - 300) > 1.0 or wide_f(s + 100) > 1.0):
            continue                                     # animals stay out of the multi-lane stretches: the next kind of event comes up instead
        if kind == "deer":
            out.append(_warn(s - 480, "deer", rng))
            side = rng.choice((-1, 1))
            for i in range(rng.choice((1, 1, 2))):
                if i:
                    side = -side
                lx0, plan, trig = _deer_plan(rng, side, DEER_MODES[deer_count[0] % len(DEER_MODES)])
                deer_count[0] += 1
                first = plan[0][0] if plan else lx0
                out.append(_hz("deer", s + i * 26.0, lx0, plan=plan, trig=trig, face=1 if first > lx0 else -1))
            length = 80.0

        elif kind in ("ped", "treat"):
            out.append(_warn(s - 320, "ped" if kind == "ped" else "ghost", rng))
            CROSSWALKS.append(s)
            n = rng.choice((1, 2, 3, 3, 4, 5))
            side = rng.choice((-1, 1))
            for i in range(n):
                sd = side if rng.random() < 0.65 else -side
                who = "kid" if rng.random() < 0.2 else "ped"
                if kind == "treat":
                    who = "costume"
                col = rng.choice([(160, 40, 40), (40, 120, 70), (200, 170, 50), (90, 60, 140), (60, 120, 200)])
                lx0, plan, trig, _mode = _ped_plan(rng, sd)
                off = rng.uniform(-1.5, 3.0)
                if i == 0 and rng.random() < 0.3:        # somebody who can't be bothered with the crossing
                    off = rng.choice((-1, 1)) * rng.uniform(14, 38)
                out.append(_hz(who, s + off, lx0, plan=plan, trig=trig, shirt=col, look=rng.randint(0, 3)))
            length = 60.0

        elif kind == "horde":                            # a rack of ten zombies shuffling towards you: bowling!
            out.append(_warn(s - 520, "zombie", rng))
            out.append(_warn(s - 260, "zombie", rng))
            hid = horde_id[0]
            horde_id[0] += 1
            cx = rng.uniform(-0.22, 0.22)
            for r_ in range(4):
                for k_ in range(r_ + 1):
                    lx0 = cx + (k_ - r_ / 2.0) * 0.21
                    out.append(_hz("zombie", s + r_ * 4.5 + rng.uniform(-0.5, 0.5), lx0, lx0=lx0, vs=0.11, trig_d=270.0,
                                   horde=hid, knock_t=0, knock_dir=1.0, ph=rng.uniform(0, 6.28), anim=rng.randint(0, 60)))
            length = 90.0

        elif kind == "ghoul":                            # something climbs out of a grave beside the road and lurches across
            out.append(_warn(s - 380, "zombie", rng))
            for i in range(rng.choice((1, 2, 2))):
                sd = rng.choice((-1, 1))
                lx0 = sd * rng.uniform(1.15, 1.35)
                out.append(_hz("ghoul", s + i * 24.0, lx0, plan=[(-sd * rng.uniform(0.5, 1.5), 0.013, 0)], trig=rng.uniform(120, 170),
                               solid=False, rise=0.0, anim=rng.randint(0, 60), face=-sd))
            length = 60.0

        elif kind == "faltree":                          # a tree beside the road creaks, shakes and comes down across it
            out.append(_warn(s - 480, "tree", rng))
            sd = rng.choice((-1, 1))
            full = False                                 # it never blocks the whole road: there is always a way round
            ln = 2.7 if full else rng.uniform(1.15, 1.7)
            root = sd * 1.45
            out.append(_hz("faltree", s, root - sd * ln / 2.0, hw=ln / 2.0, solid=False, trig=rng.uniform(185, 225) if full else rng.uniform(105, 135),
                           root=root, ln=ln, rsd=sd, fall=0.0, anim=0, col=rng.randrange(4)))
            length = 70.0

        elif kind == "wetleaf":                          # a drift of wet leaves across all or half of the road: the tyres skate
            out.append(_warn(s - 320, "slip", rng))
            full = rng.random() < 0.5
            sd = rng.choice((-1, 1))
            for i in range(7):
                out.append(_hz("wetleaf", s + i * 9.0, 0.0 if full else sd * 0.5, hw=1.6 if full else 0.85, solid=False, used=False, ph=rng.randrange(8)))
            length = 70.0

        elif kind == "rockfall":                         # rocks let go of the bank as you pass and drop onto the road: weave through
            out.append(_warn(s - 460, "rocks", rng))
            sd = rng.choice((-1, 1))
            for i, (lx_, ds_) in enumerate(((sd * 0.7, 0.0), (-sd * 0.1, 11.0), (sd * 0.45, 22.0), (-sd * 0.75, 30.0))):
                out.append(_hz("rock", s + ds_, lx_, hw=0.26, solid=False, trig=rng.uniform(95, 125) + ds_ * 0.4, fall=0.0, delay=rng.randint(0, 10) + i * 3, anim=0))
            length = 80.0

        elif kind == "family":
            out.append(_warn(s - 480, "boar", rng))
            out += _family(rng, s, rng.choice((-1, 1)))
            length = 90.0

        elif kind in ("amb", "police"):
            out.append(_warn(s - 420, "emv", rng))
            out += _scene(rng, s, "amb" if kind == "amb" else "pol")
            length = 60.0

        elif kind == "web":                              # a spider web across part of the road: steer round it
            out.append(_warn(s - 420, "spider", rng))
            out.append(_hz("web", s, 0.0, solid=False, hw=1.5, used=False, anim=rng.randint(0, 50)))
            length = 60.0

        elif kind == "witch":                            # the GOOD witch lands beside the road: pass close to be mended and uncursed
            out.append(_warn(s - 420, "witch", rng))
            out.append(_hz("witch", s + 60, rng.choice((-1, 1)) * rng.uniform(0.62, 0.75), trig_d=420.0, alt=1.0, anim=0, wait=0, helped=False))
            length = 60.0

        elif kind == "bats":                             # bats that dive at the car
            out.append(_warn(s - 420, "bat", rng))
            for i in range(rng.choice((2, 3, 3, 4))):
                out.append(_hz("bat", s + 40 + i * 22.0, rng.uniform(-1.3, 1.3), vs=0.30, trig_d=400.0 + i * 30.0, fly=True,
                               anim=rng.randint(0, 30), knock_t=0))
            length = 60.0

        elif kind == "ghost":                            # halloween: ghosts you can drive through... and one that is not
            out.append(_warn(s - 480, "ghost", rng))
            n = rng.choice((2, 3, 3))
            pick = rng.randrange(n) if rng.random() < 0.4 else -1
            for i in range(n):
                sd = rng.choice((-1, 1))
                if i == pick:                            # a man in a bedsheet, wandering across just like the ghosts
                    lx0, plan, trig, _m = _ped_plan(rng, sd)
                    out.append(_hz("costume", s + i * 34.0, lx0, plan=plan, trig=trig, look=0))
                    continue
                lx0 = rng.uniform(-0.7, 0.7) if rng.random() < 0.7 else sd * 1.3
                plan = [(rng.uniform(-1.6, 1.6), rng.uniform(0.004, 0.010), 0)]
                out.append(_hz("ghost", s + i * 34.0, lx0, plan=plan, trig=rng.uniform(80, 150), solid=False,
                               anim=rng.randint(0, 60)))
            length = 110.0

        elif kind == "costume":                          # people in costumes crossing the road
            out.append(_warn(s - 420, "ghost", rng))
            side = rng.choice((-1, 1))
            for i in range(rng.choice((1, 2, 2, 3))):
                sd = side if rng.random() < 0.65 else -side
                lx0, plan, trig, _m = _ped_plan(rng, sd)
                out.append(_hz("costume", s + rng.uniform(-6, 24) + i * 14.0, lx0, plan=plan, trig=trig,
                               look=rng.randint(0, 3), shirt=(200, 60, 60)))
            length = 70.0

        elif kind == "coffin":                           # a coffin that fell off a hearse
            out.append(_warn(s - 480, "coffin", rng))
            out.append(_hz("coffin", s, rng.choice((-1, 1)) * rng.uniform(0.3, 0.6)))
            length = 40.0

        elif kind == "work":
            b = rng.choice((-1, 1))                      # blocked side
            out.append(_warn(s - 560, "work", rng))
            out.append(_warn(s - 300, "work", rng))
            for i in range(6):                           # taper in
                out.append(_hz("cone", s - 100 + i * 17.0, b * (1.02 - 0.72 * i / 5.0)))
            out.append(_hz("barrier", s, b * 0.70, bob=rng.randint(0, 40)))
            L = rng.uniform(220, 300)
            d = 17.0
            while d < L:
                out.append(_hz("cone", s + d, b * 0.30))
                d += 17.0
            for k in range(2):                           # workers behind the barrier doing 'work'
                out.append(_hz("worker", s + 30 + k * 55 + rng.uniform(-8, 8), b * rng.uniform(0.6, 1.0),
                               anim=rng.randint(0, 40), dig=True))
            if rng.random() < 0.5:                       # one walks out from behind the barrier, across the open lane
                out.append(_hz("worker", s + 95, b * 0.45, plan=[(-b * 1.4, 0.0075, 0)], trig=rng.uniform(100, 140),
                               face=-b))
            else:                                        # or one stands in the open lane on a smoke break
                if rng.random() < 0.5:                   # ambles off when somebody comes
                    out.append(_hz("smoker", s + 150, -b * rng.uniform(0.18, 0.32), anim=rng.randint(0, 100),
                                   plan=[(-b * 1.35, 0.012, 0)], trig=rng.uniform(90, 130), face=-b))
                else:                                    # or leans on the edge of the open lane
                    out.append(_hz("smoker", s + 150, -b * 0.97, anim=rng.randint(0, 100)))
            length = L

        else:                                            # absurd, anywhere (never dead centre)
            who = "sleeper"                              # smokers only turn up at roadworks; this one is sleeping it off on the verge
            lx0 = rng.choice((-1, 1)) * rng.uniform(0.28, 0.62)
            q = rng.random()
            plan = None
            trig = None
            if who == "smoker" and q < 0.5:              # sometimes he ambles off, sometimes he doesn't
                plan = [(lx0 + (1 if lx0 > 0 else -1) * 0.9, 0.007 if q < 0.25 else 0.022, 0)]
                trig = rng.uniform(60, 110)
            if who == "sleeper":                         # snoozes on the verge, not on the tarmac
                lx0 = (1 if lx0 > 0 else -1) * 1.38
                out.append(_hz(who, s, lx0, anim=rng.randint(0, 100), solid=False))
            else:
                out.append(_hz(who, s, lx0, anim=rng.randint(0, 100), plan=plan, trig=trig))
            length = 40.0

        gaps = THEME.get("gap", ((750, 1200), (750, 1200), (550, 900)))
        s += length + rng.uniform(*gaps[zi])
    if THEME.get("ambient"):                             # ghosts drifting about beside the road, just to keep it spooky
        arng = random.Random(808 + LVL_SEED)
        a_s = 260.0
        while a_s < LEVEL_LEN - 400:
            sd = arng.choice((-1, 1))
            out.append(_hz("ghost", a_s, sd * arng.uniform(1.9, 3.2), solid=False, anim=arng.randint(0, 200)))
            a_s += arng.uniform(120, 260)
    # a cat that sprints out of nowhere (no warning sign), a few times per run
    crng = random.Random(515 + LVL_SEED)
    taken = [o["s"] for o in out if o.get("hz") and o["kind"] != "ghost"]
    for base in (() if THEME.get("no_cats") else (3100.0, 7000.0, 9300.0, 13200.0)):
        cs = _clear_spot(base + crng.uniform(0, 300))
        for _ in range(40):
            if not (near_intersection(cs, 200) or near_fork(cs, 220) or any(abs(cs - t) < 260 for t in taken)):
                break
            cs = _clear_spot(cs + 60)
        side = crng.choice((-1, 1))
        out.append(_hz("cat", cs, 1.7 * side, plan=[(-1.9 * side, 0.068, 0)], trig=crng.uniform(23, 31),
                       face=-side))
        taken.append(cs)
    frng = random.Random(2323 + LVL_SEED)                # the last stretch is clear, so: three kittens in a row, 0.5 km from the line
    if THEME.get("no_cats"):                             # no kittens here: a boar family crosses instead, half a km from the line
        out += _family(frng, LEVEL_LEN - 520.0, frng.choice((-1, 1)), T=150.0)
    for i, off_ in enumerate(() if THEME.get("no_cats") else (560.0, 520.0, 480.0)):
        fside = frng.choice((-1, 1))
        out.append(_hz("cat", LEVEL_LEN - off_ + frng.uniform(-4, 4), 1.7 * fside, plan=[(-1.9 * fside, 0.068, 0)],
                       trig=frng.uniform(23, 31), face=-fside))
    if THEME.get("mud"):                                 # tombstones standing in the muddy cemetery road
        trng = random.Random(909 + LVL_SEED)
        m0, m1 = THEME["mud"]
        ts = m0 + 200.0
        spots = [h["s"] for h in out if h.get("hz") and h["kind"] != "ghost"]
        while ts < m1 - 120:
            if not (near_intersection(ts, 200) or near_fork(ts, 220) or any(abs(ts - q) < 150 for q in spots)):
                lanes = [-0.62, -0.05, 0.52]
                pick = trng.sample(lanes, trng.choice((1, 1, 2)))
                for ln in pick:                                       # no jitter, and never more than two of the three lanes: there is always a gap
                    out.append(_hz("tomb", ts, ln, v=trng.randint(0, 2)))
                spots.append(ts)
            ts += trng.uniform(170, 290)
    if THEME.get("spiders"):                             # spiders dangling from the dark
        srng = random.Random(717 + LVL_SEED)
        sp_s = THEME["mud"][0] + 150.0 if THEME.get("mud") else 3000.0
        while sp_s < LEVEL_LEN - 900:
            if not (near_intersection(sp_s, 200) or near_fork(sp_s, 220) or any(abs(sp_s - q["s"]) < (900 if q["kind"] == "web" else 140) for q in out if q.get("hz") and q["kind"] not in ("ghost", "tomb"))):
                for i in range(srng.choice((1, 1, 2))):
                    out.append(_hz("spider", sp_s + i * 14.0, srng.uniform(-0.8, 0.8), trig_d=300.0, fly=True, alt=1.0, anim=srng.randint(0, 40)))
            sp_s += srng.uniform(1100, 1700)
    for fs_ in THEME.get("fear", ()):                    # fear stations: drive onto the green bay to get patched up
        fs2 = fs_
        for _ in range(40):
            if not (near_intersection(fs2, 220) or near_fork(fs2, 260) or any(abs(fs2 - q["s"]) < 160 for q in out if q.get("hz") and q["kind"] != "ghost")):
                break
            fs2 += 40
        out.append(_hz("pad", fs2, 0.0, solid=False, used=False, hw=1.4))
        out.append(dict(s=fs2, side=0, kind="pitgate", off=0, k=1.0, part="entry"))
        out.append(dict(s=fs2 + 46.0, side=0, kind="pitgate", off=0, k=1.0, part="exit"))
        for q in range(1, 6):                                                    # a canopy of beams between the two gates
            out.append(dict(s=fs2 + q * 7.5, side=0, kind="fbeam", off=0, k=1.0))
        for q in range(0, 5):                                                    # pumps lining both sides
            for sd in (-1, 1):
                out.append(dict(s=fs2 + 4.0 + q * 10.0, side=sd, kind="fpump", off=3.0, k=1.0, ph=q + (3 if sd > 0 else 0)))
        for dist in (600, 300):
            out.append(dict(s=fs2 - dist, side=1, kind="fsign", off=12.0, k=1.0, dist=dist))
    wrng = random.Random(1313 + LVL_SEED)
    for wb in THEME.get("witch_at", ()):                 # the good witch, in the middle of a quiet stretch
        ws_ = _gap_spot(out, wb, 480.0)
        if ws_ is None:
            continue
        out.append(_warn(ws_ - 420, "witch", wrng))
        out.append(_hz("witch", ws_, wrng.choice((-1, 1)) * wrng.uniform(0.62, 0.75), trig_d=420.0, alt=1.0, anim=0, wait=0, helped=False))
    if THEME.get("opener"):                              # something in the first seconds: bats
        for i in range(3):
            out.append(_hz("bat", 760.0 + i * 20.0, (i - 1) * 0.7, vs=0.30, trig_d=400.0 + i * 30.0, fly=True, anim=i * 7, knock_t=0))
    if THEME.get("bats"):                                # unannounced bat attacks (rare)
        brng2 = random.Random(616 + LVL_SEED)
        for base in (1900.0, 9300.0, 13800.0):
            bs = _clear_spot(base + brng2.uniform(0, 300))
            for _ in range(40):
                if not (near_intersection(bs, 200) or near_fork(bs, 220) or any(abs(bs - t) < 220 for t in taken)):
                    break
                bs = _clear_spot(bs + 60)
            for i in range(brng2.choice((2, 3))):
                out.append(_hz("bat", bs + i * 18.0, brng2.uniform(-1.2, 1.2), vs=0.30, trig_d=380.0 + i * 25.0, fly=True,
                               anim=brng2.randint(0, 30), knock_t=0))
            taken.append(bs)
    if THEME.get("throwers"):                            # roadside lunatics lobbing pumpkins, and smashed pumpkin guts on the tarmac
        trng = random.Random(4242 + LVL_SEED)
        busy = [h["s"] for h in out if h.get("hz") and h["kind"] not in ("ghost",)]
        placed = [330.0]
        sp_ = [(330.0, 1)]
        pts = sorted(busy + [0.0, LEVEL_TARGET] + [r_ + d_ for r_ in THEME.get("rail_bases", ()) for d_ in (-560.0, 300.0)])
        for a_, b_ in zip(pts, pts[1:]):                 # the middle of the quiet stretches
            if b_ - a_ < 420 or a_ < 500:
                continue
            n_ = max(1, int((b_ - a_) // 650))
            for j_ in range(n_):
                mid_ = a_ + (b_ - a_) * (j_ + 0.5) / n_
                if trng.random() < 0.85 and not near_intersection(mid_, 260) and not near_fork(mid_, 260):
                    ts_ = _calm_near(mid_ + trng.uniform(-30, 30), lim=2.0)
                    if ts_ is not None and all(abs(ts_ - q) > 420 for q in placed) and ts_ < LEVEL_TARGET - 500:
                        placed.append(ts_)
                        sp_.append((ts_, 1))
        for ts_, _n in sp_:
            sd = trng.choice((-1, 1))
            for i in range(2 if (ts_ < 400 or trng.random() < 0.4) else 1):
                sd_ = sd if i == 0 else -sd
                out.append(_hz("thrower", ts_ + i * 30.0, sd_ * 1.32, solid=False, throws=0, nextt=0, anim=trng.randint(0, 60), face=-sd_))
                for _k in range(3):
                    out.append(_hz("pshot", ts_ + i * 30.0, sd_ * 1.32, solid=False, hw=0.22, phase="idle", ph0="idle", u=0.0, s0=0.0, lx0=0.0, s1=0.0, lx1=0.0, T=48.0, anim=trng.randint(0, 30)))
        srng = random.Random(5151 + LVL_SEED)
        sb = 640.0
        while sb < LEVEL_TARGET - 400:                   # leftover splats: nobody saw who threw them
            ss_ = _clear_spot(sb + srng.uniform(0, 200))
            if not (near_intersection(ss_, 200) or near_fork(ss_, 200) or any(abs(ss_ - q) < 90 for q in busy)):
                for _k in range(srng.choice((2, 3, 4))):
                    out.append(_hz("pshot", ss_ + srng.uniform(0, 70), srng.uniform(-0.7, 0.7), solid=False, hw=0.22, phase="splat", ph0="splat", u=1.0,
                                   s0=0.0, lx0=0.0, s1=0.0, lx1=0.0, T=48.0, anim=srng.randint(0, 30), v=srng.randint(0, 3)))
            sb = ss_ + srng.uniform(520, 800)
    zs_ = [h["s"] for h in out if h.get("hz") and h["kind"] == "zombie"]
    out = [h for h in out if not (h.get("hz") and h["kind"] == "bat" and any(abs(h["s"] - z) < 800 for z in zs_))]   # bats never spoil a zombie rack
    # the good witch must have the road to herself: no roadworks, cones or crowds around her, and she stands well off to the side
    others = [h["s"] for h in out if h.get("hz") and h["kind"] not in ("ghost", "pshot", "witch")]
    others += [c_ for c_ in CHECKPOINTS]
    for r_ in THEME.get("rail_bases", ()):
        others += [r_ - 560.0, r_ + 300.0]
    for w_ in [h for h in out if h.get("hz") and h["kind"] == "witch"]:
        old_s = w_["s"]
        best = None
        for k_ in range(0, 90):
            for sg_ in (1, -1):
                c_ = old_s + sg_ * k_ * 10.0
                if 600 < c_ < LEVEL_TARGET - 500 and all(abs(c_ - o_) > 170.0 for o_ in others) and _calm_near(c_, lim=1.0) is not None:
                    best = c_
                    break
            if best is not None:
                break
        if best is not None and best != old_s:
            for sgn_ in out:
                if sgn_.get("glyph") == "witch" and abs(sgn_["s"] - (old_s - 420)) < 1.0:
                    sgn_["s"] = best - 420
            w_["s"] = best
        sd_ = 1.0 if w_["lx"] > 0 else -1.0
        w_["lx"] = sd_ * min(0.88, max(0.78, abs(w_["lx"]) + 0.14))
        w_["_init"].update(s=w_["s"], lx=w_["lx"])
        others.append(w_["s"])
    if THEME.get("early_tree"):                          # something to wake the player up long before the first deer
        for s0, sd0 in ((380.0, 1),):
            out.append(_warn(s0 - 460, "tree", rng))
            ln0 = rng.uniform(1.2, 1.6)
            out.append(_hz("faltree", s0, sd0 * 1.45 - sd0 * ln0 / 2.0, hw=ln0 / 2.0, solid=False, trig=rng.uniform(110, 135),
                           root=sd0 * 1.45, ln=ln0, rsd=sd0, fall=0.0, anim=0, col=rng.randrange(4)))
    if TUNNEL:                                           # the tunnel: warning signs, and things standing in the dark
        trng_ = random.Random(1717 + LVL_SEED)
        out.append(_warn(TUNNEL[0] - 520, "tunnel", trng_))
        out.append(_warn(TUNNEL[0] - 200, "tunnel", trng_))
        for k_ in range(3):                              # funny-looking mushrooms growing on the tunnel floor
            out.append(_hz("shroom", TUNNEL[0] + 110 + k_ * 150.0 + trng_.uniform(-20, 20), trng_.choice((-1, 1)) * trng_.uniform(0.15, 0.6),
                           solid=False, used=False, hw=0.12))
        ps_ = _clear_spot(TUNNEL[1] + 330.0 + trng_.uniform(0, 60))        # a police stop just outside the tunnel
        out.append(_warn(ps_ - 330, "emv", trng_))
        out += _scene(trng_, ps_, "pol")
        RADIO_S = ps_
        drng = random.Random(2929 + LVL_SEED)                # the mushroom-picker druids: they cure the trip if you drive close to them
        for base in (TUNNEL[1] + 4700.0,):                  # just the one, so the trip lasts a good while
            ds = _clear_spot(base + drng.uniform(0, 200))
            for _ in range(30):
                if not (near_intersection(ds, 120) or near_fork(ds, 160)):
                    break
                ds = _clear_spot(ds + 50)
            sd = drng.choice((-1, 1))
            if ds < LEVEL_LEN - 400:
                out.append(_hz("druid", ds, sd * 1.18, solid=False, used=False, anim=drng.randint(0, 100), face=-sd))
                out.append(_warn(ds - 380, "shroom", drng))
                out.append(_warn(ds - 150, "shroom", drng))
    erng = random.Random(6161 + LVL_SEED)                 # hand-placed extras: wet leaves, a rockfall, warning signs for the logging trucks

    def _free(s0, pad=130.0):
        """the nearest spot to s0 (looking both ways) that is calm, clear of crossings and forks, and not on top of another event"""
        for d_ in range(0, 1400, 40):
            for c_ in ((s0 + d_, s0 - d_) if d_ else (s0,)):
                if section_at_calm(c_) and not (near_intersection(c_, 160) or near_fork(c_, 300) or (TUNNEL and TUNNEL[0] - 560 < c_ < TUNNEL[1] + 160)
                                                or any(abs(q["s"] - c_) < pad for q in out if q.get("hz"))):
                    return c_
        return s0

    for base in THEME.get("wetleaves", ()):
        s0 = _free(base)
        out.append(_warn(s0 - 300, "slip", erng))
        full = erng.random() < 0.5
        sd0 = erng.choice((-1, 1))
        for i in range(7):
            out.append(_hz("wetleaf", s0 + i * 9.0, 0.0 if full else sd0 * 0.5, hw=1.6 if full else 0.85, solid=False, used=False, ph=erng.randrange(8)))
    for base in THEME.get("rockfalls", ()):
        s0 = _free(base, 200.0)
        out.append(_warn(s0 - 460, "rocks", erng))
        sd0 = erng.choice((-1, 1))
        for i, (lx_, ds_) in enumerate(((sd0 * 0.7, 0.0), (-sd0 * 0.1, 11.0), (sd0 * 0.45, 22.0), (-sd0 * 0.75, 30.0))):
            out.append(_hz("rock", s0 + ds_, lx_, hw=0.26, solid=False, trig=erng.uniform(95, 125) + ds_ * 0.4, fall=0.0, delay=erng.randint(0, 10) + i * 3, anim=0))
    for sp_ in THEME.get("logtrucks", ()):
        out.append(_warn(sp_ + 100, "logs", erng))
    out += build_xcars()
    return out


XCAR_L = {"sedan": 4.4, "van": 5.0, "truck": 7.5, "tractor": 4.0}
XCAR_H = {"sedan": 1.45, "van": 2.1, "truck": 3.1, "tractor": 2.6}
XCAR_HW = {"sedan": 0.46, "van": 0.52, "truck": 0.72, "tractor": 0.5}


def build_xcars():
    """cars on the cross streets: one, a convoy of three or four, or some from each side. They drive along the street and cross your road."""
    out = []
    if not THEME.get("xcars"):
        return out
    rng = random.Random(6060 + LVL_SEED)
    kinds = THEME.get("xcar_kinds", ("sedan", "sedan", "van", "truck"))
    cols = THEME.get("car_colors", CAR_COLORS)
    for si in INTERSECTIONS:
        pat = rng.choice(("single", "single", "convoy", "convoy", "both", "both", "tractor", "pair"))
        d = rng.choice((-1, 1))
        a0 = rng.uniform(-18, 50)                       # frames, relative to when you would arrive: about 0 means a collision course
        groups = []                                      # (direction, [(arrival, kind)])
        if pat == "single":
            groups.append((d, [(a0, rng.choice(kinds))]))
        elif pat == "pair":
            groups.append((d, [(a0, rng.choice(kinds)), (a0 + rng.uniform(95, 125), rng.choice(kinds))]))
        elif pat == "convoy":
            a, cs_ = a0, []
            for _ in range(rng.choice((3, 4))):
                cs_.append((a, rng.choice(kinds)))
                a += rng.uniform(100, 135)
            groups.append((d, cs_))
        elif pat == "both":
            groups.append((d, [(a0, rng.choice(kinds)), (a0 + rng.uniform(95, 125), rng.choice(kinds))]))
            groups.append((-d, [(a0 + rng.uniform(55, 100), rng.choice(kinds))]))
        else:
            groups.append((d, [(a0, "tractor")]))
        for dd, cars in groups:
            v = rng.uniform(0.040, 0.052)
            if any(k_ == "tractor" for _a, k_ in cars):
                v = rng.uniform(0.019, 0.023)
            col = rng.choice(cols)
            for ci_, (a, kd) in enumerate(cars):
                out.append(_hz("xcar", si + (2.3 if dd > 0 else -2.3), -dd * 80.0, hw=XCAR_HW[kd], solid=False, dir=dd, v=v, a=a, kind2=kd,
                               color=col if kd != "truck" else (220, 220, 214), anim=rng.randint(0, 60),
                               yielded=0, stubborn=(ci_ == len(cars) - 1 and (len(cars) > 1 or rng.random() < 0.5))))   # the last car of a group ignores the horn
    return out


def build_fork_events():
    """each fork: one branch is closed for roadworks, the other is clear"""
    rng = random.Random(9191 + LVL_SEED)
    out = []
    for f in FORKS:
        b = rng.choice((-1, 1))
        out.append(_warn(f - 330, "split", rng))
        out.append(_warn(f - 130, "split", rng))
        out.append(_warn(f + FORK_RAMP + 20, "work", rng))
        for i in range(6):
            out.append(_hz("cone", f + FORK_RAMP + 60 + i * 15.0, b * (1.02 - 0.5 * i / 5.0)))
        out.append(_hz("barrier", f + FORK_RAMP + 160, b * 0.65, bob=rng.randint(0, 40)))
        out.append(_hz("worker", f + FORK_RAMP + 190, b * 0.5, anim=rng.randint(0, 40), dig=True))
        # the island: rocks and trees down the middle
        d = FORK_RAMP
        while d < FORK_LEN - FORK_RAMP:
            kind = rng.choice(THEME.get("island", ("rock", "pine", "rock")))
            out.append(dict(s=f + d, side=0, kind=kind, lx=rng.uniform(-0.1, 0.1), off=0, k=rng.uniform(0.5, 0.8)))
            d += rng.uniform(40, 70)
    return out


_inter_signs = []
for _i, _s in enumerate(INTERSECTIONS):
    for _back in (320, 130):
        _inter_signs.append(dict(s=_s - _back, side=1 if _i % 2 else -1, kind="sign", dir=0, off=12, k=1.0, glyph="cross"))
TRAIN_LEN = 22.0           # lateral road-widths the train is long


def build_rails():
    rng = random.Random(7070 + LVL_SEED)
    out = []
    placed = []
    for base in THEME.get("rail_bases", (9000.0, 12100.0, 6600.0)):
        best = None
        for k in range(0, 45):
            for sgn in (1, -1):
                s = base + sgn * k * 20.0
                if (all(abs(section_at(s + d)[2]) < THEME.get("rail_curve", 0.45) for d in range(-120, 70, 30)) and not near_intersection(s, 140)
                        and not near_fork(s, 250) and all(abs(s - c) > 160 for c in CHECKPOINTS)
                        and all(abs(s - q) > 1500 for q in placed) and 600 < s < LEVEL_LEN - 900):
                    best = s
                    break
            if best is not None:
                break
        if best is None or len(placed) >= 2:
            continue
        s = best
        placed.append(s)
        out.append(dict(s=s, side=0, kind="rail", off=0, k=1.0, dir=rng.choice((-1, 1)), state="idle", head=0.0,
                        t=0, cool=0, signals=False, len=TRAIN_LEN + (2.3 if len(placed) == 2 else 0.0)))      # the second train has one more carriage
        out.append(_warn(s - 430, "rail", rng))
        out.append(_warn(s - 170, "rail", rng))
    return out


OBJS = [o for o in build_scenery() if not near_intersection(o["s"], STREET_HALF + 14)] + _inter_signs + build_hazards() + build_fork_events()
for _cp in CHECKPOINTS:
    OBJS.append(dict(s=_cp, side=0, kind="checkpoint", off=0, k=1.0))
_rails = build_rails()
_rail_s = [o["s"] for o in _rails if o["kind"] == "rail"]
# keep the approach to a crossing free of other events, so the train is the one thing to deal with
OBJS = [o for o in OBJS if not ((o.get("hz") or o["kind"] in ("overpass", "gas", "billboard") or
                                 (o["kind"] == "sign" and o.get("glyph")))
                                and any(r - 560 < o["s"] < r + 160 for r in _rail_s))]
OBJS += _rails
OBJS.sort(key=lambda o: o["s"])
OBJ_S = [o["s"] for o in OBJS]
HAZ = [o for o in OBJS if o.get("hz")]
HAZ_S = [o["s"] for o in HAZ]
MOVERS = [o for o in HAZ if o["kind"] in ("zombie", "bat", "witch", "spider", "web", "thrower", "pshot")]
RAILS = [o for o in OBJS if o["kind"] == "rail"]
DEER_ZONES = [(o["s"] - 380.0, o["s"] + 120.0) for o in HAZ if o["kind"] in ("deer", "zombie", "witch", "ghoul", "boar", "emv")]     # little traffic around deer

CLOUDS = []
_r = random.Random(5)
for _ in range(7):
    CLOUDS.append((_r.randint(-40, W - 80), _r.randint(8, HORIZON_BASE - 45),
                   _r.randint(70, 170), _r.randint(18, 38)))


def make_ridge(seed, hmin, hmax, step):
    r = random.Random(seed)
    return [(x, r.randint(hmin, hmax)) for x in range(-160, W + 161, step)]


RIDGE_BACK = make_ridge(11, 18, 52, 46)
RIDGE_FRONT = make_ridge(12, 6, 26, 34)

RECORD = {"best": None}
AUDIO = None                     # set in main()


# ------------------------------------------------------------------ hills
HILL_GRADE = 0.28               # road grade (rise / run) per unit of a section's "hill" value
ELEV_STEP = 2.0
CAM_ABOVE_ROAD = 4.5            # metres, matches the perspective of the flat road (see proj_y)


def _hill_features():
    """(centre, half_length, height) bumps. Flat road by default; hills only where they make sense."""
    feats = []
    # small crests on calm straights in the pine forest: clear of junctions, roadworks, deer and crossings
    spots = []
    s = 1300.0
    while s < 5000.0 and len(spots) < 3:
        ok = all(abs(section_at(x)[2]) < 0.45 for x in (s - 120, s, s + 120))
        ok = ok and not any(near_intersection(x, 200) or near_fork(x, 240) for x in (s - 120, s, s + 120))
        ok = ok and not any(abs(o["s"] - s) < 170 for o in HAZ) and not any(abs(o["s"] - s) < 300 for o in RAILS)
        ok = ok and all(abs(s - q) > 550 for q in spots)
        if ok:
            spots.append(s)
        s += 40.0
    for q in spots:
        feats.append((q, 110.0, 6.0))
    return feats


def _build_elevation():
    n = int((LEVEL_LEN + 1500.0) / ELEV_STEP)
    feats = _hill_features()
    out = []
    for i in range(n + 1):
        sx = i * ELEV_STEP
        e = 0.0
        for c, hl, h in feats:                          # smooth bump
            d = abs(sx - c)
            if d < hl:
                e += h * 0.5 * (1.0 + math.cos(math.pi * d / hl))
        if SLIDE is not None:                           # the mountain: climb to a crest, then a long way down
            c = SLIDE[0] + 20.0
            if sx < c - 260.0:
                pass
            elif sx < c:
                u = (sx - (c - 260.0)) / 260.0
                e += 16.0 * (u * u * (3.0 - 2.0 * u))
            else:
                u = min(1.0, (sx - c) / max(1.0, SLIDE[1] - c))
                e += 16.0 - 130.0 * (u * u * (3.0 - 2.0 * u))
        out.append(e)
    return out


ELEV = _build_elevation()


def elev(sx):
    f = max(0.0, sx) / ELEV_STEP
    i = min(int(f), len(ELEV) - 2)
    u = f - i
    return ELEV[i] * (1.0 - u) + ELEV[i + 1] * u


# ------------------------------------------------------------------ state
class View:
    hy = HORIZON_BASE
    vcx = W // 2
    pos = 0.0
    e0 = 0.0                    # road height under the car
    prof_z = [0.0]              # profile of the road ahead for this frame: depth, screen y, lowest y reached so far
    prof_y = [float(H)]
    prof_min = [float(H)]


view = View()


class Run:
    def __init__(self):
        reset_hazards()
        reset_rails()
        self.state = "title"        # title / countdown / race / finish
        self.horn_next = 0          # frame when the horn can be used again
        self.horn_on, self.horn_t = False, 0
        self.pos = 0.0
        self.speed = 0.0
        self.car_x = W / 2
        self.car_xv = 0.0
        self.curve = 0.0
        self.hill = 0.0
        self.frames = 0
        self.cd = 0
        self.go = 0
        self.zone_i = 0
        self.banner = 0
        self.off = False
        self.finish_frames = 0
        self.gear = 0
        self.wheel = 0.0
        self.hits = 0
        self.traffic = []
        self.gravel_car = False
        self.roadside_hit = set()
        self.next_spawn = 900.0
        self.trng = random.Random(2024)
        self.damage = 0.0
        self.cp_i = 0
        self.bonus_time = 0.0
        self.cp_msg = 0
        self.over_reason = ""
        self.over_frames = 0
        self.bump = 0
        self.car_scale = 4
        self.crash = 0
        self.crash_msg = ""
        self.spook = 0
        self.bat = 0
        self.chill = 0
        self.sparkle = 0
        self.spider = 0
        self.shake_n = 0
        self.shake_dir = 0
        self.web = 0
        self.slick = 0
        self.gut = 0
        self.shake_t = 0                      # the picture shakes when a tree or rock lands nearby
        self.shake_amp = 0.0
        self.tun_k = 0.0                      # 0..1: how deep inside the tunnel we are (drives the tunnel roar)
        self.reply = 0                        # frame at which a crossing driver honks back
        self.reply_v = 0.0
        self.reply_k = None                    # what kind of vehicle will answer (a tractor has its own horn)
        self.tractor_d = None                 # distance to the nearest crossing tractor (its engine is heard)
        self.screech_next = 0                 # frame before which the tyres do not screech again
        self.lt_done = set()                  # logging trucks already sent down the road
        self.fx = {}
        self.fx_msg = ""
        self.fx_t = 0
        self.finale = False
        self.bonus_msg = ""
        self.bonus_t = 0
        self.trip = False                    # ate a mushroom in the tunnel: things appear in the road until the end of the race
        self.vis = None
        self.vis_next = 0
        self.trip_t = 0
        self.radio_s = RADIO_S
        self.untrip = 0
        self.horde_down = {}
        self.horde_warned = set()
        self.shift = 0
        self.brake = 0.0
        self.lid_off = False                 # corpse wagon: the lid came off in a crash
        self.leg = 0.0                       # ... and the leg swings in the wind
        self.legv = 0.0
        self.finish_time = 0.0
        self.new_best = False
        self.cause = ""                      # what ended the run (shown in the Hall of Shame)
        self.sb_phase = "idle"               # online scoreboard on the finish screen: idle name sending loading board error off
        self.sb_name = ""

    def time_left(self):
        return (START_TIME + THEME.get("extra_time", 0.0)) * car_clock() + self.bonus_time - self.frames / 60.0

    def start(self):
        self.state = "countdown"
        self.cd = 190
        self.crow_q = random.choice(THEME.get("start_quips") or CROW_QUIPS)


def road_at_t(t):
    """normal road edges for perspective scale t (1 at the car, 0 at the horizon)"""
    vcx = view.vcx
    left = (vcx - VAN_W) + (ROAD_L - (vcx - VAN_W)) * t
    right = (vcx + VAN_W) + (ROAD_R - (vcx + VAN_W)) * t
    return left, right, (left + right) / 2


def edges_zd(zd):
    """drawn road edges (wider in the three-lane stretches) at depth zd"""
    t = Z1 / zd
    l, r, c = road_at_t(t)
    if not WIDES:
        return l, r, c
    k = wide_k(view.pos + zd - Z1)
    if k <= 0.0:
        return l, r, c
    half_n = (r - l) / 2.0
    far = VAN_W * WIDE_FAR
    half_w = far + ((ROAD_R - ROAD_L) / 2.0 * WIDE_NEAR - far) * t        # straight edges in the full wide stretch
    half = half_n + (half_w - half_n) * k
    return c - half, c + half, c


def edge_at(y):
    """drawn road edges at screen y on flat ground (only used near the car, where hills make no difference)"""
    hy = view.hy
    if y <= hy + 1:
        return road_at_t(0.0)
    t = (y - hy) / (H - hy)
    return edges_zd(Z1 / t)


def road_at(y):
    hy = view.hy
    if y <= hy:
        return road_at_t(0.0)
    return road_at_t((y - hy) / (H - hy))


def proj_y(zd):
    """screen y of the road surface at depth zd, including the hills"""
    t = Z1 / zd
    return view.hy + (H - view.hy) * t - (elev(view.pos + zd - Z1) - view.e0) * PXM * t


def clip_y(zd):
    """lowest screen row at which things at depth zd can still be seen (a crest in front hides what is behind it)"""
    i = bisect.bisect_right(view.prof_z, zd - 3.0) - 1
    return int(view.prof_min[i]) if i >= 0 else H


# ------------------------------------------------------------------ update
def _step_plan(o):
    if o["pause_t"] > 0:
        o["pause_t"] -= 1
        o["moving"] = False
        return
    if o["pi"] >= len(o["plan"]):
        o["moving"] = False
        o["started"] = False
        o["trig"] = None
        return
    tx, sp, pz = o["plan"][o["pi"]]
    d = tx - o["lx"]
    if abs(d) <= sp:
        o["lx"] = tx
        o["pi"] += 1
        o["pause_t"] = pz
        o["moving"] = False
    else:
        step = sp if d > 0 else -sp
        o["lx"] += step
        o["face"] = 1 if step > 0 else -1
        o["moving"] = True
        o["anim"] += 1


def car_lateral(run):
    """car position and half width as a fraction of the road (-1 .. 1), measured at the car's wheels"""
    el, er, _ = road_at(H - 30)
    half_road = (er - el) / 2.0
    return (run.car_x - (el + er) / 2.0) / half_road, car_half_px(run) / half_road


def xcar_seen(run, o):
    """is this crossing car actually on screen (not still far down its street, or long gone)?"""
    zd = o["s"] - run.pos + Z1
    if zd <= 1.0 or zd > DRAW_DIST:
        return False
    el, er, _ = edges_zd(zd)
    return abs(o["lx"]) * (er - el) * 0.5 < W * 0.5 + 30


def _step_xcar(run, o):
    """a car on a cross street: it comes into view from far down the street and drives across your road"""
    if not o["started"]:
        gap = o["s"] - run.pos
        if 0 < gap < 560.0:
            tta = gap / max(run.speed * M_PER_FRAME, 1.0)            # frames until you get there
            o["started"] = True
            o["lx"] = -o["dir"] * o["v"] * max(10.0, tta + o["a"])   # so that it is in the middle of your road when you arrive (plus/minus a)
            o["solid"] = True
        return
    if o["hit"]:
        return
    if o["yielded"] > 0 and o["lx"] * o["dir"] < -3.2:               # it heard the horn and waits at the edge of your road
        o["yielded"] -= 1
        o["moving"] = False
        return
    o["lx"] += o["dir"] * o["v"]
    o["anim"] += 1
    o["moving"] = True
    if o["lx"] * o["dir"] > 70.0:
        o["solid"] = False


def _thump(run, o, amp_m=170.0, big=9.0):
    """something heavy lands: the picture shakes (more the closer you are), and the sound has a say too"""
    gap = o["s"] - run.pos
    amp = big * max(0.0, min(1.0, 1.15 - abs(gap) / amp_m))
    if amp > 0.6:
        prev = run.shake_amp if run.shake_t > 0 else 0.0
        run.shake_t = 24
        run.shake_amp = max(prev, amp)
    return max(0.0, min(1.0, 1.1 - abs(gap) / 300.0))


def _step_rock(run, o):
    """a rock that waits on the bank until the car is near, then drops onto the road"""
    if not o["started"]:
        gap = o["s"] - run.pos
        if 0 < gap / max(run.speed * M_PER_FRAME, 1.0) < o["trig"]:
            o["started"] = True
            o["anim"] = 0
        return
    o["anim"] += 1
    if o["fall"] < 1.0 and o["anim"] > o["delay"]:
        o["fall"] = min(1.0, o["fall"] + 0.03 + 0.03 * o["fall"])
        if o["fall"] >= 1.0:
            o["solid"] = True
            if not o.get("landed"):
                o["landed"] = True
                v = _thump(run, o, 140.0, 5.0)
                if AUDIO is not None:
                    getattr(AUDIO, "event", lambda *a: None)("log_fall", 0.55 * v)
    elif o["fall"] >= 1.0:
        o["solid"] = not o["hit"]


def _step_faltree(run, o):
    """a tree that shakes (the warning), creaks for a moment, then falls across the road"""
    if not o["started"]:
        gap = o["s"] - run.pos
        if 0 < gap / max(run.speed * M_PER_FRAME, 1.0) < o["trig"]:
            o["started"] = True
            o["anim"] = 0
            if AUDIO is not None:                                    # the creak and crack start now: the landing is timed to the thud in the recording
                getattr(AUDIO, "event", lambda *a: None)("tree_fall", max(0.0, min(1.0, 1.05 - gap / 330.0)))
        return
    o["anim"] += 1
    if o["fall"] < 1.0 and o["anim"] > 40:                           # about two thirds of a second of shaking first
        o["fall"] = min(1.0, o["fall"] + 0.012 + 0.05 * o["fall"])
        if o["fall"] >= 1.0:
            o["solid"] = True
            _thump(run, o)
    elif o["fall"] >= 1.0:
        o["solid"] = not o["hit"]


def update_hazards(run, prev_pos):
    lo = bisect.bisect_left(HAZ_S, prev_pos - 8)
    hi = bisect.bisect_right(HAZ_S, run.pos + 900)
    frac, car_hw = car_lateral(run)
    update_movers(run, prev_pos, frac, car_hw)
    for i in range(lo, hi):
        o = HAZ[i]
        if o["kind"] in ("zombie", "bat", "witch", "spider", "web", "thrower", "pshot"):
            continue
        if o["kind"] == "druid":
            o["anim"] += 1
            if run.trip and not o["used"] and prev_pos - 1.0 <= o["s"] + 4.0 and run.pos >= o["s"] - 4.0 and abs(frac - o["lx"]) < 1.05:
                o["used"] = True
                run.trip = False
                run.untrip = 100
                run.vis = None
                run.damage = max(0.0, run.damage - 40.0)                          # like the good witch: time, repairs and the cure
                run.bonus_time += 5.0 * car_clock()
                run.sparkle = 70
                run.bonus_msg = "YOU ATE THE PURPLE ONES, DIDN'T YOU?  +%d SEC" % round(5.0 * car_clock())
                run.bonus_t = 230
                if AUDIO is not None:
                    getattr(AUDIO, "chime", lambda: None)()
            continue
        if o["kind"] == "shroom":
            if (not o["used"]) and prev_pos - 1.0 <= o["s"] <= run.pos + 3.0 and abs(frac - o["lx"]) < car_hw + o["hw"] + 0.05:
                o["used"] = True
                if not run.trip:
                    run.trip = True
                    run.vis_next = 420
                    run.bonus_msg = "THAT WAS A WEIRD MUSHROOM..."
                    run.bonus_t = 150
            continue
        if o["kind"] == "pad":
            if (not o["used"]) and prev_pos - 1.0 <= o["s"] + 44.0 and run.pos >= o["s"] and abs(frac - o["lx"]) < car_hw + o["hw"]:
                o["used"] = True
                run.damage = max(0.0, run.damage - 60.0)
                run.bonus_msg = "FEAR STATION  -60% DAMAGE   (NO REFUNDS)"
                run.bonus_t = 130
                if AUDIO is not None:
                    getattr(AUDIO, "chime", lambda: None)()
            continue
        if o["hit"]:
            o["hit_t"] += 1
            o["lx"] += o["vx_hit"]
            continue
        if o["kind"] == "xcar":
            _step_xcar(run, o)
            if o["solid"] and prev_pos - 1.0 <= o["s"] <= run.pos + 3.0 and abs(frac - o["lx"]) < car_hw + o["hw"] - 0.03:
                hit_hazard(run, o, frac)
            continue
        if o["kind"] == "faltree":
            _step_faltree(run, o)
            if o["solid"] and prev_pos - 1.0 <= o["s"] <= run.pos + 3.0 and abs(frac - o["lx"]) < car_hw + o["hw"] - 0.03:
                hit_hazard(run, o, frac)
            continue
        if o["kind"] == "rock":
            _step_rock(run, o)
            if o["solid"] and prev_pos - 1.0 <= o["s"] <= run.pos + 3.0 and abs(frac - o["lx"]) < car_hw + o["hw"] - 0.03:
                hit_hazard(run, o, frac)
            continue
        if o["kind"] == "wetleaf":                          # a drift of wet leaves on the tarmac: the tyres skate
            if abs(o["s"] - run.pos) < 6.0 and abs(frac - o["lx"]) < car_hw + o["hw"]:
                if run.slick < 20 and run.speed > 0.3:
                    run.car_xv += random.choice((-1, 1)) * 2.4
                    run.bonus_msg = "WET LEAVES - SLIPPERY!"
                    run.bonus_t = 80
                o["used"] = True
                run.slick = max(run.slick, 70)
            continue
        # crossing things start moving when the car is about to arrive
        if o["trig"] is not None and not o["started"]:
            tta = (o["s"] - run.pos) / max(run.speed * M_PER_FRAME, 0.6)
            if 0 < tta < o["trig"]:
                o["started"] = True
            elif o["s"] - run.pos < 430.0:                 # ...or when a car comes up to them (once you are close enough to see it)
                for c in run.traffic:
                    d = o["s"] - c["s"]
                    if 0.0 < d < 200.0 and not c["hit"] and d / max(c["v"], 0.25) < o["trig"] * 2.6:
                        o["started"] = True
                        if o["plan"] is None and o["kind"] == "deer" and abs(o["lx"]) < 1.1:
                            o["plan"] = [(1.5 if o["lx"] >= 0 else -1.5, 0.03, 0)]      # a deer in the road gets out of a car's way
                            o["pi"] = 0
                        break
        if o["kind"] == "ghoul" and o["started"] and o["rise"] < 1.0:
            o["rise"] = min(1.0, o["rise"] + 0.022)
            o["solid"] = o["rise"] > 0.6
            o["moving"] = False
        elif o["plan"] is not None:
            if o["started"]:
                _step_plan(o)
                if o["kind"] == "ghoul":
                    o["solid"] = True
        elif o["started"] and o["vx"] != 0.0:
            end = o["lx_end"]
            nxt = o["lx"] + o["vx"]
            if (o["vx"] > 0 and nxt >= end) or (o["vx"] < 0 and nxt <= end):
                o["lx"] = end
                o["vx"] = 0.0
                o["started"] = False
                o["trig"] = None
                o["solid"] = False        # off the road now
            else:
                o["lx"] = nxt
            o["anim"] += 1
            o["moving"] = True
        else:
            o["moving"] = False
            if o["kind"] in ("smoker", "worker", "sleeper"):
                o["anim"] += 1
        if o["kind"] == "ghost":                      # you can drive straight through a ghost: it only spooks you
            if (not o["spooked"]) and prev_pos - 1.0 <= o["s"] <= run.pos + 3.0 and abs(frac - o["lx"]) < car_hw + o["hw"]:
                o["spooked"] = True
                run.spook = 60
                apply_curse(run, random.choice(("frozen", "reverse", "choke", "blackout")))
                if AUDIO is not None:
                    getattr(AUDIO, "spook", lambda: None)()
            continue
        if not o["solid"]:
            continue
        if prev_pos - 1.0 <= o["s"] <= run.pos + 3.0:
            if abs(frac - o["lx"]) < car_hw + o["hw"] - 0.03:
                hit_hazard(run, o, frac)


CURSES = {"frozen": (210, "FROZEN TYRES - NO GRIP!"), "reverse": (150, "POSSESSED - STEERING REVERSED!"),
          "choke": (80, "ENGINE DIED!"), "blackout": (220, "LIGHTS OUT!"), "bewitch": (230, "BEWITCHED - DRUNK DRIVING!")}


def apply_curse(run, kind):
    if run.fx:                                           # one curse at a time
        return
    n, msg = CURSES[kind]
    run.fx[kind] = n
    run.fx_msg = msg
    run.fx_t = 150
    if kind == "frozen":
        run.chill = n
    if kind == "choke":
        run.speed *= 0.8


def _bonus(run, sec, msg):
    run.bonus_time += sec
    run.bonus_msg = msg
    run.bonus_t = 70


HORN_COOL = 90                      # frames between honks (1.5 s)


def honk(run):
    """the horn: cats, deer and boars up ahead start running a little early, polite crossing cars wait for you, zombies and ghouls turn towards the sound"""
    if run.state != "race":
        return
    if AUDIO is not None:
        getattr(AUDIO, "honk", lambda c: None)(SET["car"])      # the sound always plays; only the effects below have a cooldown
    if run.frames < run.horn_next:
        return
    run.horn_next = run.frames + HORN_COOL
    if not run.reply:                                                     # a driver on a cross street out there does not like being honked at
        for o_ in HAZ[bisect.bisect_left(HAZ_S, run.pos): bisect.bisect_right(HAZ_S, run.pos + 330)]:
            if o_["kind"] == "xcar" and o_["started"] and not o_["hit"] and xcar_seen(run, o_):        # nobody there, nobody answers
                run.reply = run.frames + random.randint(18, 42)
                run.reply_v = max(0.25, min(1.0, 1.1 - (o_["s"] - run.pos) / 360.0))
                run.reply_k = o_.get("kind2")
                break
    frac, _hw = car_lateral(run)
    mps = max(run.speed * M_PER_FRAME, 0.6)
    lo = bisect.bisect_left(HAZ_S, run.pos)
    hi = bisect.bisect_right(HAZ_S, run.pos + 400)
    for i in range(lo, hi):
        o = HAZ[i]
        if o["hit"] or o["started"]:
            continue
        gap = o["s"] - run.pos
        if o["kind"] in ("cat", "deer", "boar", "piglet") and o["trig"] is not None and gap > 0 and gap / mps < o["trig"] * (2.2 if o["kind"] == "cat" else 1.7):
            o["started"] = True                           # it hears you and goes - a bit early, not a rescue
        elif o["kind"] == "ghoul" and 0 < gap < 260:
            o["started"] = True
        elif o["kind"] == "sleeper" and 0 < gap < 90 and not o.get("awake"):       # the horn at close range wakes him: he leaps up and bolts across the road
            sd_ = 1.0 if o["lx"] > 0 else -1.0
            o["awake"] = True
            o["shirt"] = (150, 112, 70)
            o["look"] = 2
            o["plan"] = [(-sd_ * 1.7, 0.05, 0)]
            o["pi"] = 0
            o["started"] = True
            o["solid"] = True
            o["hw"] = 0.09
            run.bonus_msg = "HE WOKE UP!"
            run.bonus_t = 60
    yielded = 0
    for i in range(lo, bisect.bisect_right(HAZ_S, run.pos + 420)):
        o = HAZ[i]
        if o["kind"] == "xcar" and o["started"] and not o["hit"] and not o["stubborn"] and o["lx"] * o["dir"] < -3.2 and o["yielded"] == 0:
            o["yielded"] = 150                                # polite cars stop and let you through
            if xcar_seen(run, o):
                yielded += 1                                  # (a car still far down its street waits silently)
    if yielded:
        if AUDIO is not None:
            getattr(AUDIO, "event", lambda *a: None)("tyre_screech", 0.8)                  # polite drivers stamp on the brakes for you
        run.bonus_msg = "THEY'RE WAITING"
        run.bonus_t = 60
    for o in MOVERS:
        if o["kind"] == "zombie" and not o["hit"] and 0 < o["s"] - run.pos < 320:
            o["started"] = True
            o["lure"] = 150                               # shuffle towards the car for a few seconds
            o["lure_x"] = frac


def update_movers(run, prev_pos, frac, car_hw):
    """zombie racks shuffling towards you, and bats diving at the windscreen"""
    for o in MOVERS:
        if o["s"] - run.pos > 900 or o["s"] < prev_pos - 30:
            if not o["hit"]:
                continue
        k = o["kind"]
        if o["hit"]:
            o["hit_t"] += 1
            o["lx"] += o["vx_hit"]
            continue
        if k == "witch" and not o["solid"] and not o["started"] and o["alt"] >= 1.0:
            o["solid"] = False
        if k == "zombie" and o.get("horde") not in run.horde_warned and 0 < o["s"] - run.pos < 400:
            run.horde_warned.add(o.get("horde"))
            if len(run.horde_warned) == 1:                  # the first time you meet them, tell the player what to do
                run.bonus_msg = "ZOMBIES AHEAD - STRIKE 'EM ALL!"
                run.bonus_t = 190
        if k == "zombie":
            if o["knock_t"] > 0:                          # a pin knocked over by another pin
                o["knock_t"] -= 1
                if o["knock_t"] == 0:
                    _zombie_down(run, o, o["knock_dir"] * 0.02)
                continue
            if not o["started"] and 0 < o["s"] - run.pos < o["trig_d"]:
                o["started"] = True
            if o["started"]:
                o["s"] -= o["vs"] * 1.0
                o["anim"] += 1
                o["moving"] = True
                if o.get("lure", 0) > 0:
                    o["lure"] -= 1
                    d_ = o["lure_x"] - o["lx0"]
                    o["lx0"] += max(-0.012, min(0.012, d_ * 0.05))
                o["lx"] = o["lx0"] + math.sin(o["anim"] * 0.05 + o["ph"]) * 0.03
            hit_ok = prev_pos - 1.5 <= o["s"] <= run.pos + 3.0
            if not hit_ok and o["started"]:                # zombie closed the distance while the car moved on
                hit_ok = o["s"] < run.pos + 3.0 and o["s"] > prev_pos - 1.5
            if hit_ok and abs(frac - o["lx"]) < car_hw * max(1.0, 18.5 / CARS[SET["car"] % len(CARS)].get("half", 18.5)) + o["hw"]:       # small cars still sweep a whole rack
                _zombie_down(run, o, (0.02 if o["lx"] >= frac else -0.02))
                run.speed *= 0.97
                # chain reaction: the pins around it go down too, if you were quick enough
                if run.speed > 0.25:
                    for m in MOVERS:
                        if m["kind"] == "zombie" and m.get("horde") == o.get("horde") and not m["hit"] and m is not o and m["knock_t"] == 0:
                            dist = math.hypot((m["s"] - o["s"]) / 4.5, (m["lx"] - o["lx"]) / 0.21)
                            if dist < 2.3 and random.random() < 0.85:
                                m["knock_t"] = 3 + int(dist * 7)
                                m["knock_dir"] = 1.0 if m["lx"] >= o["lx"] else -1.0
        elif k == "witch":
            gap = o["s"] - run.pos
            if not o["started"] and 0 < gap < o["trig_d"]:
                o["started"] = True
            if o["started"]:
                o["anim"] += 1
                if o["alt"] > 0.0:
                    o["alt"] = max(0.0, o["alt"] - 0.016)
                    if o["alt"] == 0.0 and AUDIO is not None:
                        getattr(AUDIO, "spook", lambda: None)()
                else:
                    o["wait"] += 1
                    if o["wait"] > 900 and gap > 60:        # a very bored witch takes off again
                        o["alt"] = 0.02
                        o["leaving"] = True
                if o.get("leaving"):
                    o["alt"] += 0.03
                    if o["alt"] > 1.2:
                        o["started"] = False
                        o["solid"] = False
            o["solid"] = o["alt"] < 0.3
            near_ = prev_pos - 1.5 <= o["s"] <= run.pos + 3.0
            if o["solid"] and near_ and abs(frac - o["lx"]) < car_hw + o["hw"] - 0.03:
                hit_hazard(run, o, frac)
            elif o["solid"] and near_ and not o["helped"] and abs(frac - o["lx"]) < 0.95:      # close enough: the good witch mends you
                o["helped"] = True
                run.damage = max(0.0, run.damage - 55.0)
                run.fx.clear()
                run.chill = 0
                run.spider = 0
                run.fx_t = 0
                run.sparkle = 100
                run.bonus_time += 8.0 * car_clock()
                run.bonus_msg = "GOOD WITCH:  +%d SEC  UNCURSED + REPAIRED" % round(8.0 * car_clock())
                run.bonus_t = 150
                if AUDIO is not None:
                    getattr(AUDIO, "chime", lambda: None)()
        elif k == "thrower":                               # a lunatic with a crate of pumpkins
            o["anim"] += 1
            gap = o["s"] - run.pos
            if 0 < gap < 140 and o["throws"] < len(o["shots"]) and o["anim"] >= o["nextt"]:
                sh_ = o["shots"][o["throws"]]
                o["throws"] += 1
                o["nextt"] = o["anim"] + 46
                o["armed"] = 14
                v_ = max(0.4, run.pos - prev_pos)
                T_ = 48.0
                sh_.update(phase="fly", u=0.0, T=T_, s0=o["s"], lx0=o["lx"], s1=run.pos + v_ * T_ + random.uniform(10.0, 40.0),
                           lx1=random.uniform(-0.85, 0.85), v=0)
            if o.get("armed", 0) > 0:
                o["armed"] -= 1
        elif k == "pshot":
            if o["phase"] == "fly":
                o["u"] += 1.0 / o["T"]
                u_ = min(1.0, o["u"])
                o["s"] = o["s0"] + (o["s1"] - o["s0"]) * u_
                o["lx"] = o["lx0"] + (o["lx1"] - o["lx0"]) * u_
                if o["u"] >= 1.0:
                    o["phase"] = "splat"
                    o["v"] = random.randint(0, 3)
            elif o["phase"] == "splat":
                if abs(o["s"] - run.pos) < 5.0 and abs(frac - o["lx"]) < car_hw + o["hw"]:
                    if run.slick < 20 and not o["used"]:
                        run.car_xv += random.choice((-1, 1)) * 3.2          # the back end steps out
                        run.bonus_msg = "PUMPKIN GUTS - SLIPPERY!"
                        run.bonus_t = 80
                    o["used"] = True
                    run.slick = max(run.slick, 80)
                if abs(o["s"] - run.pos) < 5.0 and abs(frac - o["lx"]) < car_hw + o["hw"] and run.frames % 28 == 0 and run.speed > 0.25:
                    run.gut = max(run.gut, 60)                    # guts spatter the windscreen while you skate through
        elif k == "spider":                                # hangs from a thread, drops as you approach
            gap = o["s"] - run.pos
            if not o["started"] and 0 < gap < o["trig_d"]:
                o["started"] = True
            if o["started"]:
                o["anim"] += 1
                o["alt"] = max(0.0, o.get("alt", 1.0) - 0.02)
                if -2.5 < gap < 3.0 and not o["hit"] and abs(frac - o["lx"]) < car_hw + 0.15:
                    o["hit"] = True
                    o["hit_t"] = 90
                    _spider_on(run)
        elif k == "web":                                   # a web across (part of) the road with a spider on it
            o["anim"] += 1
            if (not o["used"]) and prev_pos - 1.0 <= o["s"] <= run.pos + 3.0 and abs(frac - o["lx"]) < car_hw + o["hw"]:
                o["used"] = True
                run.speed *= 0.9
                run.web = 110
                run.crash = 14
                run.crash_msg = "WEB!"
        else:                                              # bat
            if not o["started"] and 0 < o["s"] - run.pos < o["trig_d"]:
                o["started"] = True
                o["tx"] = frac                              # it aims at where you are NOW and then flies a straight line
                o["lx0"] = o["lx"]
                o["gap0"] = max(60.0, o["s"] - run.pos)
            if o["started"]:
                o["anim"] += 1
                o["s"] -= o["vs"] * 3.0
                gap = o["s"] - run.pos
                prog = max(0.0, min(1.0, 1.0 - gap / o["gap0"]))
                pass                                       # no steering at all: it keeps the line it started on
                if -2.5 < gap < 3.0 and not o["hit"] and abs(frac - o["lx"]) < car_hw + 0.14:
                    o["hit"] = True
                    o["hit_t"] = 90
                    run.bat = 110
                    run.hits += 1
                    run.crash = 30
                    run.crash_msg = "BAT!"
                    run.speed *= 0.985
                    run.damage = min(100.0, run.damage + 2.0)
                    if AUDIO is not None:
                        getattr(AUDIO, "bat", lambda: None)()


def _spider_on(run):
    """a spider lands on the windscreen: wiggle the wheel (or brake hard) to shake it off"""
    run.spider = 520
    run.shake_n = 0
    run.shake_dir = 0
    run.crash = max(run.crash, 24)
    run.crash_msg = "SPIDER!"
    if AUDIO is not None:
        getattr(AUDIO, "bat", lambda: None)()


def _zombie_down(run, o, vx):
    o["hit"] = True
    o["hit_t"] = 0
    o["vx_hit"] = vx
    o["started"] = False
    hid = o.get("horde")
    run.horde_down[hid] = run.horde_down.get(hid, 0) + 1
    n = run.horde_down[hid]
    _bonus(run, 1.0, "+1 SEC  (%d/10)" % n if n < 10 else "")
    if n >= 10:
        _bonus(run, 12.0, "STRIKE!  +12 SEC")
        run.bonus_t = 110
    if AUDIO is not None:
        AUDIO.hit("zombie", 0.04)



HIT_PEN_K = 3.2                 # seconds lost for a hit that stops you dead (scaled down for lighter hits); 0 switches it off


def time_pen(run, keep):
    """crashes cost clock: returns the text to add to the crash message"""
    pen = round(HIT_PEN_K * (1.0 - keep) * 2.0) / 2.0
    if pen <= 0:
        return ""
    run.bonus_time -= pen
    return "  -%g SEC" % pen


TRACTOR_KEEP = 0.10                 # a tractor does not care about you: it leaves almost no speed
TRACTOR_TIME = 6.0                  # seconds lost (other crossing cars: about 2.5)
TRACTOR_DAMAGE = 45                 # ... and a much heavier hit than any other crossing car (those stay at DAMAGE["xcar"])


def hit_hazard(run, o, frac):
    keep, msg = IMPACT[o["kind"]]
    tractor_ = o["kind"] == "xcar" and o.get("kind2") == "tractor"
    if tractor_:
        keep = TRACTOR_KEEP
    o["hit"] = True
    o["hit_t"] = 0
    away = 1.0 if o["lx"] >= frac else -1.0
    o["vx_hit"] = away * (0.03 if o["kind"] in ("cone",) else 0.012)
    if o["kind"] in ("barrier", "faltree", "rock"):
        o["vx_hit"] = 0.0
    run.speed *= keep
    run.car_xv += -away * (2.5 if o["kind"] != "barrier" else 5.0)
    run.hits += 1
    run.crash = 50
    run.crash_msg = msg
    if o["kind"] == "cat":
        run.bonus_time -= 10.0                      # the kitten costs you ten seconds
        run.crash_msg = msg + "  -10 SEC"
    if o["kind"] == "emv" or o.get("scene"):         # an emergency scene: ambulance, patrol car, paramedics, police
        run.bonus_time -= 10.0
        who_ = o.get("who")
        run.crash_msg = ("YOU HIT A PARAMEDIC!" if who_ == "medic" else "YOU HIT A COP!" if who_ == "cop" else msg) + "  -10 SEC"
    if o["kind"] == "costume":
        pen = random.randint(3, 5)                  # so does an unfortunate person in a costume
        run.bonus_time -= pen
        run.crash_msg = "%s  -%d SEC" % (msg, pen)
    add_damage(run, TRACTOR_DAMAGE if tractor_ else DAMAGE.get(o["kind"], 10))
    if tractor_:
        run.bonus_time -= TRACTOR_TIME
        run.crash_msg += "  -%g SEC" % TRACTOR_TIME
    elif o["kind"] not in ("cat", "costume", "witch", "emv") and not o.get("scene"):
        run.crash_msg += time_pen(run, keep)
    if o["kind"] == "witch":
        apply_curse(run, random.choice(("reverse", "bewitch", "blackout", "frozen")))
    elif o["kind"] in ("tomb", "coffin", "ghoul") and random.random() < 0.35:       # smashing graveyard things can anger the dead
        apply_curse(run, random.choice(("bewitch", "blackout", "frozen")))
    if AUDIO is not None:
        AUDIO.hit(o["kind"], 1.0 - keep)
    if o["kind"] == "xcar":                         # the driver you just T-boned leans on the horn
        run.reply = run.frames + random.randint(14, 26)
        run.reply_v = 0.95
        run.reply_k = o.get("kind2")

def update(run, keys):
    if run.state == "countdown":
        run.cd -= 1
        if run.cd <= 40:
            run.state = "race"
            run.go = 40
            run.banner = 200
            run.zone_i = 0
        return
    if run.state not in ("race", "finish", "over"):
        return

    racing = run.state == "race"
    if run.shake_t > 0:
        run.shake_t -= 1
    run.tun_k = max(0.0, min(1.0, (run.pos - TUNNEL[0] + 30.0) / 70.0, (TUNNEL[1] + 60.0 - run.pos) / 90.0)) if (TUNNEL and racing) else 0.0
    td_ = None
    if racing:
        for o_ in HAZ[bisect.bisect_left(HAZ_S, run.pos - 60.0): bisect.bisect_right(HAZ_S, run.pos + 340.0)]:
            if o_["kind"] == "xcar" and o_.get("kind2") == "tractor" and not o_["hit"]:
                d_ = abs(o_["s"] - run.pos)
                td_ = d_ if td_ is None else min(td_, d_)
                gap_ = o_["s"] - run.pos
                if o_["started"] and 40.0 < gap_ < 330.0 and xcar_seen(run, o_):        # it blares at you by itself: a warning from far off, then a louder one as you close in
                    n_h = o_.get("honks", 0)
                    if (n_h == 0 and gap_ < 330.0) or (n_h == 1 and gap_ < 150.0):
                        o_["honks"] = n_h + 1
                        o_["honked"] = True
                        if AUDIO is not None:
                            getattr(AUDIO, "annoyed", lambda v, k=None: None)(0.5 if n_h == 0 else 1.0, "tractor")
    run.tractor_d = td_
    if racing and run.brake > 0.7 and run.speed > 0.45 and run.frames >= run.screech_next:     # standing on the brakes at speed: the tyres scream
        run.screech_next = run.frames + 300
        if AUDIO is not None:
            getattr(AUDIO, "event", lambda *a: None)("tyre_screech", 0.45 + 0.5 * run.speed)
    if run.reply and run.frames >= run.reply:                             # the crossing driver honks back
        run.reply = 0
        if AUDIO is not None:
            getattr(AUDIO, "annoyed", lambda v, k=None: None)(run.reply_v, run.reply_k)
    if run.state == "over":
        run.over_frames += 1

    if run.lid_off:                                          # the dangling leg: a spring, pushed by steering and the wind
        f_ = -run.wheel * run.speed * 0.22 + math.sin(run.pos * 0.045) * run.speed * 0.05 + (random.random() - 0.5) * run.speed * 0.05
        run.legv += f_ - 0.09 * run.leg - 0.045 * run.legv
        run.leg = max(-1.0, min(1.0, run.leg + run.legv))
    if racing:
        gear = run.gear
        if gear < GEARS - 1 and run.speed >= (gear + 1) / GEARS:
            gear += 1                                   # upshift: short power dip
            if keys[pygame.K_UP]:
                run.shift = SHIFT_FRAMES
        elif gear > 0 and run.speed < gear / GEARS - 0.04:
            gear -= 1                                   # downshift with hysteresis, no dip
        run.gear = gear
        if run.shift > 0:
            run.shift -= 1
        if keys[pygame.K_UP]:
            power = SHIFT_POWER if run.shift > 0 else 1.0
            # each gear is strongest at the start of its range and weaker at the end
            gpos = max(0.0, min(1.0, run.speed * GEARS - gear))
            run.speed += max(0.0, ACCEL_TOP - ACCEL_FADE * run.speed) * car_mod("pull") * power * (1.25 - 0.5 * gpos) * (0.0 if run.fx.get("choke") else 1.0)
        run.speed -= DRAG_ROLL + DRAG_AIR * run.speed * run.speed
        if keys[pygame.K_DOWN]:
            bk_ = brake_k()
            run.brake = min(1.0, run.brake + BRAKE_BUILD * (1.0 + (bk_ - 1.0) * 0.5))
            grip = min(1.0, BRAKE_LOW_GRIP + run.speed * 2.0)
            run.speed -= run.brake * BRAKE_MAX * bk_ * grip * (1.0 - 0.62 * abs_k() * mud_k(run.pos)) * (1.0 - 0.55 * abs_k() * min(1.0, run.slick / 30.0))     # wet mud: the brakes hardly bite
        else:
            run.brake = max(0.0, run.brake - 0.15)
        run.speed = max(0.0, min((1.0 - DAMAGE_SPEED_LOSS * run.damage / 100.0) * car_mod("top"), run.speed))

        left, right = keys[pygame.K_LEFT], keys[pygame.K_RIGHT]
        target = (1.0 if right else 0.0) - (1.0 if left else 0.0)
        if run.fx.get("reverse"):
            target = -target
        if run.spider > 0:
            run.spider -= 1
            if target != 0 and target != run.shake_dir:
                run.shake_dir = target
                run.shake_n += 1
            if keys[pygame.K_DOWN] and run.speed > 0.3:
                run.shake_n += 0.06
            if run.shake_n >= 4:
                run.spider = 0
                run.bonus_msg = "GOT IT!"
                run.bonus_t = 80
        if run.web > 0:
            run.web -= 1
        steer_in = WHEEL_IN + (WHEEL_IN_FAST - WHEEL_IN) * run.speed
        if target == 0.0:
            run.wheel += max(-WHEEL_OUT, min(WHEEL_OUT, -run.wheel))
        else:
            # reversing lock (left to right) is quick because you are already unwinding
            rate = steer_in * (1.8 if run.wheel * target < 0 else 1.0)
            run.wheel = max(-1.0, min(1.0, run.wheel + target * rate))
    else:
        run.speed = max(0.0, run.speed - 0.012)
        run.wheel += max(-WHEEL_OUT, min(WHEEL_OUT, -run.wheel))

    # lateral motion: needs speed, softens at the limit, follows the wheel through tyre grip
    reach = min(1.0, run.speed / STEER_MIN_SPEED)
    lat_target = run.wheel * STEER_MAX * reach * (1.0 - 0.30 * run.speed)
    grip = (GRIP_SLOW + (GRIP_FAST - GRIP_SLOW) * run.speed) * car_mod("grip")
    if run.off:
        grip *= 0.7                       # loose surface
    sk = slide_k(run.pos)
    grip *= 1.0 - 0.62 * sk               # loose gravel on the downhill left: tyres let go
    mk = mud_k(run.pos)
    grip *= 1.0 - 0.72 * min(1.0, run.chill / 60.0)       # frozen tyres: the car hardly turns at all
    if run.chill > 0 and run.speed > 0.2:
        run.car_x += math.sin(run.frames * 0.09) * 1.4 * min(1.0, run.chill / 60.0)
    if run.fx.get("bewitch"):                             # drunk driving: the car lurches left and right on its own
        run.car_x += math.sin(run.frames * 0.17) * 3.2 * min(1.0, run.speed * 2.0)
    grip *= 1.0 - 0.42 * mk               # wet mud: the tyres hardly bite
    if run.slick > 0:
        run.slick -= 1
        sl_k = min(1.0, run.slick / 30.0)
        grip *= 1.0 - 0.6 * sl_k          # pumpkin guts: the tyres skate
        if run.speed > 0.2:
            run.car_x += math.sin(run.frames * 0.23) * 1.5 * sl_k * run.speed
    if run.gut > 0:
        run.gut -= 1
    run.car_xv += (lat_target - run.car_xv) * grip
    run.car_x += run.car_xv + run.curve * run.speed * CURVE_PUSH * (1.0 + 1.7 * sk + 0.9 * mk)
    if mk > 0 and run.speed > 0.2:
        run.car_x += math.sin(run.pos * 0.031 + 1.3) * 1.3 * mk * run.speed          # the tail slithers about
        run.speed -= 0.0007 * mk
    if sk > 0 and run.speed > 0.3:
        run.car_x += math.sin(run.pos * 0.045) * 1.6 * sk * run.speed        # the back end wanders
        run.speed = min(1.0, run.speed + 0.0010 * sk)       # rolling downhill
    if run.sparkle > 0:
        run.sparkle -= 1
    if run.chill > 0:
        run.chill -= 1
    for k_ in list(run.fx):
        run.fx[k_] -= 1
        if run.fx[k_] <= 0:
            del run.fx[k_]
    if run.fx_t > 0:
        run.fx_t -= 1
    if run.bat > 0:
        run.bat -= 1
    if run.bonus_t > 0:
        run.bonus_t -= 1
    if run.spook > 0:                                      # a ghost went through you: cold shiver, the wheel shakes
        run.spook -= 1
        run.car_x += math.sin(run.spook * 1.7) * 2.6 * min(1.0, run.speed * 2.0)
    lim = car_half_px(run) + 4
    run.car_x = max(lim, min(W - lim, run.car_x))

    # road edges at the car's y (uses this frame's view)
    hy = int(HORIZON_BASE - run.hill * 10)
    vcx = int(W // 2 + run.curve * 110)
    view.hy, view.vcx = hy, vcx
    view.pos = run.pos
    run.car_scale = 4
    el, er, _ = edge_at(H - 60)
    run.off = not (el < run.car_x < er)
    wi = fork_w(run.pos + 4.0)
    if wi > 0.0 and not run.off:
        nl, nr, _nc = road_at(H - 60)
        frac_i = (run.car_x - (nl + nr) / 2.0) / ((nr - nl) / 2.0)
        if abs(frac_i) < wi + 0.08:
            run.off = True                  # driving over the island
    if run.off and run.speed > OFF_CAP:
        run.speed = max(OFF_CAP, run.speed - OFF_DRAG)

    prev_pos = run.pos
    run.pos += run.speed * M_PER_FRAME
    if racing:
        update_hazards(run, prev_pos)
        update_trip(run)
        update_traffic(run)
        update_rails(run, prev_pos)
        update_roadside(run, prev_pos)
    if run.crash > 0:
        run.crash -= 1

    if run.pos >= LEVEL_LEN:
        ct, ht = 0.0, 0.0
    else:
        sec = section_at(run.pos)
        ct, ht = curve_target(run.pos), sec[3]
    tau_ = THEME.get("curve_tau")
    rate_ = 1.0 - math.exp(-max(0.25, run.speed * M_PER_FRAME) / tau_) if tau_ else THEME.get("curve_rate", 0.012)      # per metre driven (same at any speed), or per frame
    run.curve += (ct - run.curve) * rate_
    run.hill += (ht - run.hill) * 0.010

    if racing:
        run.frames += 1
        if run.go > 0:
            run.go -= 1
        if run.cp_msg > 0:
            run.cp_msg -= 1
        while run.cp_i < len(CHECKPOINTS) and run.pos >= CHECKPOINTS[run.cp_i]:
            run.cp_i += 1
            run.bonus_time += THEME.get("cp_bonus", CP_BONUS) * car_clock()
            run.damage = max(0.0, run.damage - CP_REPAIR)
            run.cp_msg = 150
            if AUDIO is not None:
                AUDIO.chime()
        if run.time_left() <= 0 and run.pos < LEVEL_LEN:
            run.state = "over"
            run.over_reason = "TIME UP"
            run.cause = "TIME UP"
        elif run.damage >= 100.0:
            run.state = "over"
            run.over_reason = "WRECKED"
            run.cause = (run.crash_msg or "").split("  ")[0].strip().rstrip("!").strip() or "WRECKED"

        zi = zone_index(run.pos)
        if zi != run.zone_i:
            run.zone_i = zi
            run.banner = 200
        if run.banner > 0:
            run.banner -= 1
        if run.pos >= LEVEL_LEN:
            run.state = "finish"
            run.finish_time = run.frames / 60.0
            best = RECORD["best"]
            if best is None or run.finish_time < best:
                RECORD["best"] = run.finish_time
                BESTS[LEVEL] = run.finish_time
                run.new_best = True
    elif run.state == "finish":
        run.finish_frames += 1



# ------------------------------------------------------------------ time of day
# the sun sets as you go: bright sunset in the forest, deep dusk in the pass, night in the town
TOD = [(0, (255, 255, 255)), (3200, (255, 236, 220)), (6500, (214, 150, 150)), (9500, (120, 92, 140)),
       (12000, (82, 96, 156)), (99999, (74, 88, 148))]
STARS = []
_sr = random.Random(21)
for _ in range(70):
    STARS.append((_sr.randint(0, W), _sr.randint(4, HORIZON_BASE - 22), _sr.choice((1, 1, 2))))
LIGHTS = []                      # glow points collected while drawing the world (x, y, radius, colour)
_GLOW = {}


def tod_tint(pos):
    tod = THEME.get("tod") or TOD
    for i in range(len(tod) - 1):
        a, b = tod[i], tod[i + 1]
        if a[0] <= pos <= b[0]:
            k = (pos - a[0]) / float(b[0] - a[0])
            return tuple(int(a[1][j] + (b[1][j] - a[1][j]) * k) for j in range(3))
    return tod[-1][1]


def night_amount(pos):
    if THEME.get("night"):
        return 1.0
    return max(0.0, min(1.0, (pos - 6000.0) / 6000.0))


def glow_sprite(r, col):
    key = (r, col)
    if key not in _GLOW:
        sf = pygame.Surface((r * 2, r * 2))
        for i in range(r, 0, -1):
            k = (1.0 - i / float(r)) ** 2
            pygame.draw.circle(sf, tuple(int(c * k) for c in col), (r, r), i)
        _GLOW[key] = sf
    return _GLOW[key]


_WEB = False                              # True = use the plain drawing code everywhere (kept in case the faster code misbehaves in a browser)
BOOT = [lambda msg: None]                 # main.py replaces this to show start-up progress on the loading screen
_STAR_LAYERS = {}
_TINT = {"s": None, "c": None}
_BEAM = {"s": None, "k": None}


def _blit_glow(g, pos, hide):
    """additive glow, except where a nearer vehicle covers it"""
    gr = pygame.Rect(pos[0], pos[1], g.get_width(), g.get_height())
    parts = [gr]
    for h in hide:
        if not h.colliderect(gr):
            continue
        nxt = []
        for q in parts:
            if not q.colliderect(h):
                nxt.append(q)
                continue
            if q.top < h.top:
                nxt.append(pygame.Rect(q.left, q.top, q.width, h.top - q.top))
            if q.bottom > h.bottom:
                nxt.append(pygame.Rect(q.left, h.bottom, q.width, q.bottom - h.bottom))
            mt, mb = max(q.top, h.top), min(q.bottom, h.bottom)
            if q.left < h.left:
                nxt.append(pygame.Rect(q.left, mt, h.left - q.left, mb - mt))
            if q.right > h.right:
                nxt.append(pygame.Rect(h.right, mt, q.right - h.right, mb - mt))
        parts = nxt
    for q in parts:
        if q.width > 0 and q.height > 0:
            screen.blit(g, q.topleft, (q.left - gr.left, q.top - gr.top, q.width, q.height), special_flags=pygame.BLEND_RGB_ADD)


def apply_time_of_day(run):
    tint = tod_tint(run.pos)
    if tint != (255, 255, 255):
        if _WEB:
            ov = pygame.Surface((W, H))
            ov.fill(tint)
            screen.blit(ov, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        else:
            tint = tuple(min(255, int(round(c / 4.0)) * 4) for c in tint)         # fine steps: the overlay is only refilled when the tint really changes
            if _TINT["s"] is None:
                _TINT["s"] = pygame.Surface((W, H))
            if _TINT["c"] != tint:
                _TINT["s"].fill(tint)
                _TINT["c"] = tint
            screen.blit(_TINT["s"], (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    n = night_amount(run.pos)
    if n > 0.25:
        a = min(1.0, (n - 0.25) / 0.5)
        hy = view.hy
        if _WEB:                                                  # browser build: the plain, original way (the faster one trips the browser)
            for (x, y, sz) in STARS:
                if y < hy - 6:
                    c = int(60 + 190 * a)
                    screen.fill((c, c, int(c * 0.95)), (x + int(-run.curve * 6), y, sz, sz))
        else:
            c = int(60 + 190 * a) // 8 * 8                           # one prebuilt star layer per brightness step
            layer = _STAR_LAYERS.get(c)
            if layer is None:
                layer = pygame.Surface((W + 24, HORIZON_BASE))              # plain surface with a colour key (no alpha blending: the browser build trips on that)
                layer.fill((0, 0, 0))
                layer.set_colorkey((0, 0, 0))
                for (x, y, sz) in STARS:
                    layer.fill((c, c, int(c * 0.95)), (x + 12, y, sz, sz))
                _STAR_LAYERS[c] = layer
            screen.set_clip((0, 0, W, max(0, hy - 6)))
            screen.blit(layer, (int(-run.curve * 6) - 12, 0))
            screen.set_clip(None)
        if n > 0.55 and not THEME.get("moon"):
            mx, my = 540 + int(-run.curve * 10), 56
            pygame.draw.circle(screen, (226, 226, 206), (mx, my), 15)
            pygame.draw.circle(screen, (186, 190, 184), (mx - 4, my - 3), 4)
            pygame.draw.circle(screen, (176, 180, 176), (mx + 5, my + 4), 3)
    # headlights on the road ahead
    if n > 0.12:
        cx = int(run.car_x)
        vcx = view.vcx
        by0 = H - 118 + CARS[SET["car"] % len(CARS)].get("top_row", 0) * run.car_scale      # beams start at the car's roof, not above it
        bw = 70 * car_half_px(run) / (18.5 * run.car_scale)         # beams start at the lamps: narrower for a narrower car
        sc = min(1.0, n * 1.6)
        top_b = max(0, min(H - 1, clip_y(Z1 * (H - view.hy) / 70.0)))          # nothing of the beam shows behind a crest
        top_b = max(top_b, view.hy)
        if _WEB:
            beam = pygame.Surface((W, H))
            for k, col in ((1.0, (34, 30, 16)), (0.62, (30, 26, 12)), (0.3, (26, 22, 8))):
                pygame.draw.polygon(beam, col, [(cx - int(bw * k), by0), (cx + int(bw * k), by0),
                                                (vcx + int(14 * k) + int(cx - vcx) * 6 // 10, view.hy + 70),
                                                (vcx - int(14 * k) + int(cx - vcx) * 6 // 10, view.hy + 70)])
            beam.fill((int(255 * sc),) * 3, special_flags=pygame.BLEND_RGB_MULT)
        else:
            beam = _BEAM["s"]
            if beam is None:
                beam = _BEAM["s"] = pygame.Surface((W, H))
            beam.fill((0, 0, 0), (0, top_b, W, H - top_b))                # only the part that will be shown is cleared and drawn
            for k, col in ((1.0, (34, 30, 16)), (0.62, (30, 26, 12)), (0.3, (26, 22, 8))):      # beams ride on the car itself
                pygame.draw.polygon(beam, (int(col[0] * sc), int(col[1] * sc), int(col[2] * sc)),
                                    [(cx - int(bw * k), by0), (cx + int(bw * k), by0),
                                     (vcx + int(14 * k) + int(cx - vcx) * 6 // 10, view.hy + 70),
                                     (vcx - int(14 * k) + int(cx - vcx) * 6 // 10, view.hy + 70)])
        screen.blit(beam, (0, top_b), (0, top_b, W, H - top_b), special_flags=pygame.BLEND_RGB_ADD)
    # glows (street lamps, billboards, tail lights)
    if n > 0.1:
        cars = [c for c in _CAR_RECTS if c[0] is not None]
        ends = [c[1] for c in _CAR_RECTS]
        for k, (x, y, r, col) in enumerate(LIGHTS):
            g = glow_sprite(r, col)
            own = None                                                         # which vehicle (if any) this light belongs to
            for i in range(len(cars)):
                if cars[i][1] <= k < ends[i + 1]:
                    own = i
                    break
            hide = [cars[j][0] for j in range(len(cars)) if own is None or j > own]    # vehicles in front of the light hide its glow
            _blit_glow(g, (x - r, y - r), hide)
        del _CAR_RECTS[:]
    del LIGHTS[:]


# ------------------------------------------------------------------ drawing: world
def _spooky_sky(hy, curve):
    """halloween: a deep purple night, a huge pale moon, torn clouds, bats"""
    px = int(-curve * 25)
    top, bot = (8, 6, 22), (84, 52, 112)
    n = 24
    for i in range(n):
        k = i / (n - 1.0)
        c = tuple(int(top[j] + (bot[j] - top[j]) * k ** 1.6) for j in range(3))
        y0, y1 = hy * i // n, hy * (i + 1) // n
        pygame.draw.rect(screen, c, (0, y0, W, y1 - y0 + 1))
    mx, my = 470 + px, int(hy * 0.52)
    halo = glow_sprite(120, (70, 60, 40))
    screen.blit(halo, (mx - 120, my - 120), special_flags=pygame.BLEND_RGB_ADD)
    pygame.draw.circle(screen, (238, 232, 200), (mx, my), 44)
    pygame.draw.circle(screen, (214, 206, 176), (mx - 14, my - 10), 11)
    pygame.draw.circle(screen, (206, 198, 168), (mx + 16, my + 12), 8)
    pygame.draw.circle(screen, (222, 214, 184), (mx + 10, my - 18), 5)
    for cx, cy, cw, ch in CLOUDS:
        x = cx + px
        pygame.draw.ellipse(screen, (26, 18, 44), (x, cy + 10, cw, ch))
        pygame.draw.ellipse(screen, (44, 30, 70), (x + 8, cy + 14, cw - 14, max(4, ch - 14)))
    t = pygame.time.get_ticks() / 1000.0
    for i in range(5):                                      # bats crossing the moon
        bx = int((W + 160) * ((t * (0.045 + i * 0.012) + i * 0.21) % 1.0)) - 80 + px
        by = int(hy * (0.22 + 0.5 * ((i * 0.37) % 0.6))) + int(math.sin(t * 2.3 + i) * 9)
        fl = int(math.sin(t * 16 + i * 2) * 5)
        pygame.draw.polygon(screen, (10, 8, 16), [(bx, by), (bx - 11, by - 5 - fl), (bx - 6, by + 1),
                                                  (bx, by + 3), (bx + 6, by + 1), (bx + 11, by - 5 - fl)])


def draw_sky(hy, curve):
    if THEME.get("sky"):
        _spooky_sky(hy, curve)
        return
    px = int(-curve * 25)
    b = hy // 4
    pygame.draw.rect(screen, (60, 20, 10), (0, 0, W, b))
    pygame.draw.rect(screen, (110, 45, 15), (0, b, W, b))
    pygame.draw.rect(screen, (160, 75, 20), (0, 2 * b, W, b))
    pygame.draw.rect(screen, (210, 120, 30), (0, 3 * b, W, hy - 3 * b))
    for cx, cy, cw, ch in CLOUDS:
        x = cx + px
        pygame.draw.ellipse(screen, (80, 30, 10), (x, cy, cw, ch))
        pygame.draw.ellipse(screen, (120, 55, 15), (x + 8, cy + 4, cw - 12, ch - 8))
        pygame.draw.ellipse(screen, (180, 100, 20), (x + 4, cy + ch - 6, cw - 8, 10))


def draw_ridge(pts, hy, dx, col):
    poly = [(-160 + dx, hy)] + [(x + dx, hy - h) for x, h in pts] + [(W + 160 + dx, hy)]
    pygame.draw.polygon(screen, col, poly)


def _lerp_col(c0, c1, f):
    return (int(c0[0] + (c1[0] - c0[0]) * f), int(c0[1] + (c1[1] - c0[1]) * f), int(c0[2] + (c1[2] - c0[2]) * f))


GROUND_A, GROUND_B = (30, 22, 14), (36, 27, 17)
ROAD_A, ROAD_B = (110, 70, 45), (105, 66, 42)
HAZE = (112, 62, 26)


_LOD = 1.8 if sys.platform == "emscripten" else 1.0


def _profile(run):
    """depth samples along the road ahead and where each lands on screen; remembers the highest point reached"""
    zs = []
    z = Z1 * 0.7
    while z < DRAW_DIST + Z1:
        zs.append(z)
        z += (1.6 if z < 30 else (3.0 if z < 90 else (6.0 if z < 220 else (12.0 if z < 460 else 24.0)))) * _LOD     # phones: fewer, wider road strips
    ys = [proj_y(z) for z in zs]
    mins = []
    m = 1e9
    for y in ys:
        m = min(m, y)
        mins.append(m)
    view.prof_z, view.prof_y, view.prof_min = zs, ys, mins
    return zs, ys, mins


def draw_road(run):
    hy, vcx = view.hy, view.vcx
    view.pos = run.pos
    view.e0 = elev(run.pos)
    rb, rf = THEME.get("ridge", ((92, 40, 14), (58, 24, 10)))
    gA, gB = THEME.get("ground", (GROUND_A, GROUND_B))
    rdA, rdB = THEME.get("road", (ROAD_A, ROAD_B))
    haze = THEME.get("haze", HAZE)
    hk_g, hk_r = THEME.get("haze_k", (0.55, 0.35))
    fogd = THEME.get("fog_dist", DRAW_DIST)
    fk_ = fog_k(run.pos)
    fogd *= 1.0 - 0.7 * fk_
    hk_r = hk_r + (0.9 - hk_r) * fk_
    edge1, edge2 = THEME.get("edge", ((230, 190, 40), (200, 160, 30)))
    dashc = THEME.get("dash", (222, 182, 44))
    draw_ridge(RIDGE_BACK, hy, int(-run.curve * 40), rb)
    draw_ridge(RIDGE_FRONT, hy, int(-run.curve * 70), rf)
    hz1, hz2 = THEME.get("horizon", ((220, 140, 30), (255, 200, 60)))
    pygame.draw.rect(screen, hz1, (0, hy - 3, W, 6))
    pygame.draw.rect(screen, hz2, (0, hy - 1, W, 2))
    pygame.draw.rect(screen, gA, (0, hy, W, H - hy))

    zs, ys, mins = _profile(run)
    # terrain and road, built from quads between depth samples; whatever lies behind a crest is simply not drawn
    prev_l = prev_r = None
    _ed = {}
    for i in range(len(zs) - 1):
        yb = ys[i + 1]
        floor_y = mins[i]                                  # lowest row not yet covered by nearer ground
        if yb >= floor_y:
            continue
        zb = zs[i + 1]
        lb, rb, _cb = _ed[i + 1] = _ed.get(i + 1) or edges_zd(zb)
        la, ra, _ca = _ed[i] = _ed.get(i) or edges_zd(zs[i])
        bot = min(floor_y, H + 2)
        top = int(yb)
        ya = ys[i]
        if ya > bot:                                       # the near end is below the screen: cut the edges where they cross the bottom row
            f = (ya - bot) / max(1e-6, ya - yb)
            la, ra = la + (lb - la) * f, ra + (rb - ra) * f
        h_f = min(1.0, (zb / fogd) ** 1.3)
        band = int((run.pos + zb - Z1) // 24.0) % 2
        gcol = _lerp_col(gA if band == 0 else gB, haze, h_f * hk_g)
        rcol = _lerp_col(rdA if band == 0 else rdB, haze, h_f * hk_r)
        pygame.draw.rect(screen, gcol, (0, top, W, int(bot) - top + 1))
        wpos = run.pos + zb - Z1
        gk = slide_k(wpos)
        mk_ = mud_k(wpos)
        if mk_ > 0.0:                                       # churned brown mud, wet and shiny in places
            rcol = _lerp_col(rcol, ((74, 54, 40), (66, 48, 36))[band], min(1.0, mk_ * 1.1) * (1.0 - h_f * 0.5))
            gcol = _lerp_col(gcol, (30, 24, 20), mk_ * 0.8)
        if TUNNEL and TUNNEL[0] < wpos < TUNNEL[1]:         # inside the tunnel: dark tarmac with a pool of orange light under every lamp
            lamp = (wpos % 24.0) < 7.0
            rcol = _lerp_col(rcol, (62, 62, 76) if lamp else (34, 38, 54), 0.7 if lamp else 0.85)
            gcol = (12, 16, 26)
        if gk > 0.0:                                        # loose gravel: paler, and speckled so you can see it
            gv = ((118, 116, 134), (108, 106, 124)) if THEME.get("night") else ((128, 108, 88), (118, 100, 82))
            rcol = _lerp_col(rcol, gv[band], min(1.0, gk * 1.2))
        pygame.draw.polygon(screen, rcol, [(la, bot), (ra, bot), (rb, yb), (lb, yb)])
        if gk > 0.2 and (bot - top) >= 1:
            seed = int((run.pos + zb - Z1) // 2.5)
            n = 12 + int(40 * (Z1 / zb) ** 0.5)
            sz = max(2, int(5 * (Z1 / zb) ** 0.7))
            for q in range(n):
                hsh = (seed * 73856093 ^ q * 19349663 ^ i * 83492791) & 0xFFFFFF
                fx = (hsh & 1023) / 1023.0
                fy = ((hsh >> 10) & 1023) / 1023.0
                px = la + (ra - la) * fx + (lb - la + (rb - ra - lb + la) * fx) * 0.0
                py = top + (bot - top) * fy
                cc = ((190, 168, 138), (84, 66, 50), (150, 128, 100), (214, 196, 160))[(hsh >> 20) & 3]
                if THEME.get("night"):
                    cc = ((150, 150, 170), (50, 48, 62), (110, 108, 130), (186, 186, 204))[(hsh >> 20) & 3]
                pygame.draw.rect(screen, cc, (int(px), int(py), sz, max(1, sz // 2 + 1)))
        if mk_ > 0.3 and (bot - top) >= 1:                  # puddles that catch the lightning
            seed = int((run.pos + zb - Z1) // 3.5)
            for q in range(2):
                hsh = (seed * 73856093 ^ q * 19349663 ^ i * 83492791) & 0xFFFFFF
                fx = 0.1 + 0.8 * (hsh & 1023) / 1023.0
                fy = ((hsh >> 10) & 1023) / 1023.0
                pw_ = max(3, int((ra - la) * (0.04 + 0.06 * ((hsh >> 20) & 3) / 3.0)))
                px = la + (ra - la) * fx
                py = top + (bot - top) * fy
                pygame.draw.ellipse(screen, (62, 54, 70) if q else (92, 94, 128), (int(px - pw_ / 2), int(py), pw_, max(1, int(pw_ * 0.16 * (1 + (bot - top) * 0.1)))))
        wl = max(1, int(1 + 4 * (Z1 / zb)))
        for (xa, xb) in ((la, lb), (ra, rb)):
            inner = 0.012 * (rb - lb) * (1 if xa == la else -1)
            pygame.draw.line(screen, _lerp_col(edge1, haze, h_f * 0.4), (xa + inner, bot), (xb + inner, yb), wl)
            pygame.draw.line(screen, _lerp_col(edge2, haze, h_f * 0.4), (xa + (-6 if xa == la else 6) * (Z1 / zb), bot),
                             (xb + (-6 if xa == la else 6) * (Z1 / zb), yb), max(1, wl - 1))

    def clipped(zd):
        screen.set_clip((0, 0, W, max(0, clip_y(zd))))

    # four-way intersections: a cross street runs the full width of the screen
    for istreet in INTERSECTIONS:
        a = (istreet - STREET_HALF) - run.pos + Z1
        b = a + 2 * STREET_HALF
        if a > DRAW_DIST or b < Z1 * 0.7:
            continue
        a0 = max(a, Z1 * 0.7)
        y0 = int(proj_y(a0))
        y1 = int(proj_y(b))
        if y0 - y1 < 1:
            y1 = y0 - 1
        clipped(a0)
        pygame.draw.rect(screen, THEME["road"][1] if THEME.get("road") else (104, 66, 42), (0, y1, W, y0 - y1 + 1))
        kc = THEME["edge"][1] if THEME.get("edge") else (196, 156, 36)
        pygame.draw.line(screen, kc, (0, y1), (W, y1), 2)                       # kerb lines
        pygame.draw.line(screen, kc, (0, y0), (W, y0), 2)
        # dashed centre line of the cross street
        am = a + STREET_HALF
        if am > Z1 * 0.7:
            ym = int(proj_y(am))
            tm = Z1 / am
            seg = max(2, int(3.0 * PXM * tm))
            thick = max(1, int(0.35 * PXM * tm))
            start = int(view.vcx % (2 * seg))
            x = start - 2 * seg
            while x < W:
                pygame.draw.rect(screen, dashc, (x, ym - thick // 2, seg, thick))
                x += 2 * seg
        # stop line across our side of the road
        sa = (istreet - STREET_HALF - 2.0) - run.pos + Z1
        if sa > Z1 * 0.7:
            ys_ = int(proj_y(sa))
            ys2 = int(proj_y(sa + 0.6))
            l0, r0, _c = road_at_t(Z1 / sa)
            pygame.draw.rect(screen, (222, 210, 180), (int(l0), ys2, int(r0 - l0), max(2, ys_ - ys2)))
        screen.set_clip(None)

    # zebra crossings
    for cs in CROSSWALKS:
        a = (cs - 2.0) - run.pos + Z1
        if a > DRAW_DIST or a + 4.0 < Z1 * 0.7:
            continue
        a0, b0 = max(a, Z1 * 0.7), a + 4.0
        y0 = int(proj_y(a0))
        y1 = int(proj_y(b0))
        l0, r0, _c = road_at_t(Z1 / a0)
        l1, r1, _c = road_at_t(Z1 / b0)
        clipped(a0)
        for k in range(-5, 6):
            f0, f1 = (k * 0.17 - 0.06 + 1) / 2, (k * 0.17 + 0.06 + 1) / 2
            pygame.draw.polygon(screen, (214, 200, 168),
                                [(l0 + (r0 - l0) * f0, y0), (l0 + (r0 - l0) * f1, y0),
                                 (l1 + (r1 - l1) * f1, y1), (l1 + (r1 - l1) * f0, y1)])
        screen.set_clip(None)

    # island between the two branches of a fork
    for f in FORKS:
        u0 = max(0.0, run.pos - 6.0 - f)
        u1 = min(FORK_LEN, run.pos + DRAW_DIST - f)
        if u1 <= u0:
            continue
        u = u1
        while u > u0:
            un = max(u0, u - (5.0 if (f + u - run.pos) < 160 else 12.0))
            a = (f + u) - run.pos + Z1
            b = (f + un) - run.pos + Z1
            if a > Z1 * 0.7:
                a = max(a, Z1 * 0.7)
                b = max(b, Z1 * 0.7)
                ya = int(proj_y(a))
                yb = int(proj_y(b))
                la, ra, _c = road_at_t(Z1 / a)
                lb, rb, _c2 = road_at_t(Z1 / b)
                wa, wb = fork_w(f + u), fork_w(f + un)
                xa0 = la + (ra - la) * (1 - wa) / 2.0
                xa1 = la + (ra - la) * (1 + wa) / 2.0
                xb0 = lb + (rb - lb) * (1 - wb) / 2.0
                xb1 = lb + (rb - lb) * (1 + wb) / 2.0
                clipped(b)
                pygame.draw.polygon(screen, (44, 32, 20), [(xa0, ya), (xa1, ya), (xb1, yb), (xb0, yb)])
                pygame.draw.line(screen, (214, 176, 40), (xa0, ya), (xb0, yb), 2)
                pygame.draw.line(screen, (214, 176, 40), (xa1, ya), (xb1, yb), 2)
                screen.set_clip(None)
            u = un

    # centre dashes, fixed in the world so they stream past at the right speed
    period, dash = 18.0, 7.0
    off = run.pos % period
    k = 0
    while True:
        a = k * period - off + Z1
        k += 1
        if a > DRAW_DIST:
            break
        wpos = run.pos + a - Z1
        if near_intersection(wpos, STREET_HALF + 4):
            continue
        b = a + dash
        if b < Z1 * 0.7:
            continue
        a = max(a, Z1 * 0.7)
        y0 = int(proj_y(a))
        y1 = int(proj_y(b))
        l0, r0, c0 = edges_zd(a)
        l1, r1, c1 = edges_zd(b)
        w0 = max(1, int((r0 - l0) * 0.018))
        w1 = max(1, int((r1 - l1) * 0.018))
        wm = fork_w(wpos)
        wf = wide_f(wpos)
        if wm > 0.02:                       # two roadways: a dash line down the middle of each branch
            lanes = ()                      # no centre lines on the two branches
        elif wf > 1.0:                      # three lanes: the centre dash splits into two lane dividers
            kk = (wf - 1.0) / (WIDE_MAX - 1.0)
            lanes = (-kk / 3.0, kk / 3.0)
        else:
            lanes = (None,)
        clipped(a)
        for lane in lanes:
            if lane is None:
                cc0, cc1 = c0, c1
            else:
                cc0 = l0 + (r0 - l0) * (lane + 1.0) / 2.0
                cc1 = l1 + (r1 - l1) * (lane + 1.0) / 2.0
            pygame.draw.polygon(screen, dashc,
                                [(cc0 - w0, y0), (cc0 + w0, y0), (cc1 + w1, y1), (cc1 - w1, y1)])
        screen.set_clip(None)


# ------------------------------------------------------------------ drawing: scenery
def _draw_tree(name, variant, ox, y, t, o):
    spr = sprites.get(name, variant)
    sh = int(sprites.HEIGHT_M[name] * o["k"] * PXM * (t ** 0.9))
    if sh < 4:
        return
    sw = max(2, int(spr.get_width() / spr.get_height() * sh))
    screen.blit(pygame.transform.scale(spr, (sw, sh)), (ox - sw // 2, y - sh))


def draw_pine(ox, y, sc, o):
    _draw_tree("pine", int(o["s"]) % 2, ox, y, sc, o)


def draw_maple(ox, y, sc, o):
    """an autumn tree with an orange, yellow, red or rust crown"""
    _draw_tree("maple", int(o["s"]) % 4, ox, y, sc, o)


def draw_deadtree(ox, y, sc, o):
    _draw_tree("deadtree", 0, ox, y, sc, o)


def _draw_prop(name, variant, ox, y, t, o, glow=None):
    spr = sprites.get(name, variant)
    sh = int(sprites.HEIGHT_M[name] * o["k"] * PXM * (t ** 0.9))
    if sh < 3:
        return
    sw = max(2, int(spr.get_width() / spr.get_height() * sh))
    screen.blit(pygame.transform.scale(spr, (sw, sh)), (ox - sw // 2, y - sh))
    if glow and sh > 8:
        LIGHTS.append((ox, y - sh // 2, max(6, int(sh * 1.4)), glow))


def draw_pumpkin(ox, y, sc, o):
    _draw_prop("pumpkin", 0, ox, y, sc, o, glow=(150, 80, 14))


def draw_gravestone(ox, y, sc, o):
    _draw_prop("gravestone", o.get("v", 0), ox, y, sc, o)


def draw_house(ox, y, sc, o):
    """a crooked haunted house on the hill: pointed roof, a tower, a few lit windows"""
    w, h = int(o["w"] * sc), int(o["h"] * sc)
    if w < 4:
        return
    x0 = ox if o["side"] > 0 else ox - w
    wall, dark = (36, 30, 44), (22, 18, 30)
    pygame.draw.rect(screen, wall, (x0, y - h, w, h))
    roof = [(x0 - w // 10, y - h), (x0 + w // 2, y - h - int(h * 0.55)), (x0 + w + w // 10, y - h)]
    pygame.draw.polygon(screen, dark, roof)
    tw = int(w * 0.22)                                                  # crooked tower
    tx = x0 + int(w * 0.68)
    pygame.draw.rect(screen, wall, (tx, y - h - int(h * 0.55), tw, int(h * 0.7)))
    pygame.draw.polygon(screen, dark, [(tx - tw // 5, y - h - int(h * 0.55)), (tx + tw // 2 + int(tw * 0.15), y - h - int(h * 0.95)),
                                       (tx + tw + tw // 5, y - h - int(h * 0.55))])
    cw, ch = max(2, int(w * 0.13)), max(2, int(h * 0.17))
    for row in range(2):
        for col in range(4):
            lit = o["lit"][row * 4 + col]
            c = ((226, 180, 56) if (col + row) % 2 == 0 else (120, 220, 120)) if lit else (14, 10, 20)
            pygame.draw.rect(screen, c, (x0 + int(w * (0.1 + col * 0.22)), y - h + int(h * (0.18 + row * 0.38)), cw, ch))
            if lit and sc > 0.03:
                LIGHTS.append((x0 + int(w * (0.1 + col * 0.22)) + cw // 2, y - h + int(h * (0.18 + row * 0.38)) + ch // 2,
                               max(6, int(w * 0.14)), (110, 84, 20) if (col + row) % 2 == 0 else (30, 90, 30)))
    pygame.draw.rect(screen, (14, 10, 20), (x0 + w // 2 - cw // 2, y - ch * 2, cw, ch * 2))      # door


def draw_crypt(ox, y, sc, o):
    """a little stone mausoleum with pillars and a cross"""
    w, h = int(o["w"] * sc), int(o["h"] * sc)
    if w < 4:
        return
    x0 = ox if o["side"] > 0 else ox - w
    st, lt, dk = (96, 98, 108), (132, 134, 144), (56, 58, 66)
    pygame.draw.rect(screen, st, (x0, y - h, w, h))
    pygame.draw.polygon(screen, lt, [(x0 - w // 12, y - h), (x0 + w // 2, y - h - int(h * 0.35)), (x0 + w + w // 12, y - h)])
    pygame.draw.rect(screen, dk, (x0 + w // 3, y - int(h * 0.65), w // 3, int(h * 0.65)))
    for px_ in (x0 + w // 8, x0 + w - w // 8 - max(2, w // 10)):
        pygame.draw.rect(screen, lt, (px_, y - h, max(2, w // 10), h))
    cx = x0 + w // 2
    pygame.draw.rect(screen, lt, (cx - max(1, w // 40), y - h - int(h * 0.62), max(2, w // 20), int(h * 0.3)))
    pygame.draw.rect(screen, lt, (cx - max(2, w // 14), y - h - int(h * 0.52), max(4, w // 7), max(2, w // 22)))


def draw_rock(ox, y, sc, o):
    r = int(34 * sc * o["k"])
    if r < 2:
        return
    pts = [(ox - r, y), (ox - int(r * .8), y - int(r * .7)), (ox - int(r * .2), y - r),
           (ox + int(r * .6), y - int(r * .8)), (ox + r, y)]
    pygame.draw.polygon(screen, (64, 48, 36), pts)
    pygame.draw.polygon(screen, (84, 64, 46), [(ox - int(r * .5), y - int(r * .6)), (ox - int(r * .2), y - r),
                                               (ox + int(r * .3), y - int(r * .7)), (ox, y - int(r * .4))])


def draw_lamp(ox, y, sc, o):
    h, pw = int(130 * sc), max(2, int(6 * sc))
    pygame.draw.rect(screen, (72, 68, 62), (ox - pw // 2, y - h, pw, h))
    x1 = ox - o["side"] * int(34 * sc)
    pygame.draw.line(screen, (72, 68, 62), (ox, y - h), (x1, y - h), max(2, int(5 * sc)))
    lc = THEME.get("lamp", ((244, 206, 96), (255, 214, 120)))
    pygame.draw.rect(screen, lc[0], (x1 - int(9 * sc), y - h, int(18 * sc), max(2, int(6 * sc))))
    if sc > 0.03:
        LIGHTS.append((x1, y - h + 2, max(6, int(46 * sc)), lc[1]))


def draw_factory(ox, y, sc, o):
    w, h = int(o["w"] * sc), int(o["h"] * sc)
    if w < 3:
        return
    x0 = ox if o["side"] > 0 else ox - w
    pygame.draw.rect(screen, (38, 28, 26), (x0, y - h, w, h))
    pygame.draw.rect(screen, (26, 18, 16), (x0, y - h, w, max(2, int(10 * sc))))
    cw, ch = max(2, int(w * 0.16)), max(2, int(h * 0.2))
    for row in range(2):
        for col in range(4):
            lit = o["lit"][row * 4 + col]
            c = (214, 134, 42) if lit else (20, 15, 14)
            pygame.draw.rect(screen, c, (x0 + int(w * (0.08 + col * 0.23)), y - h + int(h * (0.2 + row * 0.34)), cw, ch))
    cx = x0 + int(w * 0.72)
    pygame.draw.rect(screen, (32, 24, 22), (cx, y - h - int(60 * sc), max(2, int(22 * sc)), int(60 * sc)))
    pygame.draw.ellipse(screen, (84, 62, 52), (cx - int(6 * sc), y - h - int(86 * sc), int(34 * sc), int(24 * sc)))


_SIL = {}


def silhouette(name, frame=0):
    key = (name, frame)
    if key not in _SIL:
        spr = sprites.get(name, frame)
        _SIL[key] = pygame.mask.from_surface(spr).to_surface(setcolor=(22, 14, 8, 255), unsetcolor=(0, 0, 0, 0))
    return _SIL[key]


def draw_glyph_sign(ox, y, sc, o):
    ph, pw = int(120 * sc), max(2, int(6 * sc))
    pygame.draw.rect(screen, (72, 68, 62), (ox - pw // 2, y - ph, pw, ph))
    cy, r = y - ph - int(30 * sc), int(40 * sc)
    if r < 3:
        return
    diamond = [(ox, cy - r), (ox + r, cy), (ox, cy + r), (ox - r, cy)]
    fill = (244, 130, 30) if o["glyph"] == "work" else (238, 198, 36)
    pygame.draw.polygon(screen, fill, diamond)
    pygame.draw.polygon(screen, (22, 14, 8), diamond, max(1, int(3 * sc)))
    if o["glyph"] == "split":
        a = max(2, int(r * 0.6))
        w = max(1, int(r * 0.16))
        pygame.draw.line(screen, (22, 14, 8), (ox, cy + a), (ox, cy), w * 2)
        pygame.draw.line(screen, (22, 14, 8), (ox, cy), (ox - a, cy - a), w * 2)
        pygame.draw.line(screen, (22, 14, 8), (ox, cy), (ox + a, cy - a), w * 2)
        return
    if o["glyph"] == "tree":
        a = max(2, int(r * 0.7))
        w = max(1, int(r * 0.16))
        pygame.draw.line(screen, (22, 14, 8), (ox - a, cy + a), (ox + a // 2, cy - a // 2), w * 2)
        pygame.draw.circle(screen, (22, 14, 8), (ox + a // 2, cy - a // 2), max(2, int(a * 0.5)))
        return
    if o["glyph"] == "tunnel":
        a = max(2, int(r * 0.6))
        pygame.draw.rect(screen, (22, 14, 8), (ox - a, cy - a // 3, 2 * a, a + a // 3))
        pygame.draw.circle(screen, (22, 14, 8), (ox, cy - a // 3), a)
        pygame.draw.rect(screen, fill, (ox - a // 2, cy - a // 6, a, a * 2 // 3 + 1))
        pygame.draw.circle(screen, fill, (ox, cy - a // 6), a // 2)
        return
    if o["glyph"] == "shroom":
        a = max(2, int(r * 0.62))
        pygame.draw.rect(screen, (22, 14, 8), (ox - a // 3, cy, 2 * a // 3, a))
        pygame.draw.ellipse(screen, (22, 14, 8), (ox - a, cy - a, 2 * a, int(a * 1.3)))
        pygame.draw.circle(screen, fill, (ox - a // 3, cy - a // 2), max(1, a // 5))
        pygame.draw.circle(screen, fill, (ox + a // 3, cy - a // 3), max(1, a // 6))
        return
    if o["glyph"] == "emv":
        a = max(2, int(r * 0.7))
        w = max(1, int(r * 0.22))
        pygame.draw.rect(screen, (200, 30, 24), (ox - w, cy - a, 2 * w, 2 * a))
        pygame.draw.rect(screen, (200, 30, 24), (ox - a, cy - w, 2 * a, 2 * w))
        return
    if o["glyph"] == "cross":
        a = max(2, int(r * 0.7))
        w = max(1, int(r * 0.22))
        pygame.draw.rect(screen, (22, 14, 8), (ox - w, cy - a, 2 * w, 2 * a))
        pygame.draw.rect(screen, (22, 14, 8), (ox - a, cy - w, 2 * a, 2 * w))
        return
    if o["glyph"] == "rail":
        a = max(2, int(r * 0.62))
        w = max(1, int(r * 0.13))
        pygame.draw.line(screen, (22, 14, 8), (ox - a, cy - a), (ox + a, cy + a), w * 2)
        pygame.draw.line(screen, (22, 14, 8), (ox - a, cy + a), (ox + a, cy - a), w * 2)
        return
    if o["glyph"] == "rocks":
        a = max(2, int(r * 0.6))
        for dx_, dy_, rr in ((-a // 2, a // 3, a // 3), (a // 3, -a // 3, a // 4), (a // 2, a // 2, a // 3)):
            pygame.draw.circle(screen, (22, 14, 8), (ox + dx_, cy + dy_), max(1, rr))
        pygame.draw.line(screen, (22, 14, 8), (ox - a, cy + a), (ox + a, cy + a), max(1, a // 4))
        return
    if o["glyph"] == "logs":
        a = max(2, int(r * 0.42))
        for dx_, dy_ in ((-a, a // 2), (0, a // 2), (a, a // 2), (-a // 2, -a // 2), (a // 2, -a // 2)):
            pygame.draw.circle(screen, (22, 14, 8), (ox + dx_, cy + dy_), max(1, int(a * 0.55)))
            pygame.draw.circle(screen, fill, (ox + dx_, cy + dy_), max(1, int(a * 0.25)))
        return
    if o["glyph"] == "slip":
        a = max(2, int(r * 0.55))
        w = max(1, int(r * 0.12))
        for dx in (-a // 2, a // 2):
            pts = [(ox + dx + int(math.sin(k * 1.3) * a * 0.35), cy - a + k * a // 3) for k in range(7)]
            pygame.draw.lines(screen, (22, 14, 8), False, pts, w * 2)
        return
    name = {"deer": "deer", "work": "worker", "ped": "ped", "ghost": "ghost", "coffin": "coffin",
            "zombie": "zombie", "bat": "bat", "spider": "spider", "witch": "witchland", "boar": "boar"}[o["glyph"]]
    fr = 2 if name in ("deer", "boar") else 0
    sil = silhouette(name, fr)
    gh = int(r * 1.05)
    gw = max(1, int(sil.get_width() * gh / sil.get_height()))
    if gh >= 3:
        screen.blit(pygame.transform.scale(sil, (gw, gh)), (ox - gw // 2, cy - gh // 2))


def draw_sign(ox, y, sc, o):
    if o.get("glyph"):
        draw_glyph_sign(ox, y, sc, o)
        return
    d = o["dir"]
    ph, pw = int(120 * sc), max(2, int(6 * sc))
    pygame.draw.rect(screen, (72, 68, 62), (ox - pw // 2, y - ph, pw, ph))
    cy, r = y - ph - int(26 * sc), int(34 * sc)
    if r < 3:
        return
    diamond = [(ox, cy - r), (ox + r, cy), (ox, cy + r), (ox - r, cy)]
    pygame.draw.polygon(screen, (238, 198, 36), diamond)
    pygame.draw.polygon(screen, (22, 14, 8), diamond, max(1, int(3 * sc)))
    a = int(18 * sc)
    if a >= 2:
        pygame.draw.line(screen, (22, 14, 8), (ox - d * a, cy), (ox + d * a // 3, cy), max(2, int(6 * sc)))
        pygame.draw.polygon(screen, (22, 14, 8), [(ox + d * a, cy), (ox + d * a // 3, cy - int(11 * sc)),
                                                  (ox + d * a // 3, cy + int(11 * sc))])


def draw_finish(y, sc, cols=((240, 240, 240), (20, 20, 20))):
    el, er, _ = edges_zd(Z1 / sc)                                             # follows the road when it widens
    big_ = cols[0] == (240, 240, 240)
    n = 14
    cw = (er - el) / n
    sh = max(2, int((14 if not big_ else 22) * sc))
    for i in range(n):
        for r in range(2):
            col = cols[0] if (i + r) % 2 == 0 else cols[1]
            pygame.draw.rect(screen, col, (int(el + i * cw), y - sh + r * (sh // 2), int(cw) + 1, sh // 2 + 1))
    big = cols[0] != (240, 240, 240)                                          # the yellow checkpoint gate is much bigger than the plain finish
    post_h = int((520 if big else 720) * sc)                                  # the finish gate stands taller than the checkpoint gate
    pw = max(3, int(28 * sc))
    pygame.draw.rect(screen, (60, 56, 52), (int(el) - pw, y - post_h, pw, post_h))
    pygame.draw.rect(screen, (60, 56, 52), (int(er), y - post_h, pw, post_h))
    bh = max(4, int(130 * sc))
    n2 = 22
    bw = (er - el) / n2
    for i in range(n2):
        for r in range(2):
            col = cols[0] if (i + r) % 2 == 0 else cols[1]
            pygame.draw.rect(screen, col, (int(el + i * bw), y - post_h + r * (bh // 2), int(bw) + 1, bh // 2 + 1))
    if big and bh >= 14:
        plate = pygame.Rect(int(el + (er - el) * 0.18), y - post_h + bh // 6, int((er - el) * 0.64), int(bh * 0.68))
        pygame.draw.rect(screen, (24, 20, 10), plate)
        pygame.draw.rect(screen, (250, 220, 60), plate, max(1, int(3 * sc)))
        ts_ = font_mid.render("CHECKPOINT", True, (255, 226, 70))
        fh_ = max(6, int(plate.height * 0.62))
        ts_ = pygame.transform.scale(ts_, (min(plate.width - 6, int(ts_.get_width() * fh_ / ts_.get_height())), fh_))
        screen.blit(ts_, (plate.centerx - ts_.get_width() // 2, plate.centery - fh_ // 2))
        LIGHTS.append((plate.centerx, plate.centery, max(12, int(plate.width * 0.5)), (255, 200, 40)))



SMOKE = []


CUR_POS = [0.0]


def draw_limb(y, g, el, er, tip_lx, side):
    """a dead tree at the roadside whose big branch bends out over the road to lx; returns the y of the branch tip"""
    tip_x = el + (tip_lx + 1.0) / 2.0 * (er - el)
    tx = (er + 0.9 * g) if side > 0 else (el - 0.9 * g)
    top_y = y - 5.6 * g
    tip_y = y - 4.6 * g
    wood, lite = (44, 34, 32), (74, 60, 54)
    tw = max(2, int(0.8 * g))
    if g < 1.5:
        return int(tip_y)
    pygame.draw.polygon(screen, wood, [(tx - tw, y), (tx + tw, y), (tx + tw // 2, top_y), (tx - tw // 2, top_y)])
    pygame.draw.line(screen, lite, (tx - tw // 2, y), (tx - tw // 4, top_y), 1)
    pts = []
    for i in range(13):                                                      # the limb arches up, then bends down towards the tip
        f = i / 12.0
        bx = tx + (tip_x - tx) * f
        by = top_y + (tip_y - top_y) * f - math.sin(f * math.pi) * 0.9 * g
        pts.append((bx, by))
    for i in range(12):
        w_ = max(1, int(tw * (1.0 - i / 14.0) * 0.8))
        pygame.draw.line(screen, wood, pts[i], pts[i + 1], w_)
    for i in (3, 6, 9):                                                      # twigs
        bx, by = pts[i]
        pygame.draw.line(screen, wood, (bx, by), (bx + (0.5 * g) * (1 if side > 0 else -1), by - 0.6 * g), max(1, tw // 3))
        pygame.draw.line(screen, wood, (bx, by), (bx - (0.4 * g) * (1 if side > 0 else -1), by + 0.5 * g), max(1, tw // 3))
    return int(tip_y)


AUTUMN = [(214, 110, 30), (190, 62, 32), (226, 168, 40), (172, 84, 30)]


def _poly(pts, col, x0, w, h, y_top, flip):
    """polygon from unit coordinates (u across 0..1, v down 0..1 of the box)"""
    screen_pts = [(x0 + ((1.0 - u) if flip else u) * w, y_top + v * h) for u, v in pts]
    pygame.draw.polygon(screen, col, screen_pts)


def _tun_ring(zd):
    el, er, c = edges_zd(zd)
    y = proj_y(zd)
    return el - 0.03 * (er - el), er + 0.03 * (er - el), y, c, er - el


def _arch(l, r, y, w, grow=0.0, n=6):
    """cross-section of the tunnel: floor corners, straight wall, then a round roof. returns the points from the left foot over the top"""
    c = (l + r) / 2.0
    a_ = (r - l) / 2.0 + grow * w
    hw = 0.26 * w
    out = [(c - a_, y)]
    for i in range(n + 1):
        th = math.pi * (1.0 - i / float(n))
        out.append((c + a_ * -math.cos(math.pi * i / float(n)), y - hw - (0.55 * w + grow * w) * math.sin(th)))
    out.append((c + a_, y))
    return out


TUN_N = 12
_TUN_LOW, _TUN_TOP = (92, 112, 134), (30, 42, 72)


def _tun_seg_col(q, n):
    """colour of wall segment q: pale stone low down, dark blue at the crown of the roof"""
    if q == 0 or q == n + 1:
        f = 0.0
    else:
        th = math.pi * (1.0 - (q - 0.5) / float(n))
        f = math.sin(th) ** 0.7
    return _lerp_col(_TUN_LOW, _TUN_TOP, f)


_PORTAL = {}
TUN_VIS = 1500.0                  # the tunnel mouth is drawn from this far away: tiny at first, so it never pops in


def _portal_sprite():
    """the tunnel mouth as pixel art, 630 x 300: a big rocky hill (a stepped pile of brown boulders with a block on top, drawn on a 3x chunky grid)
    with a round arch of big stones round a dark opening. the road is 120 px wide here and the opening uses the same arch as the rings inside"""
    sp = _PORTAL.get("s")
    if sp is not None:
        return sp
    LW, LH, K = 420, 100, 3
    rr = random.Random(33)
    cxl = LW // 2
    peaks = ((cxl - 16, 78, 34), (cxl + 34, 62, 30), (cxl - 62, 50, 26), (cxl + 70, 44, 24), (cxl + 4, 56, 40), (cxl - 92, 40, 24), (cxl + 98, 46, 26),
             (cxl - 130, 44, 28), (cxl + 140, 38, 30), (cxl - 170, 28, 26), (cxl + 176, 30, 24), (cxl - 195, 16, 18), (cxl + 200, 14, 16))
    hts = []
    for x in range(LW):                                            # an uneven pile of crags: a tall one left of the middle, lower ones either side, ragged slopes
        h = max(6.0, 20.0 * (1.0 - abs(x - cxl) / float(cxl)))
        for px_, ph_, pw_ in peaks:
            d = abs(x - px_) / float(pw_)
            if d < 1.0:
                h = max(h, ph_ * (1.0 - d) ** 0.7)
        hts.append(h)
    out = []
    for i in range(0, LW, 5):                                      # blocky noise, a new step every 5 columns, so the outline is jagged
        nz = rr.randint(-4, 3)
        for x in range(i, min(LW, i + 5)):
            out.append(max(3, int(hts[x] + nz) // 2 * 2))
    hts = out
    low = pygame.Surface((LW, LH), pygame.SRCALPHA)
    mask = pygame.Surface((LW, LH), pygame.SRCALPHA)
    for x in range(LW):
        pygame.draw.line(mask, (255, 255, 255, 255), (x, LH - 1), (x, LH - hts[x]))
    pal = ((22, 16, 26), (42, 30, 38), (64, 46, 48), (92, 68, 60), (130, 98, 76))
    for x in range(LW):                                            # solid dark base first, so nothing ever shows through between the rocks
        pygame.draw.line(low, pal[1], (x, LH - 1), (x, LH - hts[x]))
    y = 0
    while y < LH + 8:                                              # rows of big angular blocks: lit top face, dark front face, light from the upper left
        x = -rr.randint(0, 12)
        while x < LW:
            bw, bh = rr.randint(12, 26), rr.randint(7, 13)
            th = rr.randint(3, 6)
            lit = 0.55 - 0.5 * (x / float(LW)) + 0.25 * (1.0 - y / float(LH))
            ci = 1 + (rr.random() < lit) + (rr.random() < lit * 0.45)
            ci = max(1, min(3, ci))
            yy = y + rr.randint(-2, 2)
            front = [(x, yy), (x + bw, yy), (x + bw - 2, yy + bh), (x + 2, yy + bh)]
            topf = [(x, yy), (x + bw, yy), (x + bw - rr.randint(3, 6), yy - th), (x + rr.randint(3, 6), yy - th)]
            pygame.draw.polygon(low, pal[ci], front)
            pygame.draw.polygon(low, pal[min(4, ci + 1)], topf)
            pygame.draw.line(low, pal[0], (x + 2, yy + bh), (x + bw - 2, yy + bh))         # dark joint below
            pygame.draw.line(low, pal[0], (x + bw, yy), (x + bw - 2, yy + bh))             # and on the right
            if rr.random() < 0.4:
                pygame.draw.line(low, pal[0], (x + bw // 2, yy + 1), (x + bw // 2 - rr.randint(0, 3), yy + bh - 1))   # a crack
            x += bw
        y += rr.randint(7, 10)
    low.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    for x in range(1, LW - 1):                                     # dark outline round the whole silhouette
        for y in range(LH - max(hts[x - 1], hts[x], hts[x + 1]) - 1, LH - hts[x] + 1):
            if 0 <= y < LH and mask.get_at((x, y))[3]:
                low.set_at((x, y), (18, 12, 20, 255))
    for _ in range(46):                                            # little pines on the ridges and slopes
        x = rr.randint(4, LW - 5)
        by = LH - hts[x] + rr.randint(2, 9)
        ph_ = rr.randint(6, 12)
        for j in range(ph_):
            wj = 1 + (j * 3) // ph_
            col = (22, 38, 32) if j % 2 else (34, 56, 40)
            pygame.draw.line(low, col, (x - wj, by - ph_ + j), (x + wj, by - ph_ + j))
        pygame.draw.line(low, (40, 28, 24), (x, by), (x, by + 1))
    big = pygame.transform.scale(low, (LW * K, LH * K))
    W_, H_ = LW * K, LH * K
    CX, FY = W_ // 2, H_ - 3
    sf = pygame.Surface((W_, H_), pygame.SRCALPHA)
    sf.blit(big, (0, 0))
    outer = _arch(CX - 63.5, CX + 63.5, FY, 120.0, 0.2, 12)
    mid = _arch(CX - 63.5, CX + 63.5, FY, 120.0, 0.0, 12)
    for k in range(1, len(outer) - 2):                             # big arch stones, each a little different
        v = rr.randint(-18, 18)
        col = (120 + v, 118 + v, 128 + v)
        quad = [outer[k], outer[k + 1], mid[k + 1], mid[k]]
        pygame.draw.polygon(sf, col, quad)
        pygame.draw.polygon(sf, (52, 50, 66), quad, 2)
        pygame.draw.line(sf, (170, 168, 180), outer[k], outer[k + 1], 1)
    pygame.draw.polygon(sf, (10, 12, 30), mid)
    for k in range(14):                                            # boulders and tufts of dry grass at the foot
        bx = rr.choice((rr.randint(20, 220), rr.randint(410, 610)))
        br = rr.randint(7, 15)
        pygame.draw.circle(sf, (40, 22, 32), (bx, FY - br + 8), br + 1)
        pygame.draw.circle(sf, (96, 64, 52), (bx, FY - br + 8), br)
        pygame.draw.circle(sf, (140, 98, 70), (bx - br // 3, FY - br + 5), max(2, br // 3))
    for xx in range(0, W_, 3):
        if abs(xx - CX) > 74 and rr.random() < 0.7:
            hh = rr.randint(3, 8)
            pygame.draw.line(sf, (120, 100, 48), (xx, FY + 2), (xx + rr.randint(-1, 1), FY + 2 - hh), 1)
    _PORTAL["s"] = sf
    return sf


_BOULDER = {}


def _boulder_sprite(v):
    """a heap of angular rocks, 44 x 30 art pixels (three variants)"""
    sp = _BOULDER.get(v)
    if sp is not None:
        return sp
    rr = random.Random(70 + v)
    W_, H_ = 44, 30
    low = pygame.Surface((W_, H_), pygame.SRCALPHA)
    mask = pygame.Surface((W_, H_), pygame.SRCALPHA)
    pts = [(0, H_ - 1), (rr.randint(3, 7), rr.randint(14, 20)), (rr.randint(12, 18), rr.randint(4, 9)), (rr.randint(22, 28), rr.randint(1, 5)),
           (rr.randint(32, 38), rr.randint(8, 14)), (W_ - 1, H_ - 1)]
    pygame.draw.polygon(mask, (255, 255, 255, 255), pts)
    pal = ((22, 16, 26), (42, 30, 38), (64, 46, 48), (92, 68, 60), (130, 98, 76))
    pygame.draw.rect(low, pal[1], (0, 0, W_, H_))
    y = 0
    while y < H_ + 4:
        x = -rr.randint(0, 8)
        while x < W_:
            bw, bh = rr.randint(8, 16), rr.randint(6, 10)
            ci = 1 + (rr.random() < 0.5 - 0.4 * x / W_) + (rr.random() < 0.2)
            ci = max(1, min(3, ci))
            pygame.draw.polygon(low, pal[ci], [(x, y), (x + bw, y), (x + bw - 1, y + bh), (x + 1, y + bh)])
            pygame.draw.polygon(low, pal[min(4, ci + 1)], [(x, y), (x + bw, y), (x + bw - 3, y - 3), (x + 3, y - 3)])
            pygame.draw.line(low, pal[0], (x + 1, y + bh), (x + bw - 1, y + bh))
            x += bw
        y += rr.randint(6, 8)
    low.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    for x in range(W_):
        for y in range(H_):
            if mask.get_at((x, y))[3] and (y == 0 or not mask.get_at((x, y - 1))[3] or x == 0 or not mask.get_at((x - 1, y))[3] or x == W_ - 1 or not mask.get_at((x + 1, y))[3]):
                low.set_at((x, y), (18, 12, 20, 255))
    _BOULDER[v] = low
    return low


def _boulder(z, u, k=1.0, v=0, lift=0.0):
    el, er, _c = edges_zd(z)
    t = Z1 / z
    x = (el + er) / 2.0 + u * (er - el)
    y = proj_y(z) - lift
    sh = int(1.3 * k * PXM * (t ** 0.9))
    if sh < 3 or x < -200 or x > W + 200:
        return
    spr = _boulder_sprite(v % 3)
    sw = max(2, int(spr.get_width() / float(spr.get_height()) * sh))
    screen.blit(pygame.transform.scale(spr, (sw, sh)), (int(x - sw // 2), int(y - sh * 0.92)))


_HAZE = {}


def _portal_hazed(f):
    """the hill fades into the distance haze while it is far away, so it settles into the scenery instead of standing out"""
    lv = 0 if f > 3.0 else 1 if f > 1.6 else 2 if f > 0.9 else 3
    sp = _HAZE.get(lv)
    if sp is None:
        k = (0.0, 0.18, 0.34, 0.5)[lv]
        sp = _portal_sprite().copy()
        if k > 0:
            sp.fill((int(255 * (1 - k)),) * 3, special_flags=pygame.BLEND_RGB_MULT)
            sp.fill((int(74 * k), int(46 * k), int(46 * k)), special_flags=pygame.BLEND_RGB_ADD)
        _HAZE[lv] = sp
    return sp


def _forest_pine(z, u, run_c_unused=None, k=1.0, var=0, lift=0.0):
    """one pine of the forest round the tunnel: depth z, lateral position u in road widths from the road centre"""
    el, er, _c = edges_zd(z)
    t = Z1 / z
    x = (el + er) / 2.0 + u * (er - el)
    y = proj_y(z) - lift
    sh = int(sprites.HEIGHT_M["pine"] * k * PXM * (t ** 0.9))
    if sh < 3 or x < -300 or x > W + 300:
        return
    spr = sprites.get("pine", var)
    sw = max(2, int(spr.get_width() / spr.get_height() * sh))
    screen.blit(pygame.transform.scale(spr, (sw, sh)), (int(x - sw // 2), int(y - sh)))


def draw_tunnel(run):
    """the tunnel: a grassy rock cutting that grows along the approach, the stone mouth in a mossy hill with a pine forest round it,
    and inside rings of blue stone wall with rows of lamps. drawn in depth order with the scenery"""
    a, b = TUNNEL
    if run.pos > b - 4.0 or a - run.pos > TUN_VIS:
        return
    zd_a = a - run.pos + Z1
    zd_b = b - run.pos + Z1
    outside = zd_a > Z1 * 0.6
    z0 = zd_a if outside else Z1 * 0.03
    far = min(zd_b, DRAW_DIST - 10.0)
    screen.set_clip(None)
    if outside:
        xl, xr, ya, c, w = _tun_ring(zd_a)
        hz_ = screen.get_at((min(W - 1, max(0, int(c))), max(0, view.hy - 3)))[:3]
        rr = random.Random(5)
        forest = [(zd_a + rr.uniform(2, 70), rr.choice((-1, 1)) * rr.uniform(1.6, 6.5), rr.uniform(0.9, 1.5), rr.randint(0, 1)) for _ in range(14)]
        forest.sort(key=lambda q: -q[0])
        for z_, u_, k_, v_ in forest:
            _forest_pine(z_, u_, None, k_, v_)
        f_ = w / 120.0
        spr0 = _portal_sprite()
        SW, SH = spr0.get_size()
        if f_ < 40.0:
            dx0, dy0 = c - SW * 0.5 * f_, ya - (SH - 3) * f_
            sx0, sx1 = max(0, int((0 - dx0) / f_)), min(SW, int((W - dx0) / f_) + 2)
            sy0, sy1 = max(0, int((0 - dy0) / f_)), min(SH, int((H - dy0) / f_) + 2)
            if sx1 > sx0 and sy1 > sy0:
                part = spr0.subsurface((sx0, sy0, sx1 - sx0, sy1 - sy0))
                ps_ = pygame.transform.scale(part, (max(1, int((sx1 - sx0) * f_)), max(1, int((sy1 - sy0) * f_))))
                kh = max(0.0, min(0.42, 0.55 - f_ / 4.0))                                  # far away it melts into the sky colour at the horizon
                if kh > 0.02:
                    ps_.fill((int(255 * (1 - kh)),) * 3, special_flags=pygame.BLEND_RGB_MULT)
                    ps_.fill(tuple(int(q * 0.7 * kh) for q in hz_), special_flags=pygame.BLEND_RGB_ADD)
                screen.blit(ps_, (int(dx0 + sx0 * f_), int(dy0 + sy0 * f_)))
        else:
            pygame.draw.polygon(screen, (10, 12, 30), _arch(xl, xr, ya, w, 0.0, TUN_N))
        if w >= 1.0:                                                                 # the cutting: grassy banks rising on both sides as the road runs into the hill
            zs_c = [zd_a]
            zc = zd_a - 20.0
            zmin = max(Z1 * 0.6, zd_a - 560.0)
            while zc > zmin:
                zs_c.append(zc)
                zc -= 20.0 if zd_a - zc < 200 else 40.0
            zs_c.append(zmin)
            br_ = random.Random(77)
            bl_ = [(zd_a + br_.uniform(-540, 50), br_.choice((-1, 1)) * br_.uniform(0.75, 3.6), br_.uniform(1.2, 2.8), br_.randint(0, 2)) for _ in range(54)]
            items_ = [(z_, 0, u_, k_, v_) for z_, u_, k_, v_ in bl_ if z_ > Z1 * 1.2]                  # boulders and rubble all round
            n_p = 0
            for z_ in range(int(zd_a - 20), int(max(Z1 * 1.2, zd_a - 540)), -45):                     # pines behind the banks
                for sd_ in (-1, 1):
                    n_p += 1
                    items_.append((float(z_), 1, sd_ * (0.78 + 0.5 * ((n_p * 37) % 7) / 7.0), 0.8 + 0.5 * ((n_p * 13) % 5) / 5.0, n_p % 2))
            items_.sort(key=lambda q: -q[0])
            ip_ = [0]

            def _flush(zlim):                                                                          # draw the scenery that stands behind everything nearer than zlim
                while ip_[0] < len(items_) and items_[ip_[0]][0] >= zlim:
                    z_, kd_, u_, k_, v_ = items_[ip_[0]]
                    ip_[0] += 1
                    if kd_ == 0:
                        _boulder(z_, u_, k_, v_)
                    else:
                        _forest_pine(z_, u_, None, k_, v_)
            _flush(zd_a + 1e-6)
            for j in range(len(zs_c) - 1):
                zf, zn = zs_c[j], zs_c[j + 1]
                if zn >= zf:
                    continue
                ramp = max(0.0, 1.0 - (zd_a - zf) / 560.0) ** 1.3
                rampn = max(0.0, 1.0 - (zd_a - zn) / 560.0) ** 1.3
                lf_, rf_, yf, cf, wf = _tun_ring(zf)
                ln_, rn_, yn, cn, wn = _tun_ring(zn)
                def _rk(zz):                                                                           # ragged height, fixed to the world so it does not crawl
                    q_ = int(round((a - (zd_a - zz)) / 20.0))
                    return 0.8 + 0.45 * (((q_ * 7919) % 13) / 13.0)
                hf, hn = 0.95 * wf * ramp * _rk(zf), 0.95 * wn * rampn * _rk(zn)
                gl_ = _lerp_col((26, 18, 18), (58, 42, 40), min(1.0, ramp * 1.6))                    # the ground on both sides turns to rubble round the tunnel
                gl2 = _lerp_col((26, 18, 18), (48, 34, 34), min(1.0, ramp * 1.6))
                gcol_ = gl_ if int(zf // 14) % 2 == 0 else gl2
                for sdg, e0f, e0n in ((-1, lf_ - 0.05 * wf, ln_ - 0.05 * wn), (1, rf_ + 0.05 * wf, rn_ + 0.05 * wn)):
                    xe = -4 if sdg < 0 else W + 4
                    pygame.draw.polygon(screen, gcol_, [(e0f, yf), (xe, yf), (xe, yn), (e0n, yn)])
                _flush(zn)                                                                             # trees and rocks stand behind this wall: the wall hides their feet
                band = int(zf // 20) % 2
                earth = ((66, 48, 50), (58, 42, 44))[band]
                for lf2, ln2, sd_ in ((lf_ - 0.05 * wf, ln_ - 0.05 * wn, -1), (rf_ + 0.05 * wf, rn_ + 0.05 * wn, 1)):
                    for f0, f1, col in ((0.0, 0.2, sprites._shade(earth, 0.7)), (0.2, 0.78, earth), (0.72, 1.0, (112, 84, 66))):
                        pygame.draw.polygon(screen, col, [(lf2, yf - hf * f0), (lf2, yf - hf * f1), (ln2, yn - hn * f1), (ln2, yn - hn * f0)])
                    pygame.draw.line(screen, (160, 122, 86), (lf2, yf - hf), (ln2, yn - hn), max(1, int(3 * Z1 / zf)))
                    if int(round((a - (zd_a - zf)) / 20.0)) % 2 == 0 and hf > 4:                    # cracks and joints in the rock face
                        pygame.draw.line(screen, (30, 22, 30), (lf2, yf - hf * 0.92), (lf2, yf - hf * 0.18), max(1, int(2 * Z1 / zf)))
            _flush(-1.0)
    if far <= z0 + 1.0:
        return
    zs = [z0]
    wp = (math.floor((run.pos + z0 - Z1) / 12.0) + 1) * 12.0
    while wp - run.pos + Z1 < far - 2.0:
        zs.append(wp - run.pos + Z1)
        wp += 12.0
    zs.append(far)
    if not outside:
        pygame.draw.rect(screen, (6, 8, 16), (0, 0, W, max(0, view.hy - 2)))            # no sky inside a tunnel
    for j in range(len(zs) - 1, 0, -1):                          # rings, far to near
        zf, zn = zs[j], zs[j - 1]
        lf, rf, yf, cf, wf = _tun_ring(zf)
        ln_, rn, yn, cn, wn = _tun_ring(zn)
        pf = _arch(lf, rf, yf, wf, 0.0, TUN_N)
        pn = _arch(ln_, rn, yn, wn, 0.0, TUN_N)
        band = int(round((run.pos + zf - Z1) / 12.0)) % 2
        k = min(1.0, (zf / DRAW_DIST) ** 0.8)
        sh_ = 1.0 if band else 0.9
        for q in range(len(pf) - 1):
            col = _lerp_col(sprites._shade(_tun_seg_col(q, TUN_N), sh_), (6, 8, 16), k * 0.92)
            pygame.draw.polygon(screen, col, [pf[q], pf[q + 1], pn[q + 1], pn[q]])
        r_ = max(1, int(wf * 0.018))
        if band == 0:                                                      # a row of lamps along each side of the roof
            for idx in (5, 9):
                lx_, ly_ = pf[idx]
                pygame.draw.circle(screen, _lerp_col((150, 100, 48), (6, 8, 16), k), (int(lx_), int(ly_)), r_ * 2)
                pygame.draw.circle(screen, _lerp_col((255, 220, 130), (6, 8, 16), k * 0.6), (int(lx_), int(ly_)), r_)
    lf, rf, yf, cf, wf = _tun_ring(zs[-1])
    if zd_b > DRAW_DIST - 10.0:                                  # the far end is too far to see: just darkness
        pygame.draw.polygon(screen, (6, 8, 16), _arch(lf, rf, yf, wf, 0.0, TUN_N))
    else:
        pygame.draw.polygon(screen, (232, 188, 120), _arch(lf, rf, yf, wf, 0.06, TUN_N))             # daylight at the far end, with a soft rim
        pygame.draw.polygon(screen, (255, 232, 176), _arch(lf, rf, yf, wf, 0.0, TUN_N))


def draw_shade(o, y, t, cx):
    """a pitch-black figure: not really there. it stands in the lamplight and is gone when you get close"""
    gap = o["s"] - view.pos
    if gap < 30.0:
        return
    sil = _SHADE.get("s")
    if sil is None:
        sil = _SHADE["s"] = pygame.mask.from_surface(sprites.get("ped", 0, shirt=(0, 0, 0), look=0)).to_surface(setcolor=(0, 0, 0, 255), unsetcolor=(0, 0, 0, 0))
    h = int(1.95 * PXM * t ** 0.62)
    if h < 4:
        return
    w = max(2, int(sil.get_width() * h / sil.get_height()))
    img = pygame.transform.scale(sil, (w, h))
    if gap < 55.0:
        img.set_alpha(int(255 * (gap - 30.0) / 25.0))
    screen.blit(img, (int(cx - w / 2), y - h))
    if h > 14 and gap < 140.0:                                     # two pale eyes
        ey = y - h + max(1, int(h * 0.13))
        e_ = max(1, h // 22)
        for dx in (-max(1, w // 7), max(1, w // 7)):
            pygame.draw.rect(screen, (214, 224, 232), (int(cx + dx - e_ // 2), ey, e_, max(1, e_)))


_SHADE = {}


def _draw_xcar(o, y, t, cx):
    """a car seen from the side (pixel sprite), driving along a cross street"""
    if not o["started"]:
        return
    kd = o["kind2"]
    spr = sprites.get("xcar", int(o["anim"] * 0.25) % 2, kind=kd, color=o["color"])
    te = t ** 0.7
    w = int(XCAR_L[kd] * PXM * te * 1.15)
    h = max(1, int(w * spr.get_height() / spr.get_width()))
    if w < 6 or cx < -w or cx > W + w:
        return
    img = pygame.transform.scale(spr, (w, h))
    if o["dir"] < 0:
        img = pygame.transform.flip(img, True, False)
    pygame.draw.ellipse(screen, (16, 10, 6), (int(cx - w * 0.52), y - max(2, h // 8), int(w * 1.04), max(3, h // 4)))
    screen.blit(img, (int(cx - w / 2), y - h + max(1, h // 10)))
    hx = int(cx + o["dir"] * w * 0.46)
    if t > 0.05:
        LIGHTS.append((hx, y - int(h * 0.5), max(8, int(w * 0.25)), (255, 226, 150)))


EMV_LOOK = {"amb": ("van", (240, 240, 236)), "pol": ("sedan", (28, 40, 90)), "stop": ("sedan", (96, 134, 84)), "wreck": ("sedan", (150, 62, 44))}


def _draw_emv(o, y, t, cx):
    """an ambulance or police car parked at the roadside with flashing lights, the stopped car, or a wreck"""
    kd, col = EMV_LOOK[o["v"]]
    spr = sprites.get("traffic", 0, kind=kd, color=col)
    w_m, h_m = CAR_SIZE_M[kd]
    te = t ** 0.7
    sw, sh = int(w_m * PXM * te * 1.15), int(h_m * PXM * te * 1.15)
    if sw < 4 or sh < 3:
        return
    img = pygame.transform.scale(spr, (sw, sh))
    if o["v"] == "wreck":
        img = pygame.transform.rotate(img, o["tilt"])
    pygame.draw.ellipse(screen, (16, 10, 6), (int(cx - sw * 0.55), y - max(2, sh // 8), int(sw * 1.1), max(3, sh // 5)))
    screen.blit(img, (int(cx - img.get_width() / 2), y - img.get_height()))
    if o["v"] in ("amb", "pol"):
        ph = (pygame.time.get_ticks() // 170) % 2
        bw = max(2, sw // 6)
        top = y - sh - max(1, sh // 12)
        cols = ((255, 40, 30), (60, 110, 255)) if o["v"] == "pol" else ((255, 40, 30), (255, 60, 40))
        for k, sx in enumerate((-1, 1)):
            on = (k + ph) % 2 == 0
            c = cols[k] if on else (60, 30, 30)
            pygame.draw.rect(screen, c, (int(cx + sx * sw * 0.22 - bw / 2), top, bw, max(2, bw // 2 + 1)))
            if on and sw > 6:
                LIGHTS.append((int(cx + sx * sw * 0.22), top, max(10, int(sw * 0.75)), c))
    if o["v"] == "wreck" and sw > 8 and (pygame.time.get_ticks() // 400) % 2 == 0:
        LIGHTS.append((int(cx), y - sh // 2, max(8, int(sw * 0.6)), (255, 170, 30)))


def _draw_faltree(o, y, t, el, er):
    """the same autumn tree sprite as the scenery: it creaks, tilts about its base and ends up lying across the road with its stump left standing"""
    span = (er - el) / 2.0
    rsd = o["rsd"]
    rx = el + (o["root"] + 1.0) / 2.0 * (er - el)
    f = o["fall"]
    Lw = o["ln"] * span
    sh = int(Lw)
    if sh < 6:
        return
    spr = sprites.get("maple", o["col"] % 4)
    sw = max(2, int(spr.get_width() / spr.get_height() * sh))
    img = pygame.transform.scale(spr, (sw, sh))
    g = max(1.0, PXM * t ** 0.8)
    pygame.draw.ellipse(screen, (18, 12, 8), (int(rx - sw * 0.35), y - max(2, sh // 24), int(sw * 0.7), max(3, sh // 12)))
    if f <= 0.0:
        deg = rsd * 2.2 * math.sin(o["anim"] * 1.3) * min(1.0, o["anim"] / 12.0) if o["started"] else 0.0      # the shaking is the warning
    else:
        deg = rsd * min(1.0, f) * 90.0
        deg *= 1.0 - 0.04 * math.sin(min(1.0, f) * math.pi * 3.0) * (1.0 if f >= 1.0 else 0.0)
    rot = pygame.transform.rotate(img, deg)
    a_ = math.radians(deg)
    ccx, ccy = rx - (sh / 2.0) * math.sin(a_), y - (sh / 2.0) * math.cos(a_)         # image centre, so that the base stays put
    screen.blit(rot, (int(ccx - rot.get_width() / 2), int(ccy - rot.get_height() / 2)))
    if f >= 1.0:
        sx = int(rx)
        stump_h = max(3, int(sh * 0.16))
        pygame.draw.rect(screen, (92, 38, 58), (sx - max(2, sw // 14), y - stump_h, max(4, sw // 7), stump_h))
        pygame.draw.rect(screen, (186, 120, 96), (sx - max(2, sw // 14), y - stump_h, max(4, sw // 7), max(1, stump_h // 4)))
        if o["hit"] is False:
            for i in range(9):                                  # leaves strewn on the tarmac around the crown
                lxp = rx - rsd * Lw * (0.45 + 0.07 * i) + math.sin(i * 7.0) * g * 0.5
                pygame.draw.rect(screen, AUTUMN[(i + o["col"]) % 4], (int(lxp), int(y - 0.1 * g + math.cos(i * 3.0) * g * 0.25), max(2, int(g * 0.22)), max(1, int(g * 0.1))))
    if f >= 1.0 and o.get("dust", 0) < 26:
        o["dust"] = o.get("dust", 0) + 1                                         # dust puff where the crown lands
        d_ = o["dust"]
        tip_x = rx - rsd * Lw
        for i in range(5):
            r_ = int(g * (0.5 + 0.09 * d_) * (0.6 + 0.2 * i))
            pygame.draw.circle(screen, (150, 124, 92), (int(tip_x + (i - 2) * g * 0.45), int(y - g * (0.15 + 0.03 * d_))), max(2, r_ // 2), 1)


def draw_hazard(o, y, t, el, er):
    kind = o["kind"]
    if kind == "pad" and o["hw"] > 1.0:
        return
    if kind == "pad":                                                        # the glowing repair bay of a fear station
        y2 = int(proj_y(Z1 / t + 44.0))
        la = el + (o["lx"] - o["hw"] + 1.0) / 2.0 * (er - el)
        ra = el + (o["lx"] + o["hw"] + 1.0) / 2.0 * (er - el)
        lb = la + (ra - la) * 0.12
        rb = ra - (ra - la) * 0.12
        col = (40, 120, 60) if o["used"] else (70, 230, 110)
        pygame.draw.polygon(screen, col, [(la, y), (ra, y), (rb, y2), (lb, y2)])
        pygame.draw.polygon(screen, (200, 255, 210), [(la, y), (ra, y), (rb, y2), (lb, y2)], 2)
        if not o["used"] and t > 0.03:
            LIGHTS.append((int((la + ra) / 2), y - 4, max(12, int(90 * t)), (90, 255, 130)))
        return
    lx = o["lx"]
    if o["hit"] and o["hit_t"] > 70:
        return
    cx = el + (lx + 1.0) / 2.0 * (er - el)
    if kind == "shroom":
        if o["used"]:
            return
        sh_ = int(0.7 * PXM * t ** 0.8)
        if sh_ < 3:
            return
        sw_ = max(3, int(sh_ * 0.9))
        cx_, y_ = int(cx), int(y)
        pygame.draw.rect(screen, (230, 220, 200), (cx_ - max(1, sw_ // 6), y_ - sh_ // 2, max(2, sw_ // 3), sh_ // 2))
        pygame.draw.ellipse(screen, (60, 20, 40), (cx_ - sw_ // 2 - 1, y_ - sh_ - 1, sw_ + 2, int(sh_ * 0.65) + 2))
        pygame.draw.ellipse(screen, (170, 60, 200), (cx_ - sw_ // 2, y_ - sh_, sw_, int(sh_ * 0.65)))
        for dx_, dy_ in ((-0.22, 0.2), (0.12, 0.12), (0.26, 0.3), (-0.05, 0.38)):
            pygame.draw.circle(screen, (120, 250, 230), (cx_ + int(dx_ * sw_), y_ - sh_ + int(dy_ * sh_)), max(1, sh_ // 12))
        return
    if kind == "wetleaf":                                                    # wet leaves: a dark, glossy patch that runs on into the next one
        zd0 = Z1 / t
        y2 = int(proj_y(zd0 + 10.5))
        el2, er2, _c2 = edges_zd(zd0 + 10.5)
        la, ra = el + (o["lx"] - o["hw"] + 1.0) / 2.0 * (er - el), el + (o["lx"] + o["hw"] + 1.0) / 2.0 * (er - el)
        lb, rb = el2 + (o["lx"] - o["hw"] + 1.0) / 2.0 * (er2 - el2), el2 + (o["lx"] + o["hw"] + 1.0) / 2.0 * (er2 - el2)
        la, ra = max(la, el), min(ra, er)
        lb, rb = max(lb, el2), min(rb, er2)
        if ra - la < 3 or y - y2 < 1:
            return
        pygame.draw.polygon(screen, (52, 32, 22), [(la, y), (ra, y), (rb, y2), (lb, y2)])
        for i in range(12):                                                  # leaves, wet and flat
            a_ = (o["ph"] * 7 + i * 37) % 97 / 97.0
            b_ = (o["ph"] * 3 + i * 53) % 89 / 89.0
            yy = y - (y - y2) * b_
            xl = la + (lb - la) * b_
            xr = ra + (rb - ra) * b_
            pygame.draw.rect(screen, AUTUMN[(i + o["ph"]) % 4], (int(xl + (xr - xl) * a_), int(yy), max(2, int((xr - xl) * 0.04)), max(1, int((y - y2) * 0.2))))
        if y - y2 > 3:
            ym = (y + y2) // 2
            pygame.draw.line(screen, (112, 88, 78), (int(la + (ra - la) * 0.3), ym), (int(la + (ra - la) * 0.55), ym), 1)       # a wet sheen
        return
    if kind == "rock":
        if not o["started"] or (o["hit"] and o["hit_t"] > 70):
            return
        f_ = o["fall"]
        g_ = PXM * t ** 0.62
        r_ = max(2, int(0.8 * g_))
        lift = int((1.0 - f_ * f_) * 6.5 * g_) if f_ < 1.0 else 0
        sh_w = int(r_ * (0.5 + 0.9 * f_))
        pygame.draw.ellipse(screen, (16, 10, 8), (int(cx - sh_w), y - max(1, r_ // 6), sh_w * 2, max(2, r_ // 3)))
        if o["anim"] > o["delay"]:
            draw_rock(int(cx), y - lift, r_ / 34.0, {"k": 1.0})
            if f_ >= 1.0 and o.get("landed") and o["hit_t"] == 0 and o["anim"] < o["delay"] + 60:
                k_ = (o["anim"] - o["delay"]) / 60.0
                for i in range(5):                                           # dust kicked up by the landing
                    pygame.draw.circle(screen, (150, 124, 100), (int(cx + (i - 2) * r_ * 0.5 * (1 + k_)), int(y - r_ * 0.3 - k_ * r_ * 0.8)), max(1, int(r_ * 0.25 * (1.0 - k_))))
        return
    if kind == "xcar":
        _draw_xcar(o, y, t, cx)
        return
    if kind == "faltree":
        _draw_faltree(o, y, t, el, er)
        return
    if kind == "emv":
        _draw_emv(o, y, t, cx)
        return
    if kind == "shade":
        draw_shade(o, y, t, cx)
        return
    if kind == "pshot":
        ph = o["phase"]
        if ph in ("idle", "gone"):
            return
        if ph == "splat":                                                    # smashed pumpkin on the tarmac: pulp and seeds
            wpx = int(o["hw"] * (er - el) * (0.85 + 0.12 * (o.get("v", 0) % 3)))
            hpx = max(2, int(wpx * 0.30))
            if wpx < 4:
                return
            gt = _guts_tex(o.get("v", 0) + int(o["anim"]), 150, 56)
            screen.blit(pygame.transform.scale(gt, (wpx, hpx)), (int(cx - wpx / 2), y - hpx // 2))
            return
        u_ = o["u"]
        g_ = PXM * t ** 0.62
        arc = 4.0 * u_ * (1.0 - u_) * 3.2 + 0.4 * (1.0 - u_)
        sz = max(3, int(0.75 * g_ * (0.6 + 0.8 * u_)))
        ps = sprites.get("pumpkin", 0)
        im = pygame.transform.rotozoom(pygame.transform.scale(ps, (sz, max(2, int(sz * ps.get_height() / ps.get_width())))), u_ * 900.0, 1.0)
        screen.blit(im, (int(cx - im.get_width() / 2), int(y - arc * g_ - im.get_height() / 2)))
        LIGHTS.append((int(cx), int(y - arc * g_), max(8, sz * 2), (255, 150, 30)))
        return
    if kind == "thrower":                                                    # the master: a tall man in black coat, lobbing pumpkins at the road
        armed = o.get("armed", 0) > 0
        try:
            ms = master_sprite.get(5 if armed else 0)
        except Exception:
            ms = sprites.get("ped", 0, shirt=(30, 30, 30), look=1)
        g_ = PXM * t ** 0.62
        sh_ = max(3, int(2.3 * g_))
        sw_ = max(2, int(ms.get_width() * sh_ / ms.get_height()))
        if sh_ < 4:
            return
        img_ = pygame.transform.scale(ms, (sw_, sh_))
        if o["face"] < 0:
            img_ = pygame.transform.flip(img_, True, False)
        pygame.draw.ellipse(screen, (10, 8, 14), (int(cx - sw_ * 0.6), y - max(2, sh_ // 14), int(sw_ * 1.2), max(3, sh_ // 7)))
        screen.blit(img_, (int(cx - sw_ / 2), y - sh_))
        if o["throws"] < len(o["shots"]) and not armed:                      # a pumpkin ready in his hand
            pr = max(2, int(sh_ * 0.12))
            hx = int(cx + (-o["face"]) * sw_ * 0.42)
            hy_ = y - int(sh_ * 0.42)
            pygame.draw.circle(screen, (236, 112, 16), (hx, hy_), pr)
            pygame.draw.circle(screen, (255, 190, 60), (hx - pr // 3, hy_ - pr // 3), max(1, pr // 3))
        if sh_ > 10:
            LIGHTS.append((int(cx), y - sh_ // 2, max(6, int(sh_ * 0.25)), (255, 120, 30)))
        return
    if kind == "web":
        if o["used"]:
            return
        wpx = (o["hw"] * (er - el)) * 1.0
        hh = int(2.6 * PXM * t ** 0.62)
        if wpx < 4 or hh < 4:
            return
        ccx, ccy = int(cx), int(y - hh * 0.55)
        col = (214, 220, 234)
        for i in range(10):
            a = i * math.pi / 5
            pygame.draw.line(screen, col, (ccx, ccy), (ccx + math.cos(a) * wpx, ccy + math.sin(a) * hh * 0.55), 1)
        for rr_ in (0.3, 0.55, 0.8, 1.0):
            pts = [(ccx + math.cos(i * math.pi / 5) * wpx * rr_, ccy + math.sin(i * math.pi / 5) * hh * 0.55 * rr_) for i in range(10)]
            pygame.draw.polygon(screen, col, pts, 1)
        if t > 0.04:
            LIGHTS.append((ccx, ccy, max(10, int(wpx * 0.9)), (150, 160, 190)))
        return
    if kind == "spider":
        if o["hit"]:
            return
        sp = sprites.get("spider", (o["anim"] // 8) % 2)
        g = PXM * t ** 0.62
        sh_ = max(3, int(1.1 * g))
        sw_ = max(3, int(sh_ * sp.get_width() / sp.get_height()))
        al = o.get("alt", 1.0)
        limb_y = draw_limb(y, g, el, er, lx, 1 if lx >= 0 else -1)
        top_ = limb_y + int(0.25 * g) + int((1.0 - al) * 2.6 * g)
        pygame.draw.line(screen, (200, 204, 216), (int(cx), limb_y), (int(cx), top_ + 2), 1)
        screen.blit(pygame.transform.scale(sp, (sw_, sh_)), (int(cx - sw_ / 2), top_))
        if sh_ > 3:
            LIGHTS.append((int(cx), top_ + sh_ // 2, max(6, int(sh_ * 1.2)), (255, 60, 50)))
        return
    if kind == "sleeper" and o.get("awake"):
        kind = "ped"
    if kind in ("deer", "cat", "boar", "piglet"):
        fr = 2
        if o["moving"]:
            fr = (o["anim"] // (5 if kind in ("deer", "boar") else (4 if kind == "piglet" else 3))) % 2
        spr = sprites.get(kind, fr, flip=(o["face"] < 0))
    elif kind == "ghost":
        spr = sprites.get("ghost", (o["anim"] // 12) % 2)
    elif kind == "tomb":
        spr = sprites.get("gravestone", o.get("v", 0))
    elif kind == "ghoul":
        spr = sprites.get("zombie", (1 + (o["anim"] // 10) % 3) if o["moving"] else 0, flip=(o["face"] < 0))
    elif kind == "bat":
        spr = sprites.get("bat", (o["anim"] // 3) % 2)
    elif kind == "witch":
        if o["alt"] >= 1.0 and not o["started"]:
            return
        spr = sprites.get("witchland", (o["anim"] // 10) % 2 if o["alt"] <= 0 else 0)
    elif kind == "zombie":
        fr = (1 + (o["anim"] // 10) % 3) if o["moving"] else 0
        spr = sprites.get("zombie", fr)
    elif kind in ("coffin", "pumpkin"):
        spr = sprites.get(kind, 0)
    elif kind in ("worker", "smoker", "sleeper", "cone", "barrier", "druid"):
        fr = (o["anim"] // 24) % 2 if kind == "druid" else 0
        if kind == "worker":
            if o["moving"]:
                fr = 1 + (o["anim"] // 7) % 3
            elif o.get("dig"):
                fr = 4 + (o["anim"] // 16) % 2
            else:
                fr = 0
        spr = sprites.get(kind, fr)
    else:   # ped / kid
        fr = 0
        if o["moving"]:
            fr = 1 + (o["anim"] // 8) % 3
        spr = sprites.get(o.get("who") or kind, fr, shirt=o.get("shirt", (160, 40, 40)), look=o.get("look", 0))
    h_m = sprites.HEIGHT_M.get(kind, 1.5) * (2.0 if kind == "bat" else 1.35 if kind == "druid" else 1.0)     # bats are drawn big so you can see them coming
    w_m = WIDTH_M.get(kind)
    te = t ** (0.5 if kind in ("deer", "cat", "boar", "piglet") else 0.62)                      # hazards are drawn bigger than true perspective so you can read them early
    sh = h_m * PXM * te
    if w_m:
        sw = w_m * PXM * te
    else:
        sw = spr.get_width() / spr.get_height() * sh
    if sh < 3 or sw < 2:
        return
    sw, sh = max(1, int(sw)), max(1, int(sh))
    img = pygame.transform.scale(spr, (sw, sh))
    x = int(cx - sw / 2)
    top = y - sh
    if kind == "ghoul" and not o["hit"]:
        rise = o["rise"]
        if rise <= 0.02:
            pygame.draw.ellipse(screen, (52, 38, 30), (x, y - max(2, sh // 12), sw, max(3, sh // 6)))
            return
        vis = max(2, int(sh * rise))
        pygame.draw.ellipse(screen, (52, 38, 30), (x - sw // 6, y - max(2, sh // 12), sw + sw // 3, max(3, sh // 6)))
        screen.blit(img, (x, y - vis), (0, 0, sw, vis))
        return
    if kind == "witch" and not o["hit"]:
        tt = pygame.time.get_ticks() / 1000.0
        lift = int(o["alt"] * sh * 3.2 + math.sin(tt * 6) * sh * 0.05 * (1 if o["alt"] > 0 else 0))
        if lift > 2:
            pygame.draw.ellipse(screen, (16, 10, 20), (x, y - max(2, sh // 14), sw, max(3, sh // 7)))
        screen.blit(img, (x, y - sh - lift))
        if sh > 2:
            LIGHTS.append((int(cx), y - sh // 2 - lift, max(16, int(sh * 2.2)), (150, 255, 110)))
        return
    if kind == "bat":                                                        # flutters above the road
        if o["hit"]:
            return
        tt = pygame.time.get_ticks() / 1000.0
        top = y - sh - int(sh * (1.3 + 0.9 * min(1.0, max(0.0, (o["s"] - CUR_POS[0]) / 160.0)))) + int(math.sin(tt * 9 + o["anim"]) * sh * 0.25)
        screen.blit(img, (x, top))
        if sh > 2:
            LIGHTS.append((int(cx), top + sh // 2, max(8, int(sh * 1.6)), (255, 70, 60)))       # glowing red eyes in the dark
        return
    if kind == "ghost":                                                      # floats, see-through, no shadow
        tt = pygame.time.get_ticks() / 1000.0
        img = img.copy()
        img.set_alpha(int(120 + 70 * math.sin(tt * 3.0 + o["anim"] * 0.7)))
        top = y - sh - int(sh * 0.12) - int(math.sin(tt * 2.2 + o["anim"]) * sh * 0.06)
        screen.blit(img, (x, top))
        if sh > 10:
            LIGHTS.append((int(cx), top + sh // 2, max(8, int(sh * 1.1)), (70, 84, 140)))
        return
    if o["hit"]:
        k = o["hit_t"]
        ang = min(90, k * 9) * (1 if o["vx_hit"] >= 0 else -1)
        lift = int(sh * 1.4 * (k / 20.0) * (1 - k / 40.0)) if k < 40 else 0
        if kind == "barrier":
            ang, lift = 0, 0
        img = pygame.transform.rotate(img, ang)
        if k > 40:
            img.set_alpha(max(0, 255 - (k - 40) * 8))
        x = int(cx - img.get_width() / 2)
        top = y - img.get_height() - max(0, lift)
        # soft ground shadow
    else:
        pygame.draw.ellipse(screen, (16, 10, 6), (x - sw // 8, y - max(2, sh // 14), sw + sw // 4, max(3, sh // 7)))
    screen.blit(img, (x, top))
    if kind == "druid" and not o["used"] and sh > 6:                       # the same green glow as the good witch: he is a healer
        LIGHTS.append((int(cx), y - sh // 2, max(16, int(sh * 2.2)), (150, 255, 110)))
    if kind == "barrier" and not o["hit"]:
        if ((o["bob"] + pygame.time.get_ticks() // 330) % 2) == 0:     # blinking amber lamps on the barrier
            for lxp in (0.12, 0.88):
                pygame.draw.circle(screen, (255, 190, 40), (x + int(sw * lxp), top - max(2, sh // 8)), max(2, sh // 8))
    if kind == "smoker" and not o["hit"]:
        phase = (o["anim"] // 3) % 40
        for i in range(3):               # smoke curling up from the cigarette
            ph = (phase + i * 13) % 40
            sx = x + int(sw * 0.9) + int(math.sin((ph + i) * 0.4) * sh * 0.05)
            sy = top + int(sh * 0.2) - int(ph * sh * 0.012)
            rad = max(1, int(sh * (0.018 + ph * 0.0012)))
            sm = pygame.Surface((rad * 2, rad * 2), pygame.SRCALPHA)
            pygame.draw.circle(sm, (190, 180, 170, max(0, 150 - ph * 4)), (rad, rad), rad)
            screen.blit(sm, (sx - rad, sy - rad))
    if kind == "sleeper" and not o["hit"]:
        z = (o["anim"] // 40) % 3
        text("Z" * (z + 1), font, (230, 220, 200), x + sw, top - 6)


# ---- billboards: tiny pixel posters, built once, scaled up crisp
_BOARDS = {}


def _txt(surf, text, size, col, cx, y, shadow=None):
    f = pygame.font.Font(None, size)
    while f.size(text)[0] > 118 and size > 8:            # shrink until it fits the poster
        size -= 1
        f = pygame.font.Font(None, size)
    im = f.render(text, False, col)
    if shadow:
        sh = f.render(text, False, shadow)
        surf.blit(sh, (cx - im.get_width() // 2 + 1, y + 1))
    surf.blit(im, (cx - im.get_width() // 2, y))


def make_board(ad, phone):
    key = (ad, phone)
    if key in _BOARDS:
        return _BOARDS[key]
    b = pygame.Surface((128, 64))
    if ad == "crowbar":
        b.fill((14, 12, 14))
        for i in range(-64, 128, 14):                                   # scratchy slashes
            pygame.draw.line(b, (34, 22, 24), (i, 64), (i + 40, 0), 3)
        _txt(b, "LISTEN TO", 20, (230, 226, 214), 64, 5)
        _txt(b, "CROWBAR", 44, (190, 24, 22), 64, 18, shadow=(240, 236, 226))
        pygame.draw.rect(b, (190, 24, 22), (6, 46, 116, 2))
        _txt(b, "LOUDER THAN YOUR NEIGHBOURS", 14, (170, 166, 156), 64, 51)
    elif ad == "circus":
        for i in range(0, 128, 16):
            pygame.draw.rect(b, (150, 26, 40) if (i // 16) % 2 == 0 else (236, 214, 150), (i, 0, 16, 64))
        pygame.draw.polygon(b, (40, 14, 60), [(0, 0), (128, 0), (128, 14), (64, 24), (0, 14)])
        pygame.draw.rect(b, (40, 14, 60), (14, 28, 100, 33))
        _txt(b, "THE FREAK", 24, (250, 214, 60), 64, 4)
        _txt(b, "CIRCUS", 36, (250, 214, 60), 64, 30, shadow=(150, 26, 40))
        _txt(b, "ONE NIGHT ONLY  NO REFUNDS", 12, (236, 214, 150), 64, 52)
    elif ad == "assholism":
        b.fill((22, 70, 56))
        pygame.draw.rect(b, (240, 236, 220), (3, 3, 122, 58), 1)
        _txt(b, "4 IN 5 MEN SUFFER FROM", 15, (240, 236, 220), 64, 6)
        _txt(b, "ASSHOLISM", 34, (250, 214, 60), 64, 15)
        _txt(b, "CALL " + phone, 22, (240, 236, 220), 64, 38)
        _txt(b, "TREATMENT IS AVAILABLE", 12, (170, 210, 190), 64, 53)
    elif ad == "funeral":
        b.fill((20, 14, 30))
        pygame.draw.rect(b, (200, 190, 120), (3, 3, 122, 58), 1)
        _txt(b, "BOOK YOUR FUNERAL", 17, (226, 214, 150), 64, 5)
        _txt(b, "WHILE YOU", 22, (240, 236, 220), 64, 20)
        _txt(b, "STILL LIVE", 30, (200, 60, 60), 64, 33)
        _txt(b, "CALL " + phone, 14, (170, 170, 190), 64, 52)
    elif ad == "salt":                                   # placeholder for the fourth ad
        b.fill((228, 224, 210))
        pygame.draw.rect(b, (40, 40, 56), (0, 0, 128, 12))
        _txt(b, "HAUNTED? CALL", 14, (240, 236, 220), 64, 1)
        _txt(b, "GHOSTBUSTED", 28, (40, 40, 56), 64, 14)
        _txt(b, "WE BRING OUR OWN SALT", 12, (170, 40, 40), 64, 36)
        _txt(b, phone, 22, (40, 40, 56), 64, 45)
    elif ad == "gravedeal":
        b.fill((18, 12, 28))
        pygame.draw.rect(b, (120, 200, 120), (3, 3, 122, 58), 1)
        _txt(b, THEME.get("town", "GRIMHOLT") + " MEMORIAL PARK", 14, (170, 220, 170), 64, 6)
        _txt(b, "ALL PLOTS", 34, (240, 236, 220), 64, 16)
        _txt(b, "30% OFF", 34, (120, 220, 120), 64, 34)
        _txt(b, "DIG DEEP. DIE LATER.", 12, (150, 150, 170), 64, 53)
    elif ad == "spice":
        b.fill((200, 100, 20))
        pygame.draw.rect(b, (60, 24, 8), (0, 0, 128, 12))
        _txt(b, "NEW THIS AUTUMN", 14, (250, 230, 190), 64, 2)
        _txt(b, "PUMPKIN SPICE", 28, (60, 24, 8), 64, 14)
        _txt(b, "FUNERALS", 34, (250, 240, 220), 64, 31, shadow=(120, 50, 10))
        _txt(b, "NOW WITH EXTRA SPICE", 12, (60, 24, 8), 64, 53)
    elif ad == "inn":
        b.fill((26, 22, 46))
        for x in range(8, 128, 24):
            pygame.draw.rect(b, (226, 180, 56), (x, 44, 8, 10))
        _txt(b, THEME.get("hill", "HAUNTED HILL") + " INN", 24, (240, 226, 190), 64, 6)
        _txt(b, "VACANCY.", 34, (200, 40, 40), 64, 20)
        _txt(b, "ALWAYS.", 22, (200, 40, 40), 64, 40)
    else:
        b.fill((30, 38, 92))
        pygame.draw.rect(b, (240, 90, 60), (0, 0, 128, 10))
        _txt(b, THEME.get("radio", "GRIMHOLT 90.1 FM"), 22, (250, 240, 200), 64, 14)
        _txt(b, "NOTHING BUT", 22, (250, 240, 200), 64, 31)
        _txt(b, "SCREAMING", 26, (240, 90, 60), 64, 44)
    _BOARDS[key] = b
    return b


CROW_QUIPS = ["SLOW DOWN. OR DON'T. I EAT EITHER WAY.", "NICE CAR. SHAME ABOUT THE DRIVER.", "BRAKES ARE FREE. FUNERALS AREN'T."]
_CROW = {}


def _wrap(txt, n):
    lines, cur = [], ""
    for w in txt.split():
        if len(cur) + len(w) + (1 if cur else 0) > n and cur:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w) if cur else w
    lines.append(cur)
    return lines


def _druid_portrait(scale=2):
    """a framed bust of the mushroom druid for the start line: dusk-green backdrop, hood and beard, the purple staff glowing"""
    n = 44
    s = pygame.Surface((n, n))
    for y in range(n):
        k = y / n
        pygame.draw.line(s, (40 + int(50 * k), 52 + int(20 * k), 34 - int(10 * k)), (0, y), (n, y))
    pygame.draw.circle(s, (210, 160, 70), (36, 8), 5)
    spr = sprites.get("druid", 0)
    crop = spr.subsurface((0, 0, spr.get_width(), min(36, spr.get_height()))).copy()
    s.blit(crop, (5, 9))
    big = pygame.transform.scale(s, (n * scale, n * scale))
    pygame.draw.rect(big, (60, 120, 58), big.get_rect(), 3)
    pygame.draw.rect(big, (14, 20, 12), big.get_rect().inflate(-6, -6), 1)
    return big


def draw_start_crow(run):
    """the crow talks from a little portrait box at the side while the car waits at the start; it slides away at GO"""
    q = getattr(run, "crow_q", None)
    druid = THEME.get("start_talker") == "druid"
    if not q or not (THEME.get("crow") or druid):
        return
    if run.state == "countdown":
        t_in = 190 - run.cd                                  # frames since the countdown began
        slide = min(1.0, t_in / 14.0)
    elif run.state == "race" and run.go > 0:
        t_in = 300
        slide = max(0.0, (run.go - 26) / 14.0) if run.go > 26 else 0.0
    else:
        return
    if slide <= 0.0:
        return
    if "f" not in _CROW:
        _CROW["f"] = pygame.font.Font(None, 24)
        _CROW["p"] = crow_sprite.portrait(2)
    if druid and "pd" not in _CROW:
        _CROW["pd"] = _druid_portrait(2)
    f, port = _CROW["f"], (_CROW["pd"] if druid else _CROW["p"])
    lines = _wrap(q, 20)
    tw = max(f.size(l)[0] for l in lines)
    lh = f.get_height()
    pw = port.get_width()
    bw, bh = tw + 22, max(port.get_height(), lh * len(lines) + 16)
    x = int(-(pw + bw + 20) * (1.0 - slide)) + 12
    y = 232
    screen.blit(port, (x, y))
    panel = pygame.Surface((bw, port.get_height()), pygame.SRCALPHA)
    pygame.draw.rect(panel, (14, 12, 20, 215), (0, 0, bw, port.get_height()), border_radius=4)
    pygame.draw.rect(panel, (60, 120, 58, 235) if druid else (122, 36, 44, 235), (0, 0, bw, port.get_height()), 2, border_radius=4)
    screen.blit(panel, (x + pw + 4, y))
    shown = max(0, (t_in - 14) // 2)                                    # typed out, a letter every other frame
    full = " ".join(lines)
    ty = y + (port.get_height() - lh * len(lines)) // 2
    done = 0
    for i, l in enumerate(lines):
        part = l[:max(0, shown - done)]
        done += len(l) + 1
        if part:
            screen.blit(f.render(part, True, (236, 226, 206)), (x + pw + 4 + 11, ty + i * lh))


def draw_billboard(ox, y, sc, o):
    w, h = int(250 * sc), int(125 * sc)
    if w < 6:
        return
    ph = int(70 * sc)
    x0 = ox if o["side"] > 0 else ox - w
    post = (58, 52, 46)
    pw = max(2, int(7 * sc))
    for px_ in (x0 + int(w * 0.18), x0 + int(w * 0.82)):
        pygame.draw.rect(screen, post, (px_ - pw // 2, y - ph, pw, ph))
    top = y - ph - h
    pygame.draw.rect(screen, (24, 22, 20), (x0 - max(1, int(4 * sc)), top - max(1, int(4 * sc)), w + 2 * max(1, int(4 * sc)),
                                           h + 2 * max(1, int(4 * sc))))
    screen.blit(pygame.transform.scale(make_board(o["ad"], o["phone"]), (w, h)), (x0, top))
    if sc > 0.05:                                                          # lamp glare for the night
        LIGHTS.append((x0 + w // 2, top - 4, max(10, int(100 * sc)), (255, 226, 170)))


def draw_gas(ox, y, sc, o):
    w = int(230 * sc)
    if w < 6:
        return
    x0 = ox if o["side"] > 0 else ox - w
    h = lambda v: int(v * sc)
    pygame.draw.rect(screen, (150, 142, 130), (x0 + h(100), y - h(52), h(130), h(52)))               # shop
    pygame.draw.rect(screen, (96, 90, 82), (x0 + h(100), y - h(56), h(130), max(2, h(6))))
    pygame.draw.rect(screen, (244, 206, 96), (x0 + h(112), y - h(40), h(50), h(24)))                 # lit window
    pygame.draw.rect(screen, (210, 36, 30), (x0, y - h(70), h(106), h(12)))                          # canopy
    pygame.draw.rect(screen, (240, 236, 224), (x0, y - h(62), h(106), max(2, h(5))))
    for px_ in (x0 + h(10), x0 + h(92)):
        pygame.draw.rect(screen, (190, 186, 178), (px_, y - h(58), max(2, h(5)), h(58)))
        pygame.draw.rect(screen, (214, 36, 30), (px_ - h(5), y - h(24), h(15), h(24)))              # pumps
    pole = x0 + h(210)
    pygame.draw.rect(screen, (60, 56, 52), (pole, y - h(140), max(2, h(6)), h(140)))
    pygame.draw.rect(screen, (240, 200, 40), (pole - h(22), y - h(168), h(50), h(30)))
    pygame.draw.rect(screen, (190, 30, 24), (pole - h(22), y - h(168), h(50), max(2, h(7))))
    if sc > 0.05:
        LIGHTS.append((pole + h(3), y - h(154), max(10, int(70 * sc)), (255, 214, 90)))
        LIGHTS.append((x0 + h(53), y - h(52), max(8, int(60 * sc)), (255, 236, 200)))


def draw_fence(ox, y, sc, o):
    h = int(80 * sc)
    if h < 3:
        return
    w = int(40 * sc)
    x0 = ox if o["side"] > 0 else ox - w
    iron = (96, 98, 126)
    pygame.draw.rect(screen, iron, (x0, y - int(h * 0.78), w, max(1, int(3 * sc))))
    pygame.draw.rect(screen, iron, (x0, y - int(h * 0.30), w, max(1, int(3 * sc))))
    for i in range(4):
        bx = x0 + int(w * i / 3.0)
        pygame.draw.rect(screen, iron, (bx, y - h, max(1, int(4 * sc)), h))
        pygame.draw.polygon(screen, iron, [(bx - int(3 * sc), y - h), (bx + int(1.5 * sc), y - h - int(9 * sc)), (bx + int(6 * sc), y - h)])


def draw_fear(ox, y, sc, o):
    """SCREAMOCO: a franchise filling station that has seen things. Corpse in the roof, a severed leg swinging from the canopy"""
    sc *= 1.5
    w = int(250 * sc)
    if w < 6:
        return
    tt = pygame.time.get_ticks() / 1000.0
    x0 = ox if o["side"] > 0 else ox - w
    h = lambda v: int(v * sc)
    wall, roof, dk = (66, 58, 80), (38, 32, 50), (24, 20, 32)
    pygame.draw.rect(screen, wall, (x0 + h(110), y - h(56), h(140), h(56)))                        # shop
    pygame.draw.polygon(screen, roof, [(x0 + h(100), y - h(56)), (x0 + h(180), y - h(92)), (x0 + h(260), y - h(56))])
    pygame.draw.rect(screen, (120, 80, 50), (x0 + h(120), y - h(40), h(26), h(40)))                # a coffin for a door
    pygame.draw.rect(screen, (70, 46, 30), (x0 + h(120), y - h(40), h(26), max(1, h(4))))
    pygame.draw.rect(screen, (150, 255, 150), (x0 + h(160), y - h(44), h(50), h(24)))              # lit window
    pygame.draw.line(screen, dk, (x0 + h(185), y - h(44)), (x0 + h(185), y - h(20)), max(1, h(2)))
    for i in range(3):                                                                         # blood drips from the eaves
        pygame.draw.rect(screen, (150, 20, 24), (x0 + h(130 + i * 40), y - h(58), max(1, h(3)), h(8 + 6 * ((i + int(tt * 1.5)) % 3))))
    legx = x0 + h(190)                                                                         # a corpse stuck headfirst in the roof: only legs show
    for dx in (-5, 5):
        pygame.draw.rect(screen, (90, 110, 160), (legx + h(dx) - h(2), y - h(120), max(2, h(5)), h(32)))
        pygame.draw.rect(screen, (30, 22, 20), (legx + h(dx) - h(3), y - h(124), max(2, h(7)), h(7)))
    pygame.draw.rect(screen, (88, 24, 28), (legx - h(8), y - h(92), h(16), max(1, h(3))))
    pygame.draw.rect(screen, (92, 84, 110), (x0, y - h(70), h(120), h(12)))                        # canopy
    pygame.draw.rect(screen, (150, 255, 160), (x0, y - h(62), h(120), max(2, h(4))))
    for px_ in (x0 + h(8), x0 + h(108)):
        pygame.draw.rect(screen, (140, 140, 150), (px_, y - h(58), max(2, h(5)), h(58)))
    sw = math.sin(tt * 2.2) * 0.35                                                             # the severed leg swings in the wind
    rx, ry = x0 + h(60), y - h(58)
    ex, ey = rx + math.sin(sw) * h(34), ry + math.cos(sw) * h(34)
    pygame.draw.line(screen, (150, 130, 90), (rx, ry), (ex, ey), max(1, h(2)))
    kx, ky = ex + math.sin(sw) * h(16), ey + math.cos(sw) * h(16)
    pygame.draw.line(screen, (226, 190, 160), (ex, ey), (kx, ky), max(2, h(8)))
    pygame.draw.line(screen, (60, 50, 44), (kx, ky), (kx + h(7), ky + h(4)), max(2, h(7)))
    for px_ in (x0 + h(30), x0 + h(84)):                                                       # pumps with hands for handles and dripping ooze
        pygame.draw.rect(screen, (60, 190, 100), (px_, y - h(24), h(14), h(24)))
        pygame.draw.rect(screen, (230, 210, 190), (px_ + h(12), y - h(20), h(8), h(5)))
        pygame.draw.rect(screen, (90, 255, 130), (px_ + h(5), y - h(2), max(1, h(3)), max(1, h(2 + (int(tt * 3) % 3)))))
    pole = x0 + h(236)
    pygame.draw.rect(screen, (50, 46, 60), (pole, y - h(150), max(2, h(6)), h(150)))
    pygame.draw.rect(screen, (30, 70, 40), (pole - h(36), y - h(188), h(80), h(34)))               # sign with a skull on top
    pygame.draw.circle(screen, (232, 228, 214), (pole + h(3), y - h(200)), max(2, h(12)))
    pygame.draw.rect(screen, (232, 228, 214), (pole - h(3), y - h(194), h(12), h(8)))
    pygame.draw.circle(screen, (24, 20, 28), (pole - h(1), y - h(202)), max(1, h(3)))
    pygame.draw.circle(screen, (24, 20, 28), (pole + h(7), y - h(202)), max(1, h(3)))
    if sc > 0.16:
        text("SCREAMOCO", font_mid, (160, 255, 170), pole + h(3), y - h(178), "center")
    if sc > 0.04:
        flick = 1.0 if (int(tt * 7) % 11) else 0.35
        LIGHTS.append((pole + h(3), y - h(170), max(14, int(120 * sc * flick)), (110, 255, 140)))
        LIGHTS.append((x0 + h(60), y - h(40), max(10, int(90 * sc)), (130, 255, 160)))


def draw_bollard(ox, y, sc, o):
    h = int(40 * sc)
    w = max(2, int(10 * sc))
    if h < 3:
        return
    pygame.draw.rect(screen, (236, 236, 226), (ox - w // 2, y - h, w, h))
    pygame.draw.rect(screen, (226, 60, 50), (ox - w // 2, y - h + h // 4, w, max(1, h // 5)))
    pygame.draw.rect(screen, (226, 60, 50), (ox - w // 2, y - h + h * 3 // 5, w, max(1, h // 5)))


def draw_pitgate(y, t, part="entry"):
    """FEAR STATION: a monstrous drive-through gate over the whole road. Corpses stick out of the roof, severed legs swing from the beam"""
    el, er, _ = edges_zd(Z1 / t)
    xl = int(el - (er - el) * 0.10)
    xr = int(er + (er - el) * 0.10)
    if xr - xl < 6:
        return
    u = (xr - xl) / 100.0
    tt = pygame.time.get_ticks() / 1000.0
    dh = int(170 * t)
    pw = max(3, int(7 * u))
    stone, dark, skin, shoe = (88, 84, 100), (48, 46, 60), (226, 190, 160), (30, 24, 28)
    green = (110, 255, 140)
    for x in (xl - pw, xr):
        pygame.draw.rect(screen, stone, (x, y - dh, pw, dh))
        pygame.draw.rect(screen, dark, (x + pw * 2 // 3, y - dh, pw // 3 + 1, dh))
        pygame.draw.rect(screen, (30, 28, 40), (x - pw // 4, y - dh - max(2, int(5 * u)), pw + pw // 2, max(3, int(5 * u))))
    beam = max(4, int(10 * u))
    top = y - dh
    pygame.draw.rect(screen, (30, 28, 40), (xl - pw, top - beam, xr - xl + 2 * pw, beam))
    pygame.draw.rect(screen, green, (xl - pw, top, xr - xl + 2 * pw, max(1, int(1.5 * u))))
    mid = (xl + xr) // 2
    if part == "exit":
        pygame.draw.rect(screen, (24, 54, 34), (mid - int(30 * u), top - beam - int(12 * u), int(60 * u), int(12 * u)))
        if u > 0.5:
            text("COME AGAIN. NEVER.", font_mid, (160, 255, 170), mid, top - beam - int(6 * u), "center")
        if t > 0.05:
            LIGHTS.append((mid, top + beam, max(16, int(150 * t)), green))
        return
    roof_h = int(30 * u)                                                                       # pitched roof of the "restaurant" on top
    pygame.draw.polygon(screen, (44, 36, 58), [(xl - pw, top - beam), (mid, top - beam - roof_h), (xr + pw, top - beam)])
    pygame.draw.polygon(screen, (70, 58, 90), [(xl - pw, top - beam), (mid, top - beam - roof_h), (xr + pw, top - beam)], max(1, int(1.5 * u)))
    for k_, fx in enumerate((0.18, 0.30, 0.55, 0.68, 0.82)):                                    # corpses stuck in the roof: only the legs show
        bx = xl + int((xr - xl) * fx)
        by = top - beam - int(roof_h * (1.0 - abs(fx - 0.5) * 2.0)) + int(3 * u)
        sw_ = math.sin(tt * 2.6 + k_ * 1.3) * (5 + 2 * k_ % 3) * u
        for dx in (-3, 3):
            p0 = (bx + dx * u, by)
            p1 = (bx + dx * u + sw_ * 0.3 + (k_ - 2) * 2 * u, by - int((16 + k_ % 2 * 6) * u))
            pygame.draw.line(screen, ((60, 70, 120), (130, 60, 60), (70, 110, 70))[k_ % 3], p0, p1, max(2, int(4 * u)))
            pygame.draw.line(screen, shoe, p1, (p1[0] + 5 * u, p1[1] - 2 * u), max(2, int(4 * u)))
    hx = xl + int((xr - xl) * 0.42)                                                            # an arm sticking out, waving
    pygame.draw.line(screen, skin, (hx, top - beam - int(roof_h * 0.6)), (hx + math.sin(tt * 4) * 8 * u, top - beam - int(roof_h * 0.6) - 18 * u), max(2, int(4 * u)))
    for sd_ in (-1, 1):                                                                         # neon arches (golden-arches parody) on both pillars
        ax = (xl - pw // 2) if sd_ < 0 else (xr + pw // 2)
        rect = (ax - int(18 * u), top - int(40 * u), int(36 * u), int(60 * u))
        if rect[2] > 4 and rect[3] > 4:
            pygame.draw.arc(screen, green, rect, 0.0, math.pi, max(2, int(5 * u)))
    pygame.draw.rect(screen, (24, 54, 34), (mid - int(38 * u), top - beam - roof_h - int(3 * u) - int(14 * u), int(76 * u), int(14 * u)))
    if u > 0.45:
        flick = (255, 255, 255) if (int(tt * 8) % 13) else (90, 140, 100)
        text("FEAR STATION", font_mid, flick if flick[0] > 200 else flick, mid, top - beam - roof_h - int(10 * u), "center")
    pygame.draw.circle(screen, (232, 228, 214), (mid, top - beam - roof_h - int(30 * u)), max(2, int(10 * u)))        # skull on top
    pygame.draw.rect(screen, (232, 228, 214), (mid - int(6 * u), top - beam - roof_h - int(24 * u), int(12 * u), int(8 * u)))
    pygame.draw.circle(screen, (20, 20, 24), (mid - int(4 * u), top - beam - roof_h - int(31 * u)), max(1, int(2.5 * u)))
    pygame.draw.circle(screen, (20, 20, 24), (mid + int(4 * u), top - beam - roof_h - int(31 * u)), max(1, int(2.5 * u)))
    # severed legs on ropes under the beam, swinging in the wind
    for k_, fx in enumerate((0.12, 0.36, 0.64, 0.88)):
        ang = math.sin(tt * 2.2 + k_ * 1.9) * 0.5
        rx, ry = xl + int((xr - xl) * fx), top + max(2, int(2 * u))
        ex, ey = rx + math.sin(ang) * 22 * u, ry + math.cos(ang) * 22 * u
        pygame.draw.line(screen, (200, 190, 150), (rx, ry), (ex, ey), max(1, int(1.5 * u)))
        kx, ky = ex + math.sin(ang) * 16 * u, ey + math.cos(ang) * 16 * u
        pygame.draw.line(screen, skin, (ex, ey), (kx, ky), max(2, int(5 * u)))
        pygame.draw.line(screen, shoe, (kx, ky), (kx + 4 * u, ky + 2 * u), max(2, int(5 * u)))
    for dx in (0.2, 0.5, 0.75, 0.95):                                                           # blood dripping
        ln = 6 + 5 * (0.5 + 0.5 * math.sin(tt * 1.5 + dx * 9))
        pygame.draw.rect(screen, (170, 20, 24), (xl + int((xr - xl) * dx), top, max(1, int(2 * u)), int(ln * u)))
    pw_ = int(40 * u)
    pygame.draw.rect(screen, (22, 20, 28), (xl + 2 * pw, top + int(12 * u), pw_, int(22 * u)))  # menu board
    if u > 0.8:
        text("NOW SERVING:", font_mid, (230, 230, 200), xl + 2 * pw + pw_ // 2, top + int(18 * u), "center")
        text("YOU", font_mid, (230, 60, 60), xl + 2 * pw + pw_ // 2, top + int(28 * u), "center")
    if t > 0.03:
        LIGHTS.append((mid, top + beam, max(20, int(170 * t)), green))
        LIGHTS.append((xl, top, max(12, int(90 * t)), (120, 255, 150)))
        LIGHTS.append((xr, top, max(12, int(90 * t)), (120, 255, 150)))


def draw_fbeam(y, t):
    el, er, _ = edges_zd(Z1 / t)
    xl, xr = int(el - (er - el) * 0.10), int(er + (er - el) * 0.10)
    dh = int(170 * t)
    bh = max(2, int(10 * t))
    pygame.draw.rect(screen, (30, 28, 40), (xl, y - dh - bh, xr - xl, bh))
    pygame.draw.rect(screen, (110, 255, 140), (xl, y - dh, xr - xl, max(1, int(2 * t))))
    if t > 0.04:
        LIGHTS.append(((xl + xr) // 2, y - dh + bh, max(14, int(110 * t)), (110, 255, 140)))


def draw_fpump(ox, y, sc, o):
    h = lambda v: int(v * sc)
    x0 = ox if o["side"] > 0 else ox - h(40)
    if h(50) < 3:
        return
    tt = pygame.time.get_ticks() / 1000.0
    pygame.draw.rect(screen, (60, 190, 100), (x0, y - h(56), h(26), h(56)))
    pygame.draw.rect(screen, (20, 60, 36), (x0 + h(3), y - h(50), h(20), h(14)))
    hand = (226, 190, 160)
    pygame.draw.rect(screen, hand, (x0 + h(24), y - h(38) + int(math.sin(tt * 3 + o.get("ph", 0)) * h(3)), h(10), h(6)))      # a hand for a nozzle
    pygame.draw.rect(screen, (90, 255, 130), (x0 + h(10), y - h(2), max(1, h(3)), max(1, h(2 + (int(tt * 3) + o.get("ph", 0)) % 3))))
    if sc > 0.05:
        LIGHTS.append((x0 + h(13), y - h(40), max(8, int(60 * sc)), (110, 255, 140)))


def draw_fsign(ox, y, sc, o):
    """sign that announces a fear station ahead"""
    sc *= 1.4
    w, h_ = int(120 * sc), int(70 * sc)
    if w < 8:
        return
    x0 = ox if o["side"] > 0 else ox - w
    pygame.draw.rect(screen, (50, 46, 60), (x0 + w // 2 - max(1, int(3 * sc)), y - int(80 * sc), max(2, int(6 * sc)), int(80 * sc)))
    top = y - int(80 * sc) - h_
    pygame.draw.rect(screen, (20, 54, 32), (x0, top, w, h_))
    pygame.draw.rect(screen, (140, 255, 160), (x0, top, w, h_), max(1, int(3 * sc)))
    if sc > 0.12:
        text("FEAR STATION", font_mid, (160, 255, 170), x0 + w // 2, top + int(h_ * 0.22), "center")
        text("DRIVE-THRU %dm" % o["dist"], font_mid, (230, 255, 230), x0 + w // 2, top + int(h_ * 0.58), "center")
    if sc > 0.03:
        LIGHTS.append((x0 + w // 2, top + h_ // 2, max(10, int(90 * sc)), (110, 255, 140)))


def draw_gate(y, t):
    """the cemetery gate over the road"""
    el, er, _ = edges_zd(Z1 / t)
    dh = int(640 * t)
    pw = max(3, int(64 * t))
    gap = int(20 * t)
    stone, dark = (88, 84, 100), (48, 46, 60)
    for x in (el - gap - pw, er + gap):
        pygame.draw.rect(screen, stone, (x, y - dh, pw, dh))
        pygame.draw.rect(screen, dark, (x + pw * 2 // 3, y - dh, pw // 3 + 1, dh))
        pygame.draw.rect(screen, stone, (x - pw // 4, y - dh - max(2, int(36 * t)), pw + pw // 2, max(3, int(36 * t))))
    bar = max(2, int(10 * t))
    ty = y - dh
    pygame.draw.rect(screen, (24, 22, 30), (el - gap, ty, er - el + 2 * gap, bar))
    for i in range(1, 9):                                           # iron spikes hanging down
        xx = el - gap + (er - el + 2 * gap) * i // 9
        pygame.draw.line(screen, (24, 22, 30), (xx, ty), (xx, ty + max(3, int(34 * t))), max(1, int(3 * t)))
    if t > 0.12:
        pygame.draw.rect(screen, (30, 28, 38), (el + (er - el) // 2 - int(120 * t), ty - int(46 * t), int(240 * t), int(40 * t)))
        text(THEME.get("town", "GRIMHOLT") + " CEMETERY", font_mid, (190, 200, 170), el + (er - el) // 2, ty - int(26 * t), "center")


def draw_overpass(y, t):
    el, er, _ = edges_zd(Z1 / t)
    dh = int(420 * t)
    th = max(3, int(70 * t))
    pw = max(3, int(44 * t))
    gap = int(26 * t)
    conc, dark, lite = (102, 96, 90), (52, 48, 46), (138, 130, 122)
    for x in (el - gap - pw, er + gap):
        pygame.draw.rect(screen, conc, (x, y - dh, pw, dh))
        pygame.draw.rect(screen, dark, (x + pw * 2 // 3, y - dh, pw // 3 + 1, dh))
    pygame.draw.rect(screen, conc, (0, y - dh - th, W, th))
    pygame.draw.rect(screen, lite, (0, y - dh - th, W, max(1, th // 6)))
    pygame.draw.rect(screen, dark, (0, y - dh - 1, W, max(2, int(14 * t))))
    pygame.draw.rect(screen, (74, 70, 66), (0, y - dh - th - max(2, int(16 * t)), W, max(2, int(16 * t))))   # parapet


DRAWERS = {"billboard": draw_billboard, "gas": draw_gas, "pine": draw_pine, "maple": draw_maple, "deadtree": draw_deadtree, "rock": draw_rock,
           "lamp": draw_lamp, "factory": draw_factory, "sign": draw_sign,
           "pumpkin": draw_pumpkin, "gravestone": draw_gravestone, "house": draw_house, "crypt": draw_crypt, "fence": draw_fence, "fear": draw_fear, "fsign": draw_fsign, "bollard": draw_bollard, "fpump": draw_fpump}


def draw_scenery(run):
    hy = view.hy
    lo = bisect.bisect_left(OBJ_S, run.pos - 10)
    hi = bisect.bisect_right(OBJ_S, run.pos + DRAW_DIST)
    td = TUNNEL is None
    for i in range(hi - 1, lo - 1, -1):
        o = OBJS[i]
        if not td and o["s"] <= TUNNEL[1]:
            draw_tunnel(run)
            td = True
        zd = (o["s"] - run.pos) + Z1
        if zd < Z1 * 0.55:
            continue
        t = Z1 / zd
        y = int(proj_y(zd))
        cy = clip_y(zd)
        if y - 400 > cy:                                          # far below the crest line: nothing of it can show
            continue
        screen.set_clip((0, 0, W, max(0, cy)))
        n_l = len(LIGHTS)
        _draw_obj(run, o, zd, t, y)
        screen.set_clip(None)
        if len(LIGHTS) > n_l:                                     # glows of things hidden behind a crest must not shine through it
            LIGHTS[n_l:] = [lt for lt in LIGHTS[n_l:] if lt[1] < cy + 2]
    if not td:
        draw_tunnel(run)


def _draw_obj(run, o, zd, t, y):
    if o["kind"] == "finish":
        draw_finish(y, t)
        return
    if o["kind"] == "checkpoint":
        draw_finish(y, t, ((250, 220, 60), (30, 24, 10)))
        return
    if o["kind"] == "overpass":
        draw_overpass(y, t)
        return
    if o["kind"] == "gate":
        draw_gate(y, t)
        return
    if o["kind"] == "pitgate":
        draw_pitgate(y, t, o.get("part", "entry"))
        return
    if o["kind"] == "fbeam":
        draw_fbeam(y, t)
        return
    if o["kind"] == "rail":
        draw_rail(o, y, t)
        return
    if id(o) in run.roadside_hit and o["kind"] in ("sign", "pumpkin"):
        return                                                    # knocked over / smashed
    el, er, _ = edges_zd(zd)
    if o.get("hz"):
        draw_hazard(o, y, t, el, er)
        return
    if "lx" in o:
        DRAWERS[o["kind"]](int(el + (o["lx"] + 1.0) / 2.0 * (er - el)), y, t * (1.0 if o["kind"] == "pine" else 1.7), o)
        return
    gap = o["off"] * t                                             # side objects stand outside the drawn road
    ox = int(er + gap) if o["side"] > 0 else int(el - gap)
    if ox < -350 or ox > W + 350:
        return
    if o["kind"] == "sign" and o.get("glyph"):
        DRAWERS["sign"](ox, y, t ** 0.68, o)
        return
    if o["kind"] in ("billboard", "gas"):                          # drawn bigger than true perspective so you can read them early
        DRAWERS[o["kind"]](ox, y, (t ** 0.6) * (2.4 if o["kind"] == "billboard" else 1.4), o)
        return
    big = 1.0 if o["kind"] in ("sign", "pine", "maple", "deadtree") else 1.7   # roadside things should feel big next to the car
    DRAWERS[o["kind"]](ox, y, t * big, o)



# ------------------------------------------------------------------ trees, rocks, lamps and signs are solid
SOLID_PX = {"maple": 24, "pine": 24, "deadtree": 30, "rock": 44, "lamp": 8, "sign": 10, "gravestone": 24, "pumpkin": 8}       # about 70% of the width the thing is drawn with, so the hit (and its sound) comes when you SEE the car touch it
SOLID_HIT = {"maple": (0.15, "TREE!", 30), "pine": (0.15, "TREE!", 30), "deadtree": (0.18, "TREE!", 26), "rock": (0.45, "ROCK!", 12),
             "lamp": (0.30, "LAMP POST!", 22), "sign": (0.72, "SIGN!", 8),
             "gravestone": (0.22, "GRAVESTONE!", 24), "pumpkin": (0.88, "SPLAT!", 2)}


def update_roadside(run, prev_pos):
    lead = 3.0
    lo = bisect.bisect_left(OBJ_S, prev_pos - 1.5)
    hi = bisect.bisect_right(OBJ_S, run.pos + lead)
    if lo >= hi:
        return
    yc = H - 30
    el, er, _ = edge_at(yc)
    tc = (yc - view.hy) / (H - view.hy)
    car_half = car_half_px(run)
    for i in range(lo, hi):
        o = OBJS[i]
        k = o["kind"]
        if k not in SOLID_PX or id(o) in run.roadside_hit:
            continue
        if "lx" in o:
            xo = el + (o["lx"] + 1.0) / 2.0 * (er - el)
        elif o.get("side", 0) > 0:
            xo = er + o["off"] * tc
        elif o.get("side", 0) < 0:
            xo = el - o["off"] * tc
        else:
            continue
        if abs(run.car_x - xo) < car_half + SOLID_PX[k] - 6:
            keep, msg, dmg = SOLID_HIT[k]
            run.roadside_hit.add(id(o))
            run.speed *= keep
            run.car_xv += (-7.0 if xo > run.car_x else 7.0)
            run.hits += 1
            run.crash = 50
            run.crash_msg = msg + time_pen(run, keep)
            add_damage(run, dmg)
            if AUDIO is not None:
                AUDIO.hit(k, 1.0 - keep)


# ------------------------------------------------------------------ level crossings
TRAIN_SPEED = 0.20         # lateral road-widths per frame
RAIL_LIGHTS_TTA = 360      # frames before arrival that the bell and lights start
RAIL_TRAIN_TTA = 100       # frames before arrival that the train comes out of the trees (it then blocks the road ~2 s)


def reset_rails():
    for r in RAILS:
        r.update(state="idle", head=0.0, t=0, cool=0, signals=False)


def rail_cover(r):
    """lateral interval (in road widths, -1..1 is the road) the train occupies right now"""
    if r["dir"] > 0:
        return r["head"] - r.get("len", TRAIN_LEN), r["head"]
    return r["head"], r["head"] + r.get("len", TRAIN_LEN)


def update_rails(run, prev_pos):
    near = None
    for r in RAILS:
        d = r["s"] - run.pos
        if d > 900 or d < -80:
            if r["state"] in ("done",):
                continue
            if d < -80 and r["state"] != "idle":
                r["state"], r["signals"] = "done", False
            continue
        tta = d / max(run.speed * M_PER_FRAME, 0.6)
        st = r["state"]
        if st == "idle" and 0 < tta < RAIL_LIGHTS_TTA:
            r["state"], r["signals"] = "lights", True
        elif st == "lights" and (tta < RAIL_TRAIN_TTA or r["t"] > 330):     # or after a long wait with the lights on
            r["state"] = "train"
            r["head"] = -r["dir"] * 3.4
            r["t"] = 0
        elif st == "lights":
            r["t"] += 1
        elif st == "train":
            r["head"] += r["dir"] * TRAIN_SPEED
            r["t"] += 1
            lo, hi = rail_cover(r)
            if (r["dir"] > 0 and lo > 1.8) or (r["dir"] < 0 and hi < -1.8):
                r["state"], r["t"] = "clear", 0
        elif st == "clear":
            r["t"] += 1
            if r["t"] > 40:
                r["state"], r["signals"] = "done", False
        if r["cool"] > 0:
            r["cool"] -= 1
        if r["state"] == "train" and r["cool"] == 0 and prev_pos - 1.0 <= r["s"] <= run.pos + 3.0:
            frac, car_hw = car_lateral(run)
            lo, hi = rail_cover(r)
            if lo - 0.05 < frac + car_hw and frac - car_hw < hi + 0.05:
                r["cool"] = 45
                run.speed *= 0.10
                run.pos = min(run.pos, r["s"] - 7.0)        # bounced back off the side of the train
                run.car_xv += 4.0 * (1 if frac < 0 else -1)
                run.hits += 1
                run.crash = 60
                run.crash_msg = "TRAIN!" + time_pen(run, 0.1)
                add_damage(run, DAMAGE["train"])
                if AUDIO is not None:
                    AUDIO.hit("train", 1.0)
        if near is None or abs(d) < abs(near[0]):
            near = (d, r)
    if AUDIO is not None:
        if near is not None and near[1]["state"] in ("lights", "train", "clear"):
            d, r = near
            try:
                AUDIO.rail(r["signals"], r["state"] == "train", 1.0 - min(1.0, abs(d) / 650.0), bool(THEME.get("ghost_train")))
            except TypeError:                                  # an old audio.py without the ghost overlay
                AUDIO.rail(r["signals"], r["state"] == "train", 1.0 - min(1.0, abs(d) / 650.0))
        else:
            AUDIO.rail(False, False, 0.0)


def draw_rail(o, y, t):
    el, er, _ = edges_zd(Z1 / t)
    bh = max(2, int(16 * t))
    pygame.draw.rect(screen, (92, 80, 66), (0, y - bh, W, bh))                         # ballast and sleepers
    for x in range(-int(14 * t), W, max(3, int(18 * t))):
        pygame.draw.rect(screen, (60, 44, 30), (x, y - bh, max(1, int(5 * t)), bh))
    rw = max(1, int(3 * t))
    for yy in (y - bh + max(1, bh // 5), y - max(1, bh // 5) - rw):
        pygame.draw.rect(screen, (168, 168, 176), (0, yy, W, rw))
    # signals: crossbuck + two red lamps on each side
    flash = (pygame.time.get_ticks() // 260) % 2
    ph = int(170 * t)
    gap = int(34 * t)
    for sd, px_ in ((-1, el - gap), (1, er + gap)):
        pw = max(2, int(7 * t))
        pygame.draw.rect(screen, (64, 60, 56), (px_ - pw // 2, y - ph, pw, ph))
        cw = int(60 * t)
        top = y - ph
        if cw >= 4:
            pygame.draw.line(screen, (236, 232, 222), (px_ - cw // 2, top - cw // 3), (px_ + cw // 2, top + cw // 3), max(2, int(8 * t)))
            pygame.draw.line(screen, (236, 232, 222), (px_ - cw // 2, top + cw // 3), (px_ + cw // 2, top - cw // 3), max(2, int(8 * t)))
        for k, lxp in enumerate((-1, 1)):
            on = o["signals"] and ((flash + k) % 2 == 0)
            cx_, cy_ = px_ + lxp * int(13 * t), top + int(34 * t)
            rr = max(2, int(8 * t))
            pygame.draw.circle(screen, (255, 54, 40) if on else (80, 20, 18), (cx_, cy_), rr)
            if on and t > 0.04:
                LIGHTS.append((cx_, cy_, max(8, int(46 * t)), (255, 50, 36)))
    # the train
    if o["state"] == "train":
        ghost = bool(THEME.get("ghost_train"))
        tgt = pygame.Surface((W, H), pygame.SRCALPHA) if ghost else screen
        lc = 2.3
        te = t ** 0.62
        h = max(4, int(3.7 * PXM * te))
        lo, hi = rail_cover(o)
        ew_ = max(1.0, er - el)
        lo_v, hi_v = max(lo, -el / ew_ * 2.0 - 1.0 - 2.5), min(hi, (W - el) / ew_ * 2.0 - 1.0 + 2.5)      # everything that can be on screen
        if hi_v <= lo_v:
            return
        n0 = int((o["head"] - hi_v) / lc) if o["dir"] > 0 else int((lo_v - o["head"]) / lc)
        n1 = int((o["head"] - lo_v) / lc) + 1 if o["dir"] > 0 else int((hi_v - o["head"]) / lc) + 1
        pal = [(142, 62, 38), (96, 98, 104), (120, 84, 52), (60, 82, 110), (150, 110, 40)]
        if ghost:                                                         # a burnt-out coach from 1890: charred planks, fire in the windows
            pal = [(40, 52, 54), (34, 44, 48), (44, 56, 54), (30, 40, 44), (42, 50, 48)]
        tnow = pygame.time.get_ticks() / 1000.0
        xs_all = []
        for j in range(max(0, n0), n1 + 1):
            if o["dir"] > 0:
                a, b = o["head"] - (j + 1) * lc + 0.1, o["head"] - j * lc
            else:
                a, b = o["head"] + j * lc, o["head"] + (j + 1) * lc - 0.1
            a, b = max(a, lo), min(b, hi)
            if b <= a:
                continue
            x0 = int(el + (a + 1.0) / 2.0 * (er - el))
            x1 = int(el + (b + 1.0) / 2.0 * (er - el))
            if x1 < 0 or x0 > W or x1 - x0 < 2:
                continue
            loco = (j == 0)
            col = ((38, 74, 52) if not ghost else (24, 26, 28)) if loco else pal[(j * 7) % len(pal)]
            dk = tuple(max(0, int(c * 0.6)) for c in col)
            yb = y - max(2, int(0.5 * PXM * te))
            xs_all.append((x0, x1))
            if ghost and loco:
                _draw_loco(tgt, x0, x1, yb, h, o["dir"], te, tnow, o["head"])
                continue
            if ghost and j == 1:
                _draw_tender(tgt, x0, x1, yb, h, o["dir"], te, tnow, o["head"])
                continue
            pygame.draw.rect(tgt, (22, 18, 16), (x0, yb - 2, x1 - x0, max(3, int(0.5 * PXM * te))))              # underframe
            pygame.draw.rect(tgt, col, (x0, yb - h, x1 - x0, h))
            pygame.draw.rect(tgt, dk, (x0, yb - h // 5, x1 - x0, h // 5))
            pygame.draw.rect(tgt, tuple(min(255, int(c * 1.3)) for c in col), (x0, yb - h, x1 - x0, max(1, h // 14)))
            if ghost:
                _burn_car(tgt, x0, x1, yb, h, j, loco, te, tnow, a <= lo + 1e-6, b >= hi - 1e-6)
            elif loco:
                pygame.draw.rect(tgt, (236, 190, 40), (x0, yb - h * 2 // 3, x1 - x0, max(2, h // 8)))
                pygame.draw.rect(tgt, (24, 28, 32), (x0 + (x1 - x0) // 8, yb - h * 7 // 8, (x1 - x0) * 3 // 8, h // 4))
                lamp = x1 if o["dir"] > 0 else x0
                LIGHTS.append((lamp, yb - h // 2, max(8, int(70 * te)), (255, 244, 200)))
            else:
                mid = (x0 + x1) // 2
                pygame.draw.rect(tgt, dk, (mid - max(1, (x1 - x0) // 16), yb - h * 9 // 10, max(2, (x1 - x0) // 8), h * 8 // 10))
            for wx in (x0 + (x1 - x0) // 6, x1 - (x1 - x0) // 6 - max(2, (x1 - x0) // 8)):
                pygame.draw.rect(tgt, (12, 10, 10), (wx, yb, max(2, (x1 - x0) // 8), max(2, int(0.5 * PXM * te))))
        sl = THEME.get("train_slogans")
        if ghost and sl and xs_all:                                      # a dumb ad painted on the side of the coaches, under the windows
            idx = RAILS.index(o) if o in RAILS else 0
            msg = sl[min(idx, len(sl) - 1)]
            cl = o["head"] - o["dir"] * o.get("len", TRAIN_LEN) / 2.0
            cxs = int(el + (cl + 1.0) / 2.0 * (er - el))
            fh = max(6, int(h * 0.19))
            ts_ = font_mid.render(msg, True, (222, 208, 168))
            ts_ = pygame.transform.scale(ts_, (max(2, int(ts_.get_width() * fh / float(ts_.get_height()))), fh))
            ts_.set_alpha(205)
            yb0 = y - max(2, int(0.5 * PXM * te))
            xmin, xmax = min(a_[0] for a_ in xs_all), max(a_[1] for a_ in xs_all)
            clip_old = tgt.get_clip()
            tgt.set_clip((max(0, xmin), 0, max(1, min(W, xmax) - max(0, xmin)), H))
            pitch = ts_.get_width() + int(h * 1.2)
            x_ = cxs - ts_.get_width() // 2
            while x_ > xmin - pitch:
                x_ -= pitch
            while x_ < xmax:
                tgt.blit(ts_, (x_, yb0 - int(h * 0.30)))
                x_ += pitch
            tgt.set_clip(clip_old)
        if ghost:
            screen.blit(tgt, (0, 0))


_GUTS = {}


def _guts_tex(v, w, h):
    """splattered pumpkin guts: orange stringy pulp with pale flat seeds (cached)"""
    key = (v % 6, w, h)
    if key in _GUTS:
        return _GUTS[key]
    rr = random.Random(v * 977 + w)
    t = pygame.Surface((w, h), pygame.SRCALPHA)
    cx, cy = w / 2.0, h / 2.0
    blobs = []
    for i in range(9):                                                   # lumpy pulp mass
        bx = cx + rr.uniform(-0.3, 0.3) * w
        by = cy + rr.uniform(-0.3, 0.3) * h
        bw, bh = rr.uniform(0.22, 0.42) * w, rr.uniform(0.25, 0.45) * h
        blobs.append((bx, by, bw, bh))
        col = rr.choice(((214, 108, 14), (226, 128, 20), (238, 150, 28), (200, 94, 12)))
        pygame.draw.ellipse(t, col, (bx - bw / 2, by - bh / 2, bw, bh))
    for (bx, by, bw, bh) in blobs:                                       # wet yellow highlights
        pygame.draw.ellipse(t, (250, 186, 52), (bx - bw * 0.25, by - bh * 0.3, bw * 0.4, bh * 0.3))
    for i in range(34):                                                  # stringy fibres inside the mass
        a = rr.uniform(0, 6.283)
        ln = rr.uniform(0.08, 0.2) * w
        x0_, y0_ = cx + math.cos(a) * w * rr.uniform(0.05, 0.3), cy + math.sin(a) * h * rr.uniform(0.05, 0.3)
        pts = [(x0_ + math.cos(a + k * 0.12) * ln * k / 5.0, y0_ + math.sin(a + k * 0.12) * ln * 0.7 * k / 5.0) for k in range(6)]
        pygame.draw.lines(t, rr.choice(((250, 182, 50), (196, 92, 12), (222, 124, 18))), False, [(px_ + rr.uniform(-2, 2), py_) for px_, py_ in pts], 1)
    for i in range(max(10, w // 7)):                                     # the flat pale seeds
        sx_ = cx + rr.uniform(-0.3, 0.3) * w
        sy_ = cy + rr.uniform(-0.3, 0.3) * h
        sl = max(5, int(w * rr.uniform(0.07, 0.1)))
        st = pygame.Surface((sl, max(3, int(sl * 0.6))), pygame.SRCALPHA)
        pygame.draw.ellipse(st, (206, 176, 124), st.get_rect())
        pygame.draw.ellipse(st, (246, 238, 214), st.get_rect().inflate(-2, -2))
        st = pygame.transform.rotate(st, rr.uniform(0, 180))
        t.blit(st, (sx_ - st.get_width() / 2, sy_ - st.get_height() / 2))
    _GUTS[key] = t
    return t


_DOOM_PAL = [(7, 7, 7), (31, 7, 7), (47, 15, 7), (71, 15, 7), (87, 23, 7), (103, 31, 7), (119, 31, 7), (143, 39, 7), (159, 47, 7),
             (175, 63, 7), (191, 71, 7), (199, 71, 7), (223, 79, 7), (223, 87, 7), (223, 87, 7), (215, 95, 7), (215, 95, 7), (215, 103, 15),
             (207, 111, 15), (207, 119, 15), (207, 127, 15), (207, 135, 23), (199, 135, 23), (199, 143, 23), (199, 151, 31), (191, 159, 31),
             (191, 159, 31), (191, 167, 39), (191, 167, 39), (191, 175, 47), (183, 175, 47), (183, 183, 47), (183, 183, 55), (207, 207, 111),
             (223, 223, 159), (239, 239, 199), (255, 255, 255)]
_FIRE_W, _FIRE_H = 64, 30
_fire = {"g": [0] * (_FIRE_W * _FIRE_H), "t": 0, "surf": None}


def _fire_tex():
    """the classic Doom fire, advanced at ~30 Hz and shared by every burning coach: one small RGBA texture, black = see-through"""
    now = pygame.time.get_ticks()
    if _fire["surf"] is not None and now - _fire["t"] < 33:
        return _fire["surf"]
    steps = 1 if _fire["surf"] is not None else 45          # first use: let it burn up first
    _fire["t"] = now
    g, w, h = _fire["g"], _FIRE_W, _FIRE_H
    rnd = random.random
    for _s in range(steps):
        for x in range(w):                                # the fuel line along the bottom
            g[(h - 1) * w + x] = 31
        for y in range(1, h):
            row = y * w
            up = row - w
            for x in range(w):
                v = g[row + x]
                if v == 0:
                    g[up + x] = 0
                else:
                    r = int(rnd() * 3.0)
                    g[up + (x - r + 1) % w] = max(0, v - (r & 1) - (1 if rnd() < 0.95 else 0))
    buf = bytearray(w * h * 4)
    i = 0
    for v in g:
        if v > 0:
            c = _DOOM_PAL[v]
            buf[i], buf[i + 1], buf[i + 2] = c
            buf[i + 3] = 255 if v > 6 else int(v * 42)
        i += 4
    sf = pygame.image.frombuffer(bytes(buf), (w, h), "RGBA").convert_alpha()
    wide = pygame.Surface((w * 2, h), pygame.SRCALPHA)                  # tiles sideways, so a train-long flame band has no seams
    wide.blit(sf, (0, 0))
    wide.blit(sf, (w, 0))
    _fire["surf"] = wide
    return wide


def _flame(tgt, tex, x, ybase, wpx, hpx, start, cols, skip=3):
    """blit `cols` columns of the (wrapping) fire texture from column `start`, scaled to wpx x hpx, bottom edge on ybase"""
    if wpx < 2 or hpx < 2:
        return
    start %= _FIRE_W
    part = tex.subsurface((start, 0, cols, _FIRE_H - skip))              # the always-white fuel rows at the very bottom stay out
    tgt.blit(pygame.transform.scale(part, (int(wpx), int(hpx))), (int(x), int(ybase - hpx)))


def _wheel(tgt, cx, cy, r, ang, col=(14, 14, 16)):
    r = max(2, int(r))
    pygame.draw.circle(tgt, col, (int(cx), int(cy)), r)
    if r >= 4:
        pygame.draw.circle(tgt, (58, 46, 40), (int(cx), int(cy)), r, max(1, r // 6))
        for k in range(6):
            a = ang + k * math.pi / 3.0
            pygame.draw.line(tgt, (44, 36, 34), (int(cx), int(cy)), (int(cx + math.cos(a) * r * 0.9), int(cy + math.sin(a) * r * 0.9)), 1)
        pygame.draw.circle(tgt, (70, 56, 48), (int(cx), int(cy)), max(1, r // 5))


def _draw_loco(tgt, x0, x1, yb, h, d, te, tt, head):
    """a burnt-out 1890s American 4-4-0: tall balloon funnel, domes, boiler, cab, cowcatcher, big drivers, rod; fire in the cab and firebox"""
    w = x1 - x0
    if w < 8:
        return
    tex = _fire_tex()

    def U(u):
        return x0 + (u if d > 0 else 1.0 - u) * w

    def R(u0, u1, v0, v1, col):
        xa, xb = U(u0), U(u1)
        pygame.draw.rect(tgt, col, (int(min(xa, xb)), int(yb - v1 * h), max(1, int(abs(xb - xa))), max(1, int((v1 - v0) * h))))

    def P(pts, col):
        pygame.draw.polygon(tgt, col, [(int(U(u)), int(yb - v * h)) for u, v in pts])

    black, soot, rust = (16, 17, 19), (30, 30, 33), (74, 44, 30)
    ang = head * 2.4 * (1 if d > 0 else -1)
    R(0.0, 0.97, 0.15, 0.24, (22, 18, 16))                                   # frame
    R(0.0, 0.34, 0.20, 1.0, soot)                                            # cab
    R(-0.01, 0.37, 0.96, 1.03, black)                                        # cab roof overhang
    R(0.08, 0.24, 0.56, 0.88, (110, 30, 6))                                  # cab window: burning inside
    wl = int(abs(U(0.24) - U(0.08)))
    if wl >= 4:
        clip_old = tgt.get_clip()
        tgt.set_clip(pygame.Rect(int(min(U(0.08), U(0.24))), int(yb - 0.88 * h), wl, int(0.32 * h)))
        _flame(tgt, tex, int(min(U(0.08), U(0.24))), int(yb - 0.56 * h), wl, 0.46 * h, int(head * 7) % 40, 8, 0)
        tgt.set_clip(clip_old)
    R(0.08, 0.24, 0.55, 0.57, black)
    R(0.30, 0.88, 0.36, 0.72, soot)                                          # boiler
    for u in (0.40, 0.52, 0.64, 0.76):
        R(u, u + 0.012, 0.36, 0.72, (44, 38, 36))                            # boiler bands
    R(0.30, 0.88, 0.69, 0.72, (46, 40, 38))
    P([(0.86, 0.36), (0.92, 0.38), (0.92, 0.70), (0.86, 0.72)], black)       # smokebox front
    R(0.47, 0.54, 0.72, 0.84, (42, 36, 34))                                  # steam dome
    R(0.40, 0.44, 0.72, 0.78, (38, 34, 32))                                  # sand dome
    P([(0.76, 0.72), (0.80, 0.72), (0.84, 1.02), (0.71, 1.02)], black)       # balloon funnel
    R(0.69, 0.86, 1.0, 1.06, black)
    R(0.70, 0.84, 0.30, 0.38, (24, 20, 18))                                  # cylinder
    pygame.draw.line(tgt, (66, 56, 50), (int(U(0.72)), int(yb - 0.34 * h)), (int(U(0.45) + math.cos(ang) * 0.05 * w), int(yb - 0.25 * h + math.sin(ang) * 0.05 * h)), max(1, int(h * 0.025)))
    P([(0.93, 0.0), (1.02, 0.0), (0.97, 0.16), (0.90, 0.16)], (40, 32, 28))  # cowcatcher
    for k in range(1, 4):
        pygame.draw.line(tgt, (18, 14, 12), (int(U(0.93 + 0.03 * k)), int(yb - 0.01 * h)), (int(U(0.90 + 0.02 * k)), int(yb - 0.16 * h)), 1)
    for u in (0.34, 0.56):                                                   # big driving wheels
        _wheel(tgt, U(u), yb - 0.20 * h, 0.27 * h, ang)
    for u in (0.78, 0.9):                                                    # small leading wheels
        _wheel(tgt, U(u), yb - 0.11 * h, 0.13 * h, ang)
    # the fire: firebox glow under the cab, flames out of the cab roof and funnel
    R(0.06, 0.28, 0.12, 0.19, (255, 110, 20))
    _flame(tgt, tex, int(min(U(0.02), U(0.34))), int(yb - 0.96 * h), int(abs(U(0.34) - U(0.02))), 0.5 * h, int(head * 5) % 40, 10)
    _flame(tgt, tex, int(min(U(0.71), U(0.83))), int(yb - 1.02 * h), int(abs(U(0.83) - U(0.71))), 0.9 * h, int(head * 5) % 40 + 12, 8)
    lamp = U(0.95)
    pygame.draw.circle(tgt, (255, 214, 120), (int(lamp), int(yb - 0.55 * h)), max(2, int(0.07 * h)))        # the headlamp still burns
    LIGHTS.append((int(lamp), int(yb - 0.55 * h), max(10, int(90 * te)), (255, 200, 120)))
    LIGHTS.append((int(U(0.16)), int(yb - 0.5 * h), max(10, int(90 * te)), (255, 110, 30)))
    for q in range(4):                                                       # thick black smoke from the funnel
        ph = (tt * 0.5 + q * 0.25) % 1.0
        px_ = int(U(0.77)) - (1 if d > 0 else -1) * int(ph * w * 0.7)
        py_ = int(yb - 1.1 * h - ph * 1.6 * h)
        pygame.draw.circle(tgt, (40, 38, 38, int(200 * (1.0 - ph))), (px_, py_), max(2, int((0.18 + ph * 0.5) * h)))
    for q in range(6):                                                       # sparks
        ph = (tt * 1.3 + q * 0.17) % 1.0
        sx_ = int(U(0.77)) + int(math.sin(q * 7.3 + tt * 3) * 0.12 * w) - (1 if d > 0 else -1) * int(ph * 0.25 * w)
        sy_ = int(yb - 1.1 * h - ph * 1.3 * h)
        tgt.fill((255, 190, 70), (sx_, sy_, max(1, int(h * 0.03)), max(1, int(h * 0.03))))


def _draw_tender(tgt, x0, x1, yb, h, d, te, tt, head):
    """the tender: a charred wooden fuel box, the load glowing and burning"""
    w = x1 - x0
    if w < 6:
        return
    tex = _fire_tex()
    pygame.draw.rect(tgt, (22, 18, 16), (x0, int(yb - 0.22 * h), w, max(2, int(0.07 * h))))
    pygame.draw.rect(tgt, (26, 28, 30), (x0 + int(w * 0.03), int(yb - 0.64 * h), int(w * 0.94), int(0.42 * h)))
    step = max(3, w // 16)
    for xx in range(x0 + step, x0 + w, step):
        pygame.draw.line(tgt, (14, 15, 17), (xx, int(yb - 0.64 * h)), (xx, int(yb - 0.22 * h)), 1)
    pygame.draw.rect(tgt, (60, 38, 28), (x0 + int(w * 0.03), int(yb - 0.64 * h), int(w * 0.94), max(1, int(0.03 * h))))
    _flame(tgt, tex, x0 + int(w * 0.06), int(yb - 0.6 * h), int(w * 0.88), 0.55 * h, int(head * 6) % 40, 20)
    ang = head * 2.4 * (1 if d > 0 else -1)
    for u in (0.2, 0.8):
        _wheel(tgt, x0 + w * u, yb - 0.12 * h, 0.14 * h, ang)
    LIGHTS.append(((x0 + x1) // 2, int(yb - 0.7 * h), max(10, int(90 * te)), (255, 110, 30)))


def _burn_car(tgt, x0, x1, yb, h, j, loco, te, tt, left_end=False, right_end=False):
    """a charred coach with Doom-style fire in the windows and through the roof, and smoke"""
    w = x1 - x0
    if w < 6:
        return
    tex = _fire_tex()
    dark = (16, 18, 20)
    step = max(3, w // 14)
    for xx in range(x0 + step, x1, step):                                # plank joints
        pygame.draw.line(tgt, dark, (xx, yb - h), (xx, yb - h // 5), 1)
    pygame.draw.rect(tgt, (28, 22, 18), (x0, yb - h - max(1, h // 14), w, max(2, h // 12)))       # charred roof edge
    wins = ((0.30, 0.56),) if loco else ((0.07, 0.17), (0.29, 0.17), (0.51, 0.17), (0.73, 0.17))
    for k, (fx, fw) in enumerate(wins):
        wx = x0 + int(w * fx)
        ww = max(2, int(w * fw))
        wt = yb - int(h * 0.78)
        wh = max(3, int(h * 0.34))
        pygame.draw.rect(tgt, dark, (wx - 1, wt - 1, ww + 2, wh + 2))
        pygame.draw.rect(tgt, (120, 30, 6), (wx, wt, ww, wh))
        _flame(tgt, tex, wx, wt + wh, ww, wh, j * 20 + int(w * fx / max(1.0, w) * 20), 6, 0)         # fire filling the window
        if k % 2 == 0 and ww > 3:
            LIGHTS.append((wx + ww // 2, wt + wh // 2, max(10, int(70 * te)), (255, 120, 30)))
    if loco:
        pygame.draw.rect(tgt, dark, (x0 + w // 8, yb - h - int(h * 0.35), max(3, w // 10), int(h * 0.38)))      # chimney
    bh_ = h * (0.95 + 0.1 * (j % 2))
    if left_end or right_end:                                             # the ends of the train burn lower: slice the band and shorten the outer slices
        for i in range(20):
            e = (19 - i) if right_end and not left_end else i
            if left_end and right_end:
                e = min(i, 19 - i)
            f = 0.12 + 0.88 * min(1.0, e / 7.0)
            xa, xb = x0 + w * i // 20, x0 + w * (i + 1) // 20
            _flame(tgt, tex, xa, yb - h + int(h * 0.08), max(1, xb - xa), bh_ * f, j * 20 + i, 1)
    else:
        _flame(tgt, tex, x0, yb - h + int(h * 0.08), w, bh_, j * 20, 20)          # one continuous band of flame along the roof
    for q in range(3):                                                    # smoke drifting up and away
        ph = (tt * 0.45 + q * 0.33 + j * 0.17) % 1.0
        px_ = x0 + int(w * (0.25 + 0.25 * q)) + int(ph * w * 0.4)
        py_ = yb - h - int((0.5 + ph * 2.6) * h)
        rr = max(2, int((0.35 + ph * 0.9) * h * 0.45))
        pygame.draw.circle(tgt, (54, 50, 50, int(120 * (1.0 - ph))), (px_, py_), rr)
    if w > 8:
        LIGHTS.append(((x0 + x1) // 2, yb - h, max(12, int(110 * te)), (255, 110, 30)))


# ------------------------------------------------------------------ traffic
CAR_COLORS = [(176, 36, 36), (46, 96, 168), (200, 190, 170), (60, 120, 70), (210, 160, 40), (110, 110, 118),
              (150, 60, 140), (230, 230, 226)]
CAR_SIZE_M = {"logtruck": (2.5, 3.0), "log": (2.4, 0.75), "sedan": (1.8, 1.4), "van": (2.0, 2.0), "truck": (2.5, 3.0), "bike": (0.95, 1.7), "cyclist": (0.8, 1.9), "hearse": (2.0, 2.1)}


def traffic_lx(c):
    """lane centre: left/right lane of the standard road, drifting out as the road widens to three lanes"""
    return c.get("lp", c["lane"]) * (0.5 + wide_k(c["s"]) / 6.0) + c.get("lxo", 0.0) + c.get("ox", 0.0)


LANE_CHANGE_FRAMES = 52


def lane_lx(lane, s):
    return lane * (0.5 + wide_k(s) / 6.0)


def car_half(c):
    """half the car's drawn width as a fraction of the road"""
    return CAR_SIZE_M[c["kind"]][0] * PXM * 1.15 / 2.0 / ((ROAD_R - ROAD_L) / 2.0)


def threatens(o, lx, half):
    """does this hazard sit in, or is it about to walk into, the strip a car of half-width `half` occupies around lx?"""
    if not o["solid"] or o["hit"] or o.get("fly"):
        return False
    near = half + o["hw"] + 0.05
    if abs(o["lx"] - lx) < near:
        return True
    if o["plan"] is not None:                          # its whole walk counts, not just where it stands now
        xs = [o["lx"]] + [w[0] for w in o["plan"][o["pi"]:o["pi"] + 2]]
        return min(xs) - near < lx < max(xs) + near
    return False


def static_blocker(s0, lx, lo, hi, half=0.3):
    """first fixed obstacle (cones, barrier, a standing person) in the way of something at lateral lx, lo..hi metres ahead"""
    i = bisect.bisect_left(HAZ_S, s0 + lo)
    for j in range(i, len(HAZ)):
        o = HAZ[j]
        if o["s"] > s0 + hi:
            break
        if o["solid"] and not o["hit"] and not o.get("fly") and o["plan"] is None and abs(o["lx"] - lx) < half + o["hw"] + 0.05:
            return o
    return None


def adjacent_lanes(c, look=0.0):
    """lanes a car may move into next: one over on the normal road, with a middle lane in the three-lane stretches"""
    three = wide_k(c["s"] + look) > 0.6
    if not three:
        return [-c["lane"]] if c["lane"] != 0 else [c["home"]]
    return [0] if c["lane"] != 0 else [-1, 1]


def _try_dodge(run, c, frac):
    """roadworks ahead in my lane: signal early and move to the open one"""
    hf = car_half(c)
    bl = static_blocker(c["s"], traffic_lx(c), 12.0, 340.0, hf)
    if bl is None:
        return False
    cands = adjacent_lanes(c)
    random.shuffle(cands)
    for tgt in cands:
        if static_blocker(c["s"] - 5.0, lane_lx(tgt, c["s"]), 0.0, bl["s"] - c["s"] + 70.0, hf) is not None:
            continue
        if not traffic_lane_clear(run, c, tgt, frac):
            continue
        c["st"], c["t"], c["tgt"] = "sig", 22, tgt
        return True
    return False


def traffic_lane_clear(run, c, tgt, frac):
    """is the target lane free for a lane change (other cars, hazards, the train, and, for polite drivers, you)?"""
    for o in run.traffic:
        if o is c or o["hit"]:
            continue
        d = o["s"] - c["s"]
        if o["lane"] == tgt and -24.0 < d < 34.0:
            return False
        if o["st"] == "sig" and o["tgt"] == tgt and abs(d) < 40.0:
            return False
    tl = tgt * (0.5 + wide_k(c["s"]) / 6.0)
    lo_i = bisect.bisect_left(HAZ_S, c["s"] - 2.0)
    for j in range(lo_i, min(len(HAZ), lo_i + 14)):
        o = HAZ[j]
        if o["s"] - c["s"] > 130.0:
            break
        if threatens(o, tl, car_half(c)):
            return False
    for q in RAILS:
        if -10.0 < q["s"] - c["s"] < 90.0 and q["state"] != "done" and q["state"] != "idle":
            return False
    rel = c["s"] - run.pos
    if abs(frac - tl) < 0.5:
        if not c["pushy"] and -22.0 < rel < 50.0:
            return False                       # polite drivers don't cut across you
        if c["pushy"] and -6.0 < rel < 14.0:
            return False                       # pushy ones will, but not onto your bonnet
    return True


_STALL_CACHE = {}


def _stalled_spot():
    """where a broken-down vehicle waits on the gravel descent: the point of the slope with the most room around it"""
    if _STALL_CACHE.get("k") == id(HAZ):
        return _STALL_CACHE["v"]
    best, bd = SLIDE[0] + 0.5 * (SLIDE[1] - SLIDE[0]), -1.0
    pts = [o["s"] for o in HAZ] + [q["s"] for q in RAILS if q["kind"] == "rail"]
    s = SLIDE[0] + 90.0
    while s < SLIDE[1] - 30.0:
        d = min((abs(p - s) for p in pts), default=999.0)
        if d > bd:
            best, bd = s, d
        s += 10.0
    _STALL_CACHE.update(k=id(HAZ), v=best)
    return best


def update_traffic(run):
    rng = run.trng
    for sp_ in THEME.get("logtrucks", ()):                       # a logging truck trundles along ahead of you, and loses a log
        if sp_ not in run.lt_done and run.pos > sp_ - 500.0:
            run.lt_done.add(sp_)
            ln_ = rng.choice((-1, 1))
            run.traffic.append(dict(s=sp_, v=0.40, v0=0.40, lane=ln_, lp=float(ln_), home=ln_, st=None, t=0, tgt=0, frm=float(ln_),
                                    cool=10 ** 9, pushy=False, kind="logtruck", color=(150, 100, 50), hit=False, hit_t=0, lxo=0.0,
                                    push=0.0, ox=0.0, ph=0, swt=0))
    for c_ in list(run.traffic):
        if c_["kind"] == "logtruck" and not c_.get("dropped") and not c_["hit"] and 30.0 < c_["s"] - run.pos < 150.0:
            c_["dropped"] = True
            run.traffic.append(dict(s=c_["s"] - 7.0, v=0.0, v0=0.0, lane=c_["lane"], lp=float(c_["lane"]), home=c_["lane"], st=None, t=0, tgt=0,
                                    frm=float(c_["lane"]), cool=10 ** 9, pushy=False, kind="log", color=(110, 72, 40), hit=False, hit_t=0,
                                    lxo=rng.uniform(-0.12, 0.12), push=0.0, ox=0.0, ph=0, swt=0, stall=True, yaw=rng.choice((-1, 1)) * rng.uniform(2, 6), drop=44))
            if AUDIO is not None:
                getattr(AUDIO, "event", lambda *a: None)("log_fall", max(0.35, min(1.0, 1.15 - (c_["s"] - run.pos) / 220.0)))
            if (c_["s"] - run.pos) < 110.0:
                run.shake_t, run.shake_amp = 14, 3.0
    for c_ in run.traffic:
        if c_.get("drop", 0) > 0:
            c_["drop"] -= 1
    if SLIDE is not None and not run.gravel_car:                 # a random broken-down vehicle somewhere on the loose gravel
        sp = _stalled_spot()
        if run.pos > sp - 950.0:
            run.gravel_car = True
            kind = random.choice(THEME.get("traffic", ("sedan", "van", "truck")) + ("sedan",))
            ln = random.choice((-1, 1))
            run.traffic.append(dict(s=sp, v=0.0, v0=0.0, lane=ln, lp=float(ln), home=ln, st=None, t=0, tgt=0, frm=float(ln),
                                    cool=10 ** 9, pushy=False, kind=kind, color=random.choice(THEME.get("car_colors", CAR_COLORS)),
                                    hit=False, hit_t=0, lxo=random.uniform(-0.1, 0.1) + 0.25 * ln, push=0.0, ox=0.0, ph=0, swt=0,
                                    stall=True, yaw=random.choice((-1, 1)) * random.uniform(5, 11)))
    while run.next_spawn < run.pos + 950:
        s = run.next_spawn
        _i = bisect.bisect_left(HAZ_S, s - 90.0)
        if _i < len(HAZ_S) and HAZ_S[_i] < s + 90.0:           # never appear in the middle of roadworks, deer or a crossing
            run.next_spawn += 120.0
            continue
        if INTERSECTIONS and near_intersection(s, 300.0):       # no new cars right before a crossing
            run.next_spawn += 120.0
            continue
        if any(z0 < s < z1 for z0, z1 in DEER_ZONES):          # deer need an empty road
            run.next_spawn += 120.0
            continue
        k = wide_k(s)
        r = rng.random()
        kind = "bike" if r < 0.17 else ("cyclist" if r < 0.31 else rng.choice(THEME.get("traffic", ("sedan", "sedan", "van", "truck"))))
        if kind == "bike":
            v = rng.uniform(0.62, 0.95)
        elif kind == "cyclist":
            v = rng.uniform(0.17, 0.26)
        else:
            v = rng.uniform(0.42, 0.90) if kind != "truck" else rng.uniform(0.38, 0.58)
        ln = 1 if kind == "cyclist" else rng.choice((-1, 1))
        col = rng.choice(THEME.get("car_colors", CAR_COLORS)) if kind != "cyclist" else rng.choice([(250, 220, 40), (240, 110, 30), (230, 60, 140), (60, 200, 90)])
        run.traffic.append(dict(s=s, v=v, v0=v, lane=ln, lp=float(ln), home=ln, st=None, t=0, tgt=0, frm=float(ln),
                                cool=(10 ** 9 if kind == "cyclist" else rng.randint(20, 160)), pushy=rng.random() < 0.15,
                                kind=kind, color=col, hit=False, hit_t=0, lxo=0.0, push=0.0, ox=0.0, ph=rng.randint(0, 300), swt=0))
        if k <= 0.3 and rng.random() < 0.55 and run.traffic[-1]["kind"] not in ("bike", "cyclist"):   # a slow one with a faster car coming up behind it: an overtake
            lead = run.traffic[-1]
            if lead["kind"] == "sedan":
                lead["kind"], lead["v"], lead["v0"] = rng.choice(("van", "truck", "hearse") if THEME.get("night") else ("van", "truck")), 0.42, 0.42
            lead["v"] = lead["v0"] = min(lead["v0"], rng.uniform(0.36, 0.5))
            run.traffic.append(dict(s=s - rng.uniform(200, 340), v=rng.uniform(0.78, 0.9), v0=0.0, lane=lead["lane"],
                                    lp=float(lead["lane"]), home=lead["lane"], st=None, t=0, tgt=0, frm=float(lead["lane"]),
                                    cool=rng.randint(10, 60), pushy=rng.random() < 0.2, kind="sedan",
                                    color=rng.choice(CAR_COLORS), hit=False, hit_t=0, lxo=0.0, push=0.0))
            run.traffic[-1]["v0"] = run.traffic[-1]["v"]
        run.next_spawn += rng.uniform(220, 420) if k > 0.3 else rng.uniform(650, 1100)
    frac, car_hw = car_lateral(run)
    if (not run.finale) and (not THEME.get("no_finale_car")) and run.pos > LEVEL_LEN - 640.0:     # the last car: it cuts into your lane just before the finish line
        run.finale = True
        pl = min((-1, 0, 1), key=lambda ln_: abs(lane_lx(ln_, run.pos + 250.0) - frac))
        side_ = 1 if pl <= 0 else -1
        ln2 = pl + side_
        ln2 = ln2 if ln2 in (-1, 1) or ln2 == 0 else pl - side_
        run.traffic.append(dict(s=run.pos + 330.0, v=0.50, v0=0.50, lane=ln2, lp=float(ln2), home=ln2, st=None, t=0, tgt=pl, frm=float(ln2),
                                cool=10 ** 9, pushy=True, kind="sedan", color=(214, 40, 40), hit=False, hit_t=0, lxo=0.0, push=0.0,
                                ox=0.0, ph=0, swt=0, finale=True))
    for c in run.traffic:
        if c.get("finale") and not c["hit"] and c["st"] is None and c["lane"] != c["tgt"] and 0 < c["s"] - run.pos < 150.0:
            c["st"], c["t"] = "sig", 14                       # short signal, then it swings across
    for c in run.traffic:                                   # riders wobble in their lane, and cyclists sometimes swerve
        if c["kind"] in ("bike", "cyclist") and not c["hit"]:
            c["ph"] += 1
            if c["kind"] == "cyclist":
                base = 0.34 - 0.2 * wide_k(c["s"])
                if c["swt"] > 0:
                    c["swt"] -= 1
                elif rng.random() < 0.003 and 60.0 < c["s"] - run.pos < 400.0:
                    c["swt"] = 70
                sw = -0.42 * math.sin(math.pi * (1.0 - c["swt"] / 70.0)) if c["swt"] > 0 else 0.0
                c["ox"] = base + sw + 0.03 * math.sin(c["ph"] / 19.0)
            else:
                c["ox"] = 0.07 * math.sin(c["ph"] / 17.0) + (0.10 * math.sin(c["ph"] / 7.0) if (c["ph"] // 160) % 3 == 0 else 0.0)
    # lane changes: signal, check the other lane, go. More of it in the wide stretches.
    for c in run.traffic:
        if c["hit"] or c.get("stall"):
            continue
        st = c["st"]
        wk = wide_k(c["s"])
        locked = near_fork(c["s"], 40.0)                      # no lane swapping inside the fork: it looks wrong
        if st == "sig":
            c["t"] -= 1
            if c["t"] <= 0:
                if not locked and traffic_lane_clear(run, c, c["tgt"], frac):
                    c["st"], c["t"], c["frm"], c["lane"] = "move", 0, c["lp"], c["tgt"]
                else:
                    c["st"], c["cool"] = None, 60
        elif st == "move":
            c["t"] += 1
            u = min(1.0, c["t"] / LANE_CHANGE_FRAMES)
            u = u * u * (3.0 - 2.0 * u)
            c["lp"] = c["frm"] + (c["lane"] - c["frm"]) * u
            if c["t"] >= LANE_CHANGE_FRAMES:
                c["st"], c["lp"], c["cool"] = None, float(c["lane"]), (30 if wk > 0.5 else 140)
        elif c["kind"] == "cyclist" or locked:
            if c["cool"] > 0:
                c["cool"] -= 1
        elif c["s"] - run.pos > -30 and c["lane"] == 0 and wide_k(c["s"] + 170.0) < 0.6 and rng.random() < 0.3:
            # the third lane is about to end: get out of the middle
            if traffic_lane_clear(run, c, c["home"], frac):
                c["st"], c["t"], c["tgt"] = "sig", 20, c["home"]
        elif c["s"] - run.pos > -30 and rng.random() < 0.25 and _try_dodge(run, c, frac):
            pass
        elif c["cool"] > 0:
            c["cool"] -= 1
        elif rng.random() < (0.12 if wk > 0.5 else 0.07) and c["s"] - run.pos > -30:
            tgt = None
            blocker = None
            for o in run.traffic:
                if o is not c and not o["hit"] and o["lane"] == c["lane"] and 0.1 < o["s"] - c["s"] < 70.0 \
                        and o["v"] < c["v0"] - 0.04:
                    blocker = o
                    break
            cands = adjacent_lanes(c)
            if blocker is not None:
                tgt = random.choice(cands)                         # blocked: go round
            elif wk > 0.6 and rng.random() < 0.6:
                cands = [x for x in cands if x != 0 or wide_k(c["s"] + 250.0) > 0.8]
                tgt = random.choice(cands) if cands else None      # three lanes: change lane just because
            elif c["lane"] != c["home"] and rng.random() < 0.6 \
                    and static_blocker(c["s"] - 5.0, lane_lx(c["home"], c["s"]), 0.0, 130.0, car_half(c)) is None:
                tgt = c["home"]                                    # passed it: back to the usual lane
            if tgt is not None and traffic_lane_clear(run, c, tgt, frac):
                c["st"], c["t"], c["tgt"] = "sig", 46 if not c["pushy"] else (18 if wk > 0.5 else 30), tgt
            else:
                c["cool"] = 25
    # cars follow each other and queue up behind roadworks / a train instead of driving through them
    by_lane = {}
    for c in run.traffic:
        if not c["hit"]:
            by_lane.setdefault(c["lane"], []).append(c)
    for lane_cars in by_lane.values():
        lane_cars.sort(key=lambda c: c["s"])
    for c in run.traffic:
        if c["hit"]:
            continue
        cap = c["v0"]
        ahead = None
        for o in by_lane.get(c["lane"], ()):
            if o["s"] > c["s"] + 0.1 and o is not c:
                ahead = o
                break
        if ahead is not None:
            gap = ahead["s"] - c["s"] - 9.0                     # bumper to bumper, with some air
            if gap < 25.0:
                cap = min(cap, max(0.0, ahead["v"] * 0.97 + (gap - 8.0) * 0.012))
            if gap < 2.0:
                c["s"] = ahead["s"] - 11.0
        lo_i = bisect.bisect_left(HAZ_S, c["s"] - 1.0)
        for j in range(lo_i, min(len(HAZ), lo_i + 14)):
            o = HAZ[j]
            stand = 8.0 if o["kind"] in ("cone", "barrier") else 18.0      # keep well back from people and animals
            d = o["s"] - c["s"] - stand
            if d > 180.0:
                break
            if o["kind"] == "xcar":
                d = o["s"] - c["s"] - 13.0                                  # wait at the stop line for crossing cars
                if o["started"] and d > -6.0 and (abs(o["lx"]) < 2.8 or (abs(o["lx"]) < 8.0 and o["lx"] * o["dir"] < 0)):
                    cap = min(cap, (2.0 * 0.0022 * max(0.0, d)) ** 0.5)
                continue
            if threatens(o, traffic_lx(c), car_half(c)):
                cap = min(cap, (2.0 * 0.0022 * max(0.0, d)) ** 0.5)         # brake early and smoothly, like a driver would
        for q in RAILS:
            d = q["s"] - c["s"] - 14.0
            if 0.0 < d + 14.0 < 180.0 and q["state"] in ("lights", "train", "clear"):
                cap = min(cap, (2.0 * 0.0022 * max(0.0, d)) ** 0.5)
        c["v"] += max(-0.02, min(0.02, cap - c["v"]))
    keep = []
    for c in run.traffic:
        c["s"] += c["v"]
        if c["hit"]:
            c["hit_t"] += 1
            c["lxo"] += c["push"]
        d = c["s"] - run.pos
        if d < -40 or c["hit_t"] > 70:
            continue
        if d > 420.0 and not c.get("stall") and c["kind"] != "logtruck" and any(z0 < c["s"] < z1 for z0, z1 in DEER_ZONES):
            continue                                        # too far to see: keep deer stretches empty
        keep.append(c)
        if c["hit"] or not (-1.5 <= d <= 4.0):
            continue
        if c["kind"] == "log" and c.get("drop", 0) > 20:
            continue                                        # still in the air
        el_, er_, _c = road_at(H - 30)
        hw_px = CAR_SIZE_M[c["kind"]][0] * PXM * 1.15 / 2.0          # roughly as wide as it is drawn
        if abs(frac - traffic_lx(c)) < car_hw + hw_px / ((er_ - el_) / 2.0) - 0.015:
            c["hit"] = True
            c["push"] = 0.025 if traffic_lx(c) >= frac else -0.025
            if c["kind"] == "log":
                c["push"] = 0.0
                c["v"] = c["v0"] = 0.0
                run.speed *= 0.3
                run.car_xv += -3.0 if traffic_lx(c) >= frac else 3.0
                run.hits += 1
                run.crash = 50
                run.crash_msg = "LOG!" + time_pen(run, 0.3)
                add_damage(run, DAMAGE["log"])
                if AUDIO is not None:
                    AUDIO.hit("faltree", 0.7)
                continue
            if c.get("stall"):
                c["v"] = 0.35                                    # it was parked: you stop against it, it lurches forward
            c["v"] *= 0.6
            c["v0"] = c["v"]
            run.speed = min(run.speed * 0.6, c["v"] / M_PER_FRAME * 0.9)
            run.car_xv += -4.0 if c["push"] > 0 else 4.0
            run.hits += 1
            run.crash = 50
            run.crash_msg = ("REAR-ENDED!" if d > 0.5 else "SIDESWIPE!") + time_pen(run, 0.6 if d > 0.5 else 0.8)
            add_damage(run, DAMAGE["car"])
            if AUDIO is not None:
                AUDIO.hit("ped" if c["kind"] in ("bike", "cyclist") else ("rear" if d > 0.5 else "side"), 0.7)
            if not c.get("stall") and c["kind"] in ("sedan", "van", "truck", "hearse", "logtruck"):      # a driver on the move honks at you; a parked car stays quiet
                run.reply = run.frames + random.randint(14, 26)
                run.reply_v = 0.9
                run.reply_k = None
    run.traffic = keep


_CAR_RECTS = []                    # (rect, first light index) of each vehicle drawn this frame, far to near


_TRIP = {}


def draw_trip_fx(run):
    """mild mushroom effects (after the reference clip): the picture slowly breathes and stretches, wobbles like heat haze, the colours drift round and a soft glow blooms"""
    t = run.trip_t
    k = min(1.0, t / 240.0)                                              # eases in over about four seconds
    if not run.trip:
        k *= run.untrip / 100.0                                          # and fades out again when the druid has cured you
    ph = t * 0.022
    base = screen.copy()
    sx = 1.0 + 0.04 * k * math.sin(ph * 1.3)
    sy = 1.0 + 0.04 * k * math.sin(ph * 1.3 + math.pi)
    sw, sh = int(W * sx), int(H * sy)
    sc = pygame.transform.scale(base, (sw, sh))
    ox, oy = (W - sw) // 2, (H - sh) // 2
    for y in range(0, H, 6):
        sy_ = y - oy
        if sy_ < 0 or sy_ + 6 > sh:
            continue
        dx = int(math.sin(ph * 3.0 + y * 0.03) * 3.0 * k)
        screen.blit(sc, (ox + dx, y), (0, sy_, sw, 6))
    r_, g_, b_ = (0.5 + 0.5 * math.sin(ph), 0.5 + 0.5 * math.sin(ph + 2.1), 0.5 + 0.5 * math.sin(ph + 4.2))
    screen.fill((int(255 - 38 * k * (1 - r_)), int(255 - 38 * k * (1 - g_)), int(255 - 38 * k * (1 - b_))), special_flags=pygame.BLEND_RGB_MULT)
    screen.fill((int(22 * k * r_), int(22 * k * g_), int(26 * k * b_)), special_flags=pygame.BLEND_RGB_ADD)
    if t % 4 == 0 or "glow" not in _TRIP:                                # the glow is only refreshed every few frames: it is soft anyway
        gl = pygame.transform.scale(pygame.transform.scale(screen, (W // 6, H // 6)), (W, H))
        gl.fill((int(90 * k),) * 3, special_flags=pygame.BLEND_RGB_MULT)
        _TRIP["glow"] = gl
    screen.blit(_TRIP["glow"], (0, 0), special_flags=pygame.BLEND_RGB_ADD)


def update_trip(run):
    """after the mushroom: every so often a figure (with two copies) stands across the road ahead, and vanishes just before you reach it"""
    if run.untrip > 0:
        run.untrip -= 1
    if not run.trip:
        return
    run.trip_t += 1
    v = run.vis
    if v:
        v["t"] += 1
        if v["s"] - run.pos < v["vanish"] or v["t"] > 700:
            run.vis = None
            run.vis_next = random.randint(450, 1100)
        return
    run.vis_next -= 1
    if run.vis_next > 0:
        return
    s = run.pos + 175.0
    if (TUNNEL and TUNNEL[0] - 200 < s < TUNNEL[1] + 30) or s > LEVEL_LEN - 120:
        run.vis_next = 60
        return
    run.vis = dict(s=s, t=0, vanish=random.uniform(22, 34), who=random.choice(("stranger", "stranger", "stranger", "deer")), look=0, seed=random.randint(0, 8))


_VIS = {}


def draw_vision(run):
    v = run.vis
    if not v:
        return
    zd = v["s"] - run.pos + Z1
    if zd < Z1 * 0.55 or zd > DRAW_DIST:
        return
    t = Z1 / zd
    y = int(proj_y(zd))
    el, er, _ = edges_zd(zd)
    name = v["who"]
    key = name
    spr = _VIS.get(key)
    if spr is None:
        spr = sprites.get(name, 0).copy()
        if name != "stranger":
            spr.fill((60, 40, 90), special_flags=pygame.BLEND_RGB_ADD)          # the deer is ghostly pale, the man stays pitch black
        _VIS[key] = spr
    sh = int(sprites.HEIGHT_M.get(name, 1.6) * PXM * t ** 0.65)
    if sh < 4:
        return
    sw = max(2, int(spr.get_width() / spr.get_height() * sh))
    img = pygame.transform.scale(spr, (sw, sh))
    gap = v["s"] - run.pos
    ph = (v["t"] // 18 + v["seed"]) % 9                     # every ~0.3 s the set of copies changes: only the middle one, all three, a pair, a lone one at the side...
    sets = ((1,), (0, 1, 2), (1,), (0, 2), (0, 1, 2), (2,), (1,), (0, 1), (0, 1, 2))
    shown = sets[ph] if gap > 70 else (0, 1, 2)             # right before the end all three stand there
    for i, lx in enumerate((-0.62, 0.0, 0.62)):
        if i not in shown:
            continue
        if (v["t"] * 3 + i * 7 + v["seed"]) % 29 > 24:     # and each copy blinks out now and then
            continue
        wob = int(math.sin((v["t"] + i * 17) * 0.13) * sw * 0.08)
        cx = el + (lx + 1.0) / 2.0 * (er - el)
        screen.blit(img, (int(cx - sw / 2) + wob, y - sh))


def draw_traffic(run):
    hy = view.hy
    drawn = []                                         # (rect, first light, last light) per car, far to near
    for c in sorted(run.traffic, key=lambda c: -c["s"]):
        zd = c["s"] - run.pos + Z1
        if zd < Z1 * 0.55 or zd > DRAW_DIST:
            continue
        t = Z1 / zd
        y = int(proj_y(zd))
        el, er, _ = edges_zd(zd)
        cx = el + (traffic_lx(c) + 1.0) / 2.0 * (er - el)
        w_m, h_m = CAR_SIZE_M[c["kind"]]
        te = t ** 0.7
        sw, sh = int(w_m * PXM * te * 1.15), int(h_m * PXM * te * 1.15)
        if sw < 3 or sh < 2:
            continue
        if c["kind"] == "cyclist" and THEME.get("witch"):
            spr = sprites.get("witch")
        else:
            spr = sprites.get("traffic", 0, kind=c["kind"], color=c["color"])
        img = pygame.transform.scale(spr, (sw, sh))
        sig_dir = 0
        if c["st"] == "sig":
            sig_dir = 1 if c["tgt"] > c["lane"] else -1
        elif c["st"] == "move":
            sig_dir = 1 if c["lane"] > c["frm"] else -1
        if c["st"] == "move" and sw > 8:
            img = pygame.transform.rotate(img, -sig_dir * 4)                  # slight yaw while it slides over
        if c.get("stall") and not c["hit"] and sw > 8:
            img = pygame.transform.rotate(img, c["yaw"])                      # skewed across the gravel
        if c["hit"]:
            img = pygame.transform.rotate(img, min(40, c["hit_t"] * 2) * (1 if c["push"] > 0 else -1))
            if c["hit_t"] > 40:
                img.set_alpha(max(0, 255 - (c["hit_t"] - 40) * 8))
        cy = clip_y(zd)
        if y - sh > cy:
            continue                                    # entirely behind a crest
        screen.set_clip((0, 0, W, max(0, cy)))
        pygame.draw.ellipse(screen, (16, 10, 6), (int(cx - sw * 0.55), y - max(2, sh // 8), int(sw * 1.1), max(3, sh // 5)))
        dy_ = 0
        if c.get("drop", 0) > 0:                                  # the log drops off the truck and bounces
            u_ = c["drop"] / 44.0
            dy_ = int(abs(math.sin((1.0 - u_) * math.pi * 2.5)) * sh * 3.0 * u_)
        screen.blit(img, (int(cx - img.get_width() / 2), y - img.get_height() - dy_))
        screen.set_clip(None)
        l0 = len(LIGHTS)
        drawn.append((pygame.Rect(int(cx - img.get_width() / 2), y - img.get_height(), img.get_width(), img.get_height()), l0))
        if sw > 6 and c["kind"] != "log":                  # (a log lying on the road has no tail lights)
            r = max(5, int(sw * 0.3))
            LIGHTS.append((int(cx - sw * 0.33), y - int(sh * 0.4), r, (255, 40, 24)))
            LIGHTS.append((int(cx + sw * 0.33), y - int(sh * 0.4), r, (255, 40, 24)))
            if c.get("stall") and not c["hit"] and (pygame.time.get_ticks() // 380) % 2 == 0:       # hazard lights
                for sd_ in (-1, 1):
                    bx, by, bs = int(cx + sd_ * sw * 0.46), y - int(sh * 0.42), max(2, sw // 9)
                    pygame.draw.rect(screen, (255, 176, 28), (bx - bs // 2, by - bs // 2, bs, bs))
                    LIGHTS.append((bx, by, max(8, int(sw * 0.3)), (255, 170, 30)))
            if sig_dir and (pygame.time.get_ticks() // 240) % 2 == 0:               # indicator on the side it is moving to
                bx = int(cx + sig_dir * sw * 0.46)
                by = y - int(sh * 0.42)
                bs = max(2, sw // 9)
                pygame.draw.rect(screen, (255, 176, 28), (bx - bs // 2, by - bs // 2, bs, bs))
                LIGHTS.append((bx, by, max(6, int(sw * 0.22)), (255, 170, 30)))
    _CAR_RECTS[:] = drawn
    _CAR_RECTS.append((None, len(LIGHTS)))                                   # end marker for the light ranges


def draw_car(run, braking):
    shake_x = shake_y = 0
    if run.off and run.speed > 0.05:
        shake_x, shake_y = random.randint(-2, 2), random.randint(-2, 1)
    spr = car_sprite.get(braking, run.car_scale, SET["car"], 1 if run.lid_off else 0)
    lean = int(run.wheel * run.speed * 3)       # tiny visual weight shift with the wheel
    x = int(run.car_x) - spr.get_width() // 2 + shake_x + lean
    y = H - spr.get_height() + shake_y
    screen.blit(spr, (x, y))
    if run.lid_off and SET["car"] % len(CARS) == 4:                  # the dangling shin swings about the knee
        leg, lx, ly = car_sprite.get_leg(run.car_scale, run.leg * 34.0)
        screen.blit(leg, (x + lx, y + ly))


# ------------------------------------------------------------------ drawing: hud
def text(s, f, col, x, y, align="left", alpha=None):
    surf = f.render(s, True, col)
    shadow = f.render(s, True, (10, 6, 4))
    if alpha is not None:
        surf.set_alpha(alpha)
        shadow.set_alpha(alpha)
    w = surf.get_width()
    if align == "center":
        x -= w // 2
    elif align == "right":
        x -= w
    screen.blit(shadow, (x + 2, y + 2))
    screen.blit(surf, (x, y))


def fmt_time(t):
    return f"{int(t // 60)}:{t % 60:04.1f}"


def draw_hud(run, keys_down):
    pygame.draw.rect(screen, (20, 12, 8), (0, 0, W, 6))
    frac = max(0.0, min(1.0, run.pos / LEVEL_LEN))
    pygame.draw.rect(screen, (210, 170, 40), (0, 0, int(W * frac), 6))
    for z in ZONES[1:]:
        pygame.draw.rect(screen, (255, 240, 200), (int(W * z[1] / LEVEL_LEN), 0, 2, 6))

    text(f"{int(run.speed * KMH):3d} km/h", font_mid, (232, 192, 50), 12, 14)
    text(ZONES[zone_index(run.pos)][0], font, (200, 150, 60), W // 2, 16, "center")
    tl = max(0.0, run.time_left())
    low = tl < 10.0 and run.state == "race"
    tcol = (255, 70, 50) if low and (run.frames // 10) % 2 == 0 else (232, 192, 50)
    text(f"TIME {int(tl // 60)}:{int(tl % 60):02d}", font_mid, tcol, W - 12, 14, "right")
    text(f"{max(0.0, LEVEL_LEN - run.pos) / 1000:.1f} km to go", font, (176, 136, 52), W - 12, 38, "right")
    if run.state == "race" and run.off:
        text("!! OFF ROAD !!", font_mid, (240, 70, 40), W // 2, 52, "center")
    elif run.state == "race" and slide_k(run.pos) > 0.25 and (run.frames // 20) % 2 == 0:
        text(THEME.get("slide_banner", "LOOSE GRAVEL - DOWNHILL"), font_mid, (244, 170, 50), W // 2, 52, "center")
    dm = run.damage / 100.0
    pygame.draw.rect(screen, (30, 14, 10), (12, 40, 104, 9))
    pygame.draw.rect(screen, (250, 120, 50) if dm < 0.7 else (255, 50, 40), (14, 42, int(100 * dm), 5))
    pygame.draw.rect(screen, (200, 150, 60), (12, 40, 104, 9), 1)
    text("DAMAGE", font, (200, 150, 60), 122, 36)
    if run.cp_msg > 0:
        text("CHECKPOINT!", font_mid, (250, 220, 60), W // 2, 70, "center", min(255, run.cp_msg * 8))
        text(f"+{int(THEME.get('cp_bonus', CP_BONUS) * car_clock())} SEC   REPAIRED", font, (230, 200, 90), W // 2, 94, "center", min(255, run.cp_msg * 8))
    if run.crash > 0 and run.crash_msg:
        text(run.crash_msg, font_mid, (255, 90, 50), W // 2, 120, "center", min(255, run.crash * 10))
    if run.fx_t > 0 and run.fx_msg:
        text(run.fx_msg, font_mid, (190, 150, 255), W // 2, 204, "center", min(255, run.fx_t * 8))
    if run.bonus_t > 0 and run.bonus_msg:
        text(run.bonus_msg, font_mid, (110, 255, 120), W // 2, 176, "center", min(255, run.bonus_t * 10))
    if run.spook > 25:
        text("BOO!  FROZEN TYRES", font_mid, (170, 220, 255), W // 2, 150, "center", min(255, run.spook * 8))
    if run.state == "race" and run.banner > 0:
        a = min(255, run.banner * 4)
        text("ENTERING", font, (170, 130, 60), W // 2, 84, "center", a)
        text(ZONES[run.zone_i][0], font_mid, (240, 200, 70), W // 2, 100, "center", a)


def dim(alpha):
    ov = pygame.Surface((W, H), pygame.SRCALPHA)
    ov.fill((0, 0, 0, alpha))
    screen.blit(ov, (0, 0))


END_BTNS = []                          # (rect, key) of the buttons on the finish / game-over screen


def _car_pic(ci):
    return car_sprite.get(False, 1, ci % len(CARS))


def draw_board_rows(rows, hl, y0, rowh):
    """top table: rows = [(rank, name, time_ms, hits, car)], hl = (name, time_ms) of the player's own row"""
    x0 = W // 2 - 260
    for i_, (rk, nm, tms, hits, ci) in enumerate(rows):
        yy = y0 + i_ * rowh
        mine = hl is not None and nm.lower() == hl[0].lower() and tms == hl[1]
        if mine:
            pygame.draw.rect(screen, (70, 46, 18), (x0 - 6, yy - 4, 532, rowh - 4), border_radius=5)
            pygame.draw.rect(screen, (255, 210, 70), (x0 - 6, yy - 4, 532, rowh - 4), 1, border_radius=5)
        col = (255, 226, 100) if mine else (210, 170, 80) if rk > 3 else (255, 210, 70)
        pic = _car_pic(ci)
        screen.blit(pic, (x0 + 46, yy + 15 - pic.get_height() // 2))
        text("%d" % rk, font_mid, col, x0 + 30, yy + 5, "right")
        text(nm, font_mid, col, x0 + 96, yy + 5)
        text(fmt_time(tms / 1000.0), font_mid, col, x0 + 350, yy + 5, "right")
        text("%d" % hits, font_mid, (190, 140, 60), x0 + 410, yy + 5, "right")
        if hits == 0:
            text("CLEAN", font, (120, 230, 100), x0 + 428, yy + 8)
    if rows:
        text("HITS", font, (130, 100, 50), x0 + 410, y0 - 24, "right")
        text("CAR", font, (130, 100, 50), x0 + 46, y0 - 24)


def _sub_page(n):
    """which block of five rows is showing (kept inside the range)"""
    last = max(0, (n - 1) // 5)
    MENU["sc_sub"] = max(0, min(MENU.get("sc_sub", 0), last))
    return MENU["sc_sub"]


def _sub_buttons(sub, n):
    """PREV / NEXT for the next five places (only when there are more than five scores)"""
    if n <= 5:
        return
    last = (n - 1) // 5
    if sub > 0:
        button((40, 396, 120, 44), pygame.K_UP, label="PREV")
    if sub < last:
        button((W - 160, 396, 120, 44), pygame.K_DOWN, label="NEXT")
    text("PLACES %d-%d OF %d" % (sub * 5 + 1, min(n, sub * 5 + 5), n), font, (150, 112, 54), W // 2, 414, "center")


def draw_champs(y0, rowh):
    """one line per car: the best run on it"""
    x0 = W // 2 - 260
    for ci in range(len(CARS)):
        yy = y0 + ci * rowh
        row = scores.CHAMPS["best"].get(ci)
        pic = _car_pic(ci)
        screen.blit(pic, (x0, yy + 10 - pic.get_height() // 2 - 2))
        text(CARS[ci]["name"], font, (190, 140, 60), x0 + 46, yy + 3)
        if row:
            hits = int(row.get("hits", 0))
            text(str(row.get("name", "")), font_mid, (255, 226, 100), x0 + 190, yy)
            text(fmt_time(int(row.get("time_ms", 0)) / 1000.0), font_mid, (255, 210, 70), x0 + 400, yy, "right")
            text("%d" % hits, font_mid, (190, 140, 60), x0 + 450, yy, "right")
            if hits == 0:
                text("CLEAN", font, (120, 230, 100), x0 + 466, yy + 3)
        else:
            text("-  nobody yet  -", font, (110, 84, 44), x0 + 190, yy + 3)
    text("HITS", font, (130, 100, 50), x0 + 450, y0 - 24, "right")


SHAME_FROM = 0.25                      # a run that did not finish only goes to the Hall of Shame after this part of the track


def sb_tick(run):
    """moves the end screen through its steps: name -> sending -> loading -> board"""
    ph = run.sb_phase
    over = run.state == "over"
    if ph == "idle":
        run.sb_name = scores.clean_name(SET.get("name", ""))
        ok_ = scores.enabled() and (not over or run.pos >= SHAME_FROM * LEVEL_LEN)
        run.sb_phase = "name" if ok_ else "off"
    elif ph == "sending" and scores.SEND["status"] in ("ok", "error"):
        if scores.SEND["status"] == "ok":
            run.sb_phase = "loading"
            if over:
                scores.load_shame(LEVEL)
            else:
                scores.load(LEVEL)
        else:
            run.sb_phase = "error"
    elif ph == "loading":
        st_ = (scores.SHAME if over else scores.BOARD)["status"]
        if st_ in ("ok", "error"):
            run.sb_phase = "board" if st_ == "ok" else "error"


def sb_submit(run):
    name = scores.clean_name(run.sb_name)
    if not name:
        return
    run.sb_name = name
    SET["name"] = name
    save_settings()
    run.sb_phase = "sending"
    if run.state == "over":
        scores.send_shame(name, SET["car"] % len(CARS), LEVEL, int(run.pos), run.cause)
    else:
        scores.send(name, SET["car"] % len(CARS), LEVEL, int(round(run.finish_time * 1000)), run.hits)


def sb_key(run, ev):
    """a key on the finish screen while the scoreboard is busy. True = used up"""
    ph = run.sb_phase
    if ph in ("sending", "loading"):
        if ev.key == pygame.K_ESCAPE:
            run.sb_phase = "off"
        return True
    if ph != "name":
        return False
    k = ev.key
    if k == pygame.K_RETURN:
        sb_submit(run)
    elif k == pygame.K_ESCAPE:
        run.sb_phase = "off"
    elif k == pygame.K_BACKSPACE:
        run.sb_name = run.sb_name[:-1]
    elif k == pygame.K_TAB:
        if sys.platform == "emscripten":                          # a phone (or Safari) types through the browser's own box
            try:
                import platform
                v = platform.window.prompt("YOUR NAME (up to 10 letters or numbers)", run.sb_name)
                if v is not None:
                    run.sb_name = scores.clean_name(v)
            except Exception:
                pass
    else:
        ch = getattr(ev, "unicode", "") or ""
        if not ch:
            nm = pygame.key.name(k) if k < 1000 else ""
            ch = nm if len(nm) == 1 else ""
        ch = ch.upper()
        if ch and ch in scores.NAME_OK and len(run.sb_name) < scores.NAME_MAX:
            run.sb_name += ch
    return True


def draw_shame_rows(rows, hl, y0, rowh):
    """Hall of Shame table: rows = [(rank, name, dist_m, cause, car)]"""
    x0 = W // 2 - 260
    for i_, (rk, nm, dist, cause, ci) in enumerate(rows):
        yy = y0 + i_ * rowh
        mine = hl is not None and nm.lower() == hl.lower()
        if mine:
            pygame.draw.rect(screen, (70, 46, 18), (x0 - 6, yy - 4, 532, rowh - 4), border_radius=5)
            pygame.draw.rect(screen, (255, 210, 70), (x0 - 6, yy - 4, 532, rowh - 4), 1, border_radius=5)
        col = (255, 226, 100) if mine else (210, 170, 80) if rk > 3 else (255, 210, 70)
        pic = _car_pic(ci)
        screen.blit(pic, (x0 + 46, yy + 15 - pic.get_height() // 2))
        text("%d" % rk, font_mid, col, x0 + 30, yy + 5, "right")
        text(nm, font_mid, col, x0 + 96, yy + 5)
        text("%.1f KM" % (dist / 1000.0), font_mid, col, x0 + 330, yy + 5, "right")
        text(cause, font, (230, 90, 70), x0 + 350, yy + 8)
    if rows:
        text("CAR", font, (130, 100, 50), x0 + 46, y0 - 24)
        text("FURTHEST", font, (130, 100, 50), x0 + 330, y0 - 24, "right")
        text("WHAT GOT THEM", font, (130, 100, 50), x0 + 350, y0 - 24)


def draw_finish_score(run):
    """finish / game over screen with the online board; returns False when the plain screen should be used"""
    ph = run.sb_phase
    if ph in ("idle", "off"):
        return False
    over = run.state == "over"
    if ph == "board":
        screen.fill((24, 16, 10))                                 # a clean page for the table
    else:
        dim(170)
    me = scores.clean_name(run.sb_name)
    tms = int(round(run.finish_time * 1000))
    if ph == "board":
        ci = SET["car"] % len(CARS)
        if over:
            text("HALL OF SHAME", font_mid, (230, 90, 70), W // 2, 14, "center")
            rk = scores.shame_rank_of(me)
            yl = "YOU:  %.1f KM   %s" % (run.pos / 1000.0, run.cause)
            yl += ("   PLACE %d" % rk) if rk else "   (NOT IN THE TOP 80)"
            text(yl, font, (255, 226, 100), W // 2, 50, "center")
            rows = scores.top_shame(5)
            if rk > 5:
                rows = rows + [(rk, me, int(run.pos), run.cause, ci)]
            draw_shame_rows(rows, me, 110, 40)
        else:
            text("TOP 5   ALL CARS", font_mid, (230, 190, 50), W // 2, 14, "center")
            rows = scores.top(5)
            rk = scores.rank_of(me, tms)
            yl = "YOU:  %s   HITS %d" % (fmt_time(run.finish_time), run.hits)
            yl += ("   PLACE %d" % rk) if rk else "   (NOT IN THE TOP 80)"
            text(yl, font, (255, 226, 100), W // 2, 50, "center")
            if rk > 5:                                                 # not in the top 5: show where you are underneath
                rows = rows + [(rk, me, tms, run.hits, ci)]
            draw_board_rows(rows, (me, tms), 110, 40)
        draw_end_buttons(H - 74)
        return True
    if over:
        text(run.over_reason, font_big, (240, 80, 50), W // 2, 56, "center")
        text(f"REACHED  {run.pos / 1000:.1f} KM OF {LEVEL_LEN / 1000:.1f}     HITS  {run.hits}", font_mid, (240, 200, 70), W // 2, 114, "center")
        text("YOU MADE IT INTO THE HALL OF SHAME", font, (190, 140, 60), W // 2, 144, "center")
    else:
        text("FINISH", font_big, (230, 190, 50), W // 2, 56, "center")
        text(f"TIME  {fmt_time(run.finish_time)}     HITS  {run.hits}     LEFT  {int(max(0, run.time_left()))}s", font_mid, (240, 200, 70), W // 2, 114, "center")
        best = RECORD["best"]
        if best is not None:
            text(f"BEST  {fmt_time(best)}" + ("  NEW BEST!" if run.new_best else ""), font, (190, 140, 60), W // 2, 144, "center")
    if ph == "name":
        del END_BTNS[:]
        text("ENTER YOUR NAME", font_mid, (240, 200, 70), W // 2, 196, "center")
        box = pygame.Rect(W // 2 - 140, 226, 280, 56)
        END_BTNS.append((box, pygame.K_TAB))
        pygame.draw.rect(screen, (30, 20, 12), box, border_radius=8)
        pygame.draw.rect(screen, (255, 210, 70), box, 2, border_radius=8)
        cur = "_" if (pygame.time.get_ticks() // 400) % 2 == 0 and len(run.sb_name) < scores.NAME_MAX else ""
        text(run.sb_name + cur, font_big, (255, 226, 100), box.centerx, box.y + 8, "center")
        text("TAP THE BOX TO TYPE" if TOUCH["on"] else "TYPE YOUR NAME", font, (150, 112, 56), W // 2, 290, "center")
        for i_, (lab, key) in enumerate((("SUBMIT", pygame.K_RETURN), ("SKIP", pygame.K_ESCAPE))):
            r = pygame.Rect(W // 2 - 200 + i_ * 210, 334, 190, 46)
            END_BTNS.append((r, key))
            pygame.draw.rect(screen, (60, 38, 18) if me or i_ else (36, 24, 14), r, border_radius=8)
            pygame.draw.rect(screen, (230, 190, 50) if me or i_ else (90, 66, 30), r, 2, border_radius=8)
            text(lab, font_mid, (240, 200, 70) if me or i_ else (120, 92, 48), r.centerx, r.y + 6, "center")
            if not TOUCH["on"]:
                text("ENTER" if key == pygame.K_RETURN else "ESC", font, (150, 112, 56), r.centerx, r.bottom + 6, "center")
        return True
    if ph in ("sending", "loading"):
        del END_BTNS[:]
        text("SENDING YOUR RESULT..." if ph == "sending" else "LOADING THE BOARD...", font_mid, (240, 200, 70), W // 2, 240, "center")
        return True
    text("SCOREBOARD NOT REACHABLE", font_mid, (240, 100, 70), W // 2, 230, "center")
    draw_end_buttons()
    return True


def draw_end_buttons(y=None):
    del END_BTNS[:]
    for i_, (lab, key) in enumerate((("PLAY AGAIN", pygame.K_RETURN), ("MAIN MENU", pygame.K_ESCAPE))):
        r = pygame.Rect(W // 2 - 200 + i_ * 210, H // 2 + 72 if y is None else y, 190, 46)
        END_BTNS.append((r, key))
        pygame.draw.rect(screen, (60, 38, 18), r, border_radius=8)
        pygame.draw.rect(screen, (230, 190, 50), r, 2, border_radius=8)
        text(lab, font_mid, (240, 200, 70), r.centerx, r.y + 6, "center")
        if not TOUCH["on"]:
            text("ENTER" if key == pygame.K_RETURN else "ESC", font, (150, 112, 56), r.centerx, r.bottom + 6, "center")


RADIO_RECT = [pygame.Rect(0, 0, 0, 0)]
RADIO_NAMES = {"music": ("DARK.FM", "MianN - Never Alone"), "ftf_labandon": ("NOISE RADIO", "Fuck The Facts - L'abandon"), "haunted_radio": ("HAUNTED RADIO", "Nothing but screaming"), "overplayed": ("OVERPLAYED.FM", "Miss Artificial - Intelligence")}      # file name -> (station, band - title)
RADIO_ST = {"last": -1, "flash": 0, "ang": 0.0, "scroll": 0.0}


def _rtext(surf, s, col, x, y):
    surf.blit(font.render(s, True, (10, 6, 4)), (x + 1, y + 1))
    surf.blit(font.render(s, True, col), (x, y))


def draw_radio(run, frame):
    """car-radio faceplate: station + scrolling track in a little display, a knob that turns, press R (or tap it) to change station.
    Bright for a few seconds at the start and after every change, then faint so it stays out of the picture."""
    RADIO_RECT[0] = pygame.Rect(0, 0, 0, 0)
    if SET["vm"] <= 0 or not SET["music"] or run.state not in ("countdown", "race"):
        return
    st = AUDIO.station % len(audio.STATIONS)
    if RADIO_ST["last"] != st:
        if RADIO_ST["last"] != -1:
            RADIO_ST["scroll"] = 0.0
        RADIO_ST["last"] = st
        RADIO_ST["flash"] = 220
    fl = RADIO_ST["flash"]
    RADIO_ST["flash"] = max(0, fl - 1)
    name, song = RADIO_NAMES.get(audio.STATIONS[st][-1], ("RADIO", ""))
    if audio.STATIONS[st][-1] == "music":
        song = THEME.get("dark_song", song)                  # DARK.FM plays a different song in each level
    touch = TOUCH["on"]
    idle = 175 if touch else 120
    alpha = 255 if fl > 40 else idle + int((255 - idle) * fl / 40.0)
    w_, h_ = (214, 46) if touch else (200, 38)
    x_ = W // 2 - w_ // 2 if touch else W - w_ - 12
    y_ = 40 if touch else H - h_ - 8                       # on a phone the bottom corners belong to the buttons
    RADIO_RECT[0] = pygame.Rect(x_, y_, w_, h_).inflate(12, 12) if touch else pygame.Rect(x_, y_, w_, h_)
    pan = pygame.Surface((w_, h_), pygame.SRCALPHA)
    pygame.draw.rect(pan, (18, 12, 8, 215), (0, 0, w_, h_), border_radius=6)
    pygame.draw.rect(pan, (230, 190, 50, 255), (0, 0, w_, h_), 2, border_radius=6)
    # knob (turns to the new station)
    RADIO_ST["ang"] += (st * 1.6 - RADIO_ST["ang"]) * 0.18
    kx, ky, kr = 17, h_ // 2, 11 if not touch else 13
    pygame.draw.circle(pan, (70, 54, 30), (kx, ky), kr)
    pygame.draw.circle(pan, (230, 190, 50), (kx, ky), kr, 2)
    a_ = RADIO_ST["ang"] - 0.8
    pygame.draw.line(pan, (255, 236, 150), (kx, ky), (kx + int(math.sin(a_) * (kr - 2)), ky - int(math.cos(a_) * (kr - 2))), 2)
    # display with the station name and the scrolling track
    dx, dw = 36, w_ - 36 - (40 if touch else 34)
    dh = h_ - 10
    disp = pygame.Rect(dx, 5, dw, dh)
    pygame.draw.rect(pan, (6, 10, 6, 255), disp, border_radius=3)
    pygame.draw.rect(pan, (90, 70, 24, 255), disp, 1, border_radius=3)
    _rtext(pan, name, (255, 176, 40), dx + 5, 6)
    tw_ = font.size(song)[0]
    inner = dw - 12
    if tw_ <= inner:
        _rtext(pan, song, (190, 140, 60), dx + 6, 6 + (dh - 2) // 2)
    else:
        RADIO_ST["scroll"] = (RADIO_ST["scroll"] + 0.7) % (tw_ + 30)
        clip = pan.subsurface(pygame.Rect(dx + 4, 6 + (dh - 2) // 2, inner + 4, 17)).copy()
        clip.fill((0, 0, 0, 0))
        for off in (0, tw_ + 30):
            clip.blit(font.render(song, True, (190, 140, 60)), (2 - RADIO_ST["scroll"] + off, 0))
        pan.blit(clip, (dx + 4, 6 + (dh - 2) // 2))
    # the "next" button on the right
    bx = w_ - (36 if touch else 30)
    br = pygame.Rect(bx, 6, (30 if touch else 24), h_ - 12)
    pulse = 0.5 + 0.5 * math.sin(frame * 0.12)
    pygame.draw.rect(pan, (230, 190, 50, 255) if fl > 0 else (120, 92, 30, 255), br, border_radius=5)
    lab = ">" if touch else "R"
    sf = font_mid.render(lab, True, (30, 18, 6))
    pan.blit(sf, (br.centerx - sf.get_width() // 2, br.centery - sf.get_height() // 2))
    for k in range(len(audio.STATIONS)):                                  # station dots
        pygame.draw.circle(pan, (255, 176, 40) if k == st else (80, 60, 28), (br.centerx - 4 + k * 8 - (len(audio.STATIONS) - 1) * 4 + 4, h_ - 5), 2)
    pan.set_alpha(alpha)
    screen.blit(pan, (x_, y_))


def draw_overlay(run, frame):
    if run.state == "title":
        pass                                              # the main menu is drawn by draw_menu
    elif run.state == "countdown":
        draw_start_crow(run)
        n = (run.cd - 41) // 50 + 1
        text(str(max(1, n)), font_big, (240, 200, 70), W // 2, H // 2 - 100, "center")
    elif run.state == "race" and run.go > 0:
        draw_start_crow(run)
        text("GO!", font_big, (120, 240, 90), W // 2, H // 2 - 100, "center", min(255, run.go * 8))
    elif run.state == "over" and run.over_frames > 40:
        if draw_finish_score(run):
            return
        dim(170)
        text(run.over_reason, font_big, (240, 80, 50), W // 2, H // 2 - 80, "center")
        text(f"REACHED  {run.pos / 1000:.1f} KM OF {LEVEL_LEN / 1000:.1f}     HITS  {run.hits}", font_mid,
             (240, 200, 70), W // 2, H // 2 - 22, "center")
        draw_end_buttons()
    elif run.state == "finish" and run.finish_frames > 60:
        if draw_finish_score(run):
            return
        dim(170)
        text("FINISH", font_big, (230, 190, 50), W // 2, H // 2 - 80, "center")
        text(f"TIME  {fmt_time(run.finish_time)}     HITS  {run.hits}     LEFT  {int(max(0, run.time_left()))}s", font_mid, (240, 200, 70), W // 2, H // 2 - 22, "center")
        best = RECORD["best"]
        tag = "  NEW BEST!" if run.new_best else ""
        if best is not None:
            text(f"BEST  {fmt_time(best)}{tag}", font, (190, 140, 60), W // 2, H // 2 + 8, "center")
        draw_end_buttons()


# ---- settings (saved next to the game)
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "settings.json")
SET = {"car": 0, "pixel": False, "music": True, "sfx": True, "full": False, "level": 1, "vm": 8, "ve": 4, "vf": 6, "mixv": 2, "radio": 0, "name": "", "rules_seen": []}      # vm / ve / vf: music, engine, effects volume 0..10. The defaults (8 / 4 / 6) ARE the balanced mix: music loudest, effects in the middle, engine quietest


def _web_store():
    """browser build: settings live in the visitor's own browser (never in a file shipped with the game)"""
    try:
        import platform as _pf
        return _pf.window.localStorage
    except Exception:
        return None


def load_settings():
    try:
        if sys.platform == "emscripten":
            st = _web_store()
            raw = st.getItem("rv_settings") if st is not None else None
            d = json.loads(str(raw)) if raw else {}
        else:
            with open(SETTINGS_FILE) as f:
                d = json.load(f)
        for k in SET:
            if k in d and type(d[k]) == type(SET[k]):
                SET[k] = d[k]
        if d.get("mixv") != 2:                                  # settings saved before the balanced mix: take the new volume defaults
            SET.update(vm=8, ve=4, vf=6, mixv=2)
    except Exception:
        pass


def set_fullscreen(on):
    try:
        cur = bool(pygame.display.get_surface().get_flags() & pygame.FULLSCREEN)
        if cur != on:
            pygame.display.toggle_fullscreen()
        SET["full"] = bool(pygame.display.get_surface().get_flags() & pygame.FULLSCREEN)
    except Exception:
        SET["full"] = False


def save_settings():
    try:
        if sys.platform == "emscripten":
            st = _web_store()
            if st is not None:
                st.setItem("rv_settings", json.dumps(SET))
            return
        with open(SETTINGS_FILE, "w") as f:
            json.dump(SET, f)
    except Exception:
        pass


def post_filter():
    """'pixelated' mode: chunky 2x pixels over the whole picture, like a 90s console"""
    if SET["pixel"]:
        small = pygame.transform.scale(screen, (W // 2, H // 2))
        pygame.transform.scale(small, (W, H), screen)


_FOG = {}
_FOGBANK = {}


def fog_k(pos):
    """0..1: a thick fog that rolls in over the first half of the haunted hill, thickens for a long while, then slowly thins out"""
    zs = list(THEME.get("fog_bumps", ()))                     # a level can have several banks of fog
    if THEME.get("fog_bump"):
        zs.append(THEME["fog_bump"])
    best = 0.0
    for z in zs:
        if z[0] < pos < z[1]:
            u = (pos - z[0]) / float(z[1] - z[0])
            best = max(best, math.sin(u * math.pi) ** 0.8)
    return best


def draw_fogbank(run):
    k = fog_k(run.pos)
    fc = THEME.get("fog")
    if k <= 0.01 or not fc:
        return
    hy = view.hy
    if hy not in _FOGBANK:
        sf = pygame.Surface((W, H), pygame.SRCALPHA)
        for y in range(H):
            if y < hy:
                a = 235 * max(0.0, 1.0 - (hy - y) / 80.0)
            else:
                a = 235 * max(0.0, 1.0 - (y - hy) / (0.8 * (H - hy))) ** 1.5
            if a > 0:
                pygame.draw.line(sf, (*fc, int(a)), (0, y), (W, y))
        _FOGBANK.clear()
        _FOGBANK[hy] = sf
    sf = _FOGBANK[hy]
    sf.set_alpha(int(255 * min(1.0, k * 1.1)))
    screen.blit(sf, (0, 0))


LIGHTN = {"next": 0, "t": 0}


def draw_fog():
    """a bank of fog sitting on the horizon: the far end of the road simply dissolves into it"""
    fc = THEME.get("fog")
    if not fc or THEME.get("fog_banks_only"):
        return
    hy = view.hy
    if hy not in _FOG:
        hgt = 190
        sf = pygame.Surface((W, hgt), pygame.SRCALPHA)
        for i in range(hgt):
            if i < 34:
                a = int(225 * (i / 34.0) ** 0.8)
            else:
                a = int(225 * max(0.0, 1.0 - (i - 34) / (hgt - 34.0)) ** 1.6)
            pygame.draw.line(sf, (*fc, a), (0, i), (W, i))
        _FOG.clear()
        _FOG[hy] = sf
    screen.blit(_FOG[hy], (0, hy - 34))


def lightning(run):
    if not THEME.get("lightning") or run.state not in ("race", "countdown"):
        return 0
    now = pygame.time.get_ticks()
    raining = mud_k(run.pos) > 0.3
    if LIGHTN["next"] == 0:
        LIGHTN["next"] = now + random.randint(6000, 12000)
    if LIGHTN.get("thunder") and now > LIGHTN["thunder"]:
        LIGHTN["thunder"] = 0
        if AUDIO is not None:
            getattr(AUDIO, "thunder", lambda: None)()
    if LIGHTN["t"] <= 0 and now > LIGHTN["next"]:
        LIGHTN["t"] = 12 if raining else 10
        LIGHTN["next"] = now + (random.randint(2200, 5200) if raining else random.randint(9000, 20000))
        LIGHTN["thunder"] = now + random.randint(300, 1800)
    if LIGHTN["t"] > 0:
        LIGHTN["t"] -= 1
        return LIGHTN["t"]
    return 0


_BLACK = []


def _blackout_surface():
    if not _BLACK:
        sf = pygame.Surface((W, H), pygame.SRCALPHA)
        sf.fill((0, 0, 8, 255))
        cx, cy = W // 2, int(H * 0.72)
        for r in range(300, 0, -6):
            pygame.draw.ellipse(sf, (0, 0, 8, int(255 * (r / 300.0) ** 1.6)), (cx - r, cy - int(r * 0.7), 2 * r, int(r * 1.4)))
        _BLACK.append(sf)
    return _BLACK[0]


_FROST = []


def _frost_surface():
    if not _FROST:
        sf = pygame.Surface((W, H), pygame.SRCALPHA)
        rr = random.Random(3)
        for i in range(140):
            side = rr.choice("lrtb")
            d = rr.random() ** 2
            x = int(d * W * 0.22) if side == "l" else (W - int(d * W * 0.22) if side == "r" else rr.randint(0, W))
            y = int(d * H * 0.22) if side == "t" else (H - int(d * H * 0.22) if side == "b" else rr.randint(0, H))
            r_ = rr.randint(10, 46)
            pygame.draw.circle(sf, (200, 230, 255, rr.randint(40, 110)), (x, y), r_)
            for k in range(5):
                a = rr.random() * 6.283
                pygame.draw.line(sf, (235, 248, 255, 150), (x, y), (x + math.cos(a) * r_ * 1.6, y + math.sin(a) * r_ * 1.6), 1)
        _FROST.append(sf)
    return _FROST[0]


RAIN = [(random.random(), random.random(), random.uniform(0.6, 1.0)) for _ in range(150)]


_RAIN_DARK = {}


def draw_rain(run):
    k = mud_k(run.pos)
    if k <= 0.05:
        return
    n = int(len(RAIN) * k)
    t = pygame.time.get_ticks() / 1000.0
    slant = 14 + run.curve * 10
    for (rx, ry, rs) in RAIN[:n]:
        x = (rx * (W + 80) - t * 90 * rs) % (W + 80) - 40
        y = (ry * H + t * 900 * rs) % H
        pygame.draw.line(screen, (150, 160, 200), (x, y), (x - slant * 0.6, y + 22 * rs), 1)
    q = int(k * 8)
    if q not in _RAIN_DARK:
        d_ = pygame.Surface((W, H))
        d_.fill((int(18 * q / 8), int(16 * q / 8), int(24 * q / 8)))
        _RAIN_DARK[q] = d_
    screen.blit(_RAIN_DARK[q], (0, 0), special_flags=pygame.BLEND_RGB_SUB)


_LEAVES = [(random.Random(31 + i).random(), random.Random(77 + i).random(), 0.5 + random.Random(5 + i).random(), i % 4) for i in range(26)]


def draw_leaves(run):
    """autumn leaves drifting across the picture"""
    if not THEME.get("leaves"):
        return
    t = pygame.time.get_ticks() / 1000.0
    for rx, ry, rs, ci in _LEAVES:
        x = (rx * (W + 60) - t * (22 + 30 * rs) - run.speed * 90.0 * rs) % (W + 60) - 30
        yv = (ry * H + t * (38 + 30 * rs)) % H + math.sin(t * 2.2 + rx * 9.0) * 8
        c = AUTUMN[ci]
        pygame.draw.polygon(screen, c, [(x, yv), (x + 5 * rs, yv - 2), (x + 8 * rs, yv + 1), (x + 4 * rs, yv + 3)])


def draw(run, keys, frame):
    CUR_POS[0] = run.pos
    view.hy = int(HORIZON_BASE - run.hill * 10)
    view.vcx = int(W // 2 + run.curve * 110)
    view.pos = run.pos
    draw_sky(view.hy, run.curve)
    draw_road(run)
    draw_scenery(run)
    draw_traffic(run)
    draw_vision(run)
    draw_fogbank(run)
    draw_fog()
    draw_car(run, run.state == "race" and keys[pygame.K_DOWN])
    if run.crash > 30:
        flash = pygame.Surface((W, H), pygame.SRCALPHA)
        flash.fill((255, 60, 30, (run.crash - 30) * 7))
        screen.blit(flash, (0, 0))
    apply_time_of_day(run)
    draw_rain(run)
    draw_leaves(run)
    if run.trip or run.untrip > 0:
        draw_trip_fx(run)
    lt = lightning(run)
    if lt and lt % 4 != 0:                                   # a bolt somewhere behind the hills
        screen.fill((120, 120, 170) if lt > 6 else (60, 60, 96), special_flags=pygame.BLEND_RGB_ADD)
    if run.spook > 0:                                        # a ghost went through the car
        if (run.spook // 3) % 2 == 0:
            screen.fill((26, 48, 96), special_flags=pygame.BLEND_RGB_ADD)
        for _ in range(3):
            ty = random.randint(0, H - 40)
            th = random.randint(8, 36)
            strip = screen.subsurface((0, ty, W, th)).copy()
            screen.blit(strip, (random.randint(-14, 14), ty))
    if run.fx.get("blackout"):                               # headlights out: only a small pool of light in front of the car
        a_ = min(1.0, run.fx["blackout"] / 40.0)
        bl = _blackout_surface()
        bl.set_alpha(int(240 * a_))
        screen.blit(bl, (0, 0))
    if run.gut > 0:                                          # pumpkin guts splattered on the windscreen
        gk = min(1.0, run.gut / 50.0)
        rr = random.Random(23)
        for i in range(4):
            cx_, cy_ = rr.randint(int(W * 0.15), int(W * 0.85)), rr.randint(int(H * 0.1), int(H * 0.5))
            sw_ = rr.randint(170, 300)
            gt = pygame.transform.scale(_guts_tex(i, 150, 112), (sw_, int(sw_ * 0.75)))
            gt.set_alpha(int(225 * gk))
            slide = int((1.0 - gk) * 70)
            screen.blit(gt, (cx_ - sw_ // 2, cy_ - sw_ // 3 + slide))
            if slide > 6:                                                # it runs down the glass
                pygame.draw.line(screen, (226, 128, 20), (cx_, cy_ + sw_ // 4), (cx_ + rr.randint(-6, 6), cy_ + sw_ // 4 + slide), 4)
    if run.web > 0:                                          # a web plastered over the windscreen: you can hardly see for a moment
        wk = min(1.0, run.web / 40.0)
        film = pygame.Surface((W, H), pygame.SRCALPHA)
        film.fill((214, 220, 232, int(175 * wk)))
        rr = random.Random(11)
        for i in range(60):
            x0_, y0_ = rr.randint(0, W), rr.randint(0, H)
            pygame.draw.line(film, (255, 255, 255, int(255 * wk)), (x0_, y0_), (x0_ + rr.randint(-220, 220), y0_ + rr.randint(-220, 220)), 2)
        screen.blit(film, (0, 0))
    if run.spider > 0:                                       # a spider sitting on the windscreen
        sp = sprites.get("spider", (run.frames // 8) % 2)
        bw = int(W * 0.5)
        bh = int(bw * sp.get_height() / sp.get_width())
        im = pygame.transform.scale(sp, (bw, bh))
        sx = W // 2 - bw // 2 + int(math.sin(run.frames * 0.05) * 60)
        sy = int(H * 0.20 + math.sin(run.frames * 0.11) * 14)
        pygame.draw.line(screen, (210, 214, 226), (sx + bw // 2, 0), (sx + bw // 2, sy + 6), 2)
        screen.blit(im, (sx, sy))
        text("SPIDER ON THE GLASS - WIGGLE THE WHEEL!  (%d/4)" % int(run.shake_n), font_mid, (255, 220, 120), W // 2, 232, "center")
    if run.sparkle > 0:                                      # green sparkles: the good witch's magic
        rr = random.Random(run.frames // 3)
        for i in range(40):
            sx_, sy_ = rr.randint(0, W), rr.randint(0, H)
            c_ = (120 + rr.randint(0, 135), 255, 140 + rr.randint(0, 100))
            r_ = rr.randint(2, 5)
            pygame.draw.line(screen, c_, (sx_ - r_, sy_), (sx_ + r_, sy_), 1)
            pygame.draw.line(screen, c_, (sx_, sy_ - r_), (sx_, sy_ + r_), 1)
        gl = pygame.Surface((W, H))
        gl.fill((0, int(40 * run.sparkle / 100.0), int(10 * run.sparkle / 100.0)))
        screen.blit(gl, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    if run.chill > 0:                                        # frost creeping in from the edges of the windscreen
        a_ = min(1.0, run.chill / 50.0)
        fr = _frost_surface()
        fr.set_alpha(int(210 * a_))
        screen.blit(fr, (0, 0))
    if run.bat > 0:                                          # a bat slaps into the windscreen and flaps off
        k = run.bat
        bsp = sprites.get("bat", (k // 3) % 2)
        bw = int(W * (0.46 - 0.18 * (1 - k / 110.0)))
        bh = int(bw * bsp.get_height() / bsp.get_width())
        im = pygame.transform.scale(bsp, (bw, bh))
        im.set_alpha(min(255, k * 8))
        screen.blit(im, (W // 2 - bw // 2 + int(math.sin(k * 0.5) * 24), int(H * 0.30) - int((110 - k) * 1.6)))
    if run.crash > 20:
        frame_copy = screen.copy()
        screen.blit(frame_copy, (random.randint(-6, 6), random.randint(-4, 4)))
    elif run.shake_t > 0:                                                 # something heavy landed beside the road
        a_ = max(1, int(run.shake_amp * run.shake_t / 24.0))
        frame_copy = screen.copy()
        screen.blit(frame_copy, (random.randint(-a_, a_), random.randint(-(a_ // 2) - 1, a_ // 2 + 1)))
    post_filter()
    draw_hud(run, keys)
    draw_overlay(run, frame)
    draw_radio(run, frame)


# ------------------------------------------------------------------ levels
from .levels import LEVELS
DEV = (bool(os.environ.get("RV_DEV")) and sys.platform != "emscripten") or scores.local_web() or scores.preview()        # developer mode (run_dev.bat): locked levels playable, no scores sent


def build_world(level):
    """(re)build everything that belongs to one level: road, scenery, hazards, crossings, hills"""
    global LEVEL, LVL_SEED, THEME, ZONES, EVENT_CYCLE, SECS, LEVEL_LEN, SLIDE, SEC_STARTS, INTERSECTIONS, FORKS, WIDES
    global _inter_signs, OBJS, OBJ_S, HAZ, HAZ_S, MOVERS, RAILS, DEER_ZONES, ELEV
    L = LEVELS[level]
    LEVEL, LVL_SEED, THEME, ZONES, EVENT_CYCLE = level, L["seed"], L["theme"], L["zones"], L["events"]
    audio.use_stations(THEME.get("stations"))                          # the radio dial of this level
    if AUDIO is not None:
        try:
            AUDIO.station %= len(audio.STATIONS)
        except Exception:
            pass
    del CROSSWALKS[:]
    SECS, LEVEL_LEN, SLIDE = build_level()
    CHECKPOINTS[:] = [LEVEL_TARGET * k_ / 6.0 for k_ in range(1, 6)]
    if THEME.get("cp_after_slide") and SLIDE:                 # one more checkpoint just after the long descent
        CHECKPOINTS.append(SLIDE[1] + 260.0)
        CHECKPOINTS.sort()
    SEC_STARTS = [sec[0] for sec in SECS]
    INTERSECTIONS = build_intersections()
    FORKS = build_forks()
    WIDES = build_wides()
    _inter_signs = []
    for i_, s_ in enumerate(INTERSECTIONS):
        for back in (320, 130):
            _inter_signs.append(dict(s=s_ - back, side=1 if i_ % 2 else -1, kind="sign", dir=0, off=12, k=1.0, glyph="cross"))
    objs = ([o for o in build_scenery() if not near_intersection(o["s"], STREET_HALF + 14)] + _inter_signs
            + build_hazards() + build_fork_events())
    for cp in CHECKPOINTS:
        objs.append(dict(s=cp, side=0, kind="checkpoint", off=0, k=1.0))
    pads_ = [o["s"] for o in objs if o.get("hz") and o["kind"] == "pad"]
    objs = [o for o in objs if not (o["kind"] in ("gravestone", "pumpkin", "deadtree", "pine", "rock", "lamp", "crypt", "sign", "house") and
                                    o.get("side") == 1 and not o.get("glyph") and any(ps - 280 < o["s"] < ps + 70 for ps in pads_))]
    rails = build_rails()
    rail_s = [o["s"] for o in rails if o["kind"] == "rail"]
    objs = [o for o in objs if not ((o.get("hz") or o["kind"] in ("overpass", "gas", "billboard") or
                                     (o["kind"] == "sign" and o.get("glyph")))
                                    and any(r - 560 < o["s"] < r + 160 for r in rail_s))]
    objs += rails
    objs.sort(key=lambda o: o["s"])
    if TUNNEL:
        objs = [o for o in objs if o.get("hz") or o["kind"] == "checkpoint" or not (TUNNEL[0] - 520 < o["s"] < TUNNEL[1] + 40)]
    emv_ = [(o["s"], 1 if o["lx"] > 0 else -1) for o in objs if o.get("hz") and ((o["kind"] == "emv" and o["v"] in ("amb", "pol")) or o["kind"] == "druid")]
    objs = [o for o in objs if o.get("hz") or o["kind"] not in ("pine", "maple", "deadtree", "rock", "lamp", "sign") or o.get("glyph")
            or not any(sd_ == o.get("side") and es_ - 30 < o["s"] < es_ + 45 for es_, sd_ in emv_)]       # keep a tree from hiding the scene
    OBJS = objs
    OBJ_S = [o["s"] for o in OBJS]
    HAZ = [o for o in OBJS if o.get("hz")]
    HAZ_S = [o["s"] for o in HAZ]
    MOVERS = [o for o in HAZ if o["kind"] in ("zombie", "bat", "witch", "spider", "web", "thrower", "pshot")]
    for th_ in HAZ:                                      # each lunatic gets his own pumpkins
        if th_["kind"] == "thrower":
            th_["shots"] = [q for q in HAZ if q["kind"] == "pshot" and q["ph0"] == "idle" and q["s"] == th_["s"] and q["lx"] == th_["lx"]]
    RAILS = [o for o in OBJS if o["kind"] == "rail"]
    DEER_ZONES = [(o["s"] - 380.0, o["s"] + 120.0) for o in HAZ if o["kind"] in ("deer", "zombie", "witch", "ghoul", "boar", "emv")]
    ELEV = _build_elevation()
    RECORD["best"] = BESTS.get(level)
    del LIGHTS[:]


# ------------------------------------------------------------------ menus
# stars 1-5 for top speed / pull / grip. 4 stars is the standard feel; every star above or below changes it by 4 %.
CARS = [dict(name="IMPROZA", desc="all-wheel-drive rally special (the name is totally legit)", top=4, pull=4, grip=4, brake=3),
        dict(name="YUGGO 45", desc="mustard hatchback. mattress tied to the roof, no questions", top=2, pull=3, grip=3, brake=2, clock=0.97),
        dict(name="ZAPPO", desc="tiny electric egg. still plugged in. hates hills", top=2, pull=5, grip=4, brake=3, half=car_sprite.EV_HALF, top_row=5, clock=0.91),
        dict(name="VALVO", desc="built like a fridge, stops like a wall. very sorry about your cat", top=3, pull=2, grip=4, brake=5, armor=0.75, half=car_sprite.V_HALF, clock=0.97),
        dict(name="CORPSE WAGON", desc="a casket on wheels. the lid will not survive. neither will the passenger", top=2, pull=1, grip=2, brake=1, lid=True, half=car_sprite.C_HALF, clock=1.05)]


def armor():
    """damage multiplier of the chosen car (a sturdy car takes less)"""
    return CARS[SET["car"] % len(CARS)].get("armor", 1.0)


_BRAKE_K = {1: 0.6, 2: 0.85, 3: 1.0, 4: 1.3, 5: 1.6}


def brake_k():
    """braking power of the chosen car: 1.0 at three stars"""
    return _BRAKE_K.get(CARS[SET["car"] % len(CARS)].get("brake", 3), 1.0)


LID_OFF_DMG = 24                # a single hit that does this much damage (in car-armour terms) knocks the lid off the corpse wagon


def add_damage(run, amount):
    """damage after the car's armour; a hard enough hit throws the lid off the corpse wagon"""
    d = amount * armor()
    run.damage = min(100.0, run.damage + d)
    if CARS[SET["car"] % len(CARS)].get("lid") and d >= LID_OFF_DMG and not run.lid_off:
        run.lid_off = True
        run.legv += 1.4
        run.bonus_msg = "THERE GOES THE LID!"
        run.bonus_t = 110
    elif run.lid_off:
        run.legv += random.choice((-1, 1)) * min(1.0, d / 20.0)


def abs_k():
    """a five-star car has ABS: mud and slippery road hurt its brakes only half as much"""
    return 0.5 if CARS[SET["car"] % len(CARS)].get("brake", 3) >= 5 else 1.0


def car_clock():
    """slower cars get a bit more clock (start time and checkpoint bonus) so every car is about as hard to finish"""
    return CARS[SET["car"] % len(CARS)].get("clock", 1.0)


def car_half_px(run):
    """half the car's width in screen pixels (small cars have a smaller hitbox)"""
    return CARS[SET["car"] % len(CARS)].get("half", 18.5) * run.car_scale


def car_mod(stat):
    """multiplier for the chosen car: 1.0 at four stars"""
    c = CARS[SET["car"] % len(CARS)]
    return 1.0 + (c[stat] - 4) * 0.04
TUTORIAL = [                                       # the basics page: the same in every level. Each level adds its own page (RULES in game/levels/<name>.py)
    ("DRIVING", [
        ("car", (230, 190, 50), "UP / DOWN: gas, brake    LEFT / RIGHT: steer", "Touch screens get on-screen buttons."),
        ("none", (230, 190, 50), "H: HORN    R: RADIO    P: PAUSE", "Esc also pauses. F toggles fullscreen."),
        ("check", (120, 230, 110), "CHECKPOINTS   added time and some repairs", "Reach each one before the clock hits zero."),
        ("none", (240, 90, 70), "100% DAMAGE = WRECKED   crashes cost seconds", "The harder the hit, the more it costs.")]),
]


def rulebook(n):
    """the pages of a level's rulebook: the basics, then that level's own"""
    L = LEVELS.get(n) if n else None
    own = list(L.get("rules", ())) if L else []
    if not own:
        own = [("RULES UNKNOWN", [("none", (190, 150, 255), "NOBODY HAS DRIVEN THIS ROAD AND LIVED", "Find out for yourself.")])]
    return list(TUTORIAL) + own


def open_rules(n, back):
    """show a level's rulebook; back = the screen to return to afterwards ('race' = we are on the way to the countdown)"""
    MENU.update(screen="help", page=0, pages=rulebook(n), rb=back, rlv=n)


def rules_done(back):
    """leave the rulebook. Returns 'race' when it was the pre-race one"""
    if back == "race":
        if MENU.get("rlv") not in SET["rules_seen"]:
            SET["rules_seen"] = list(SET["rules_seen"]) + [MENU.get("rlv")]
        save_settings()
        return "race"
    MENU.update(screen=back, sel=0, page=0)
    return None


_ICONS = {}


def _icon(name, size=60):
    """a small picture for the tutorial, scaled to fit a size x size box"""
    if name in _ICONS:
        return _ICONS[name]
    s = None
    try:
        if name == "car":
            s = car_sprite.get(False, 2, SET["car"])
        elif name == "cat":
            s = sprites.get("cat", 2)
        elif name == "costume":
            s = sprites.get("costume", 0, look=0)
        elif name == "traffic":
            s = sprites.get("traffic", 0, kind="sedan", color=(46, 96, 168))
        elif name == "gravestone":
            s = sprites.get("gravestone", 0)
        elif name == "train":
            s = pygame.Surface((64, 40), pygame.SRCALPHA)
            pygame.draw.rect(s, (24, 26, 28), (4, 8, 40, 26))
            pygame.draw.rect(s, (30, 32, 34), (40, 14, 20, 20))
            pygame.draw.rect(s, (255, 150, 30), (8, 12, 30, 8))
            pygame.draw.polygon(s, (255, 90, 20), [(10, 12), (18, 0), (24, 10), (30, 2), (36, 12)])
            pygame.draw.circle(s, (12, 12, 14), (14, 36), 4)
            pygame.draw.circle(s, (12, 12, 14), (34, 36), 4)
            pygame.draw.circle(s, (12, 12, 14), (52, 36), 4)
        elif name == "logtruck":
            s = sprites.get("traffic", 0, kind="logtruck", color=(120, 90, 50))
        elif name.startswith("sign:"):                          # a road warning sign, as the game draws it
            global screen
            real, screen = screen, pygame.Surface((100, 190), pygame.SRCALPHA)
            try:
                draw_glyph_sign(50, 186, 0.85, {"glyph": name[5:]})
                s = screen.subsurface(screen.get_bounding_rect()).copy()
            finally:
                screen = real
        elif name == "check":
            s = pygame.Surface((64, 40), pygame.SRCALPHA)
            for i in range(0, 64, 8):
                pygame.draw.rect(s, (250, 220, 60) if (i // 8) % 2 == 0 else (30, 24, 10), (i, 4, 8, 12))
            pygame.draw.rect(s, (60, 50, 40), (4, 4, 4, 34))
            pygame.draw.rect(s, (60, 50, 40), (56, 4, 4, 34))
        elif name != "none":
            s = sprites.get(name, 0)
    except Exception:
        s = None
    if s is not None:
        k = min(size / float(s.get_width()), size / float(s.get_height()))
        s = pygame.transform.scale(s, (max(1, int(s.get_width() * k)), max(1, int(s.get_height() * k))))
    _ICONS[name] = s
    return s


MENU = {"screen": "main", "sel": 0, "back": "main", "page": 0}
BUTTONS = []                         # tap targets of the menu on screen: (rect, key to press, list index or None)
TOUCH = {"on": False, "fingers": {}}   # on = a touch screen has been used: show the on-screen driving buttons


def button(rect, key, sel=None, label=None, hot=False, big=False, red=False):
    """register a tap target and draw it as a button (red = the blood-red one for the cult)"""
    r = pygame.Rect(rect)
    BUTTONS.append((r, key, sel))
    if label is not None:
        if red:
            fill, edge, ink = ((96, 14, 22), (255, 74, 62), (255, 130, 112)) if hot else ((48, 10, 16), (150, 30, 38), (206, 62, 58))
        else:
            fill, edge, ink = ((70, 46, 18), (255, 210, 70), (255, 226, 100)) if hot else ((36, 24, 14), (120, 84, 40), (190, 140, 60))
        pygame.draw.rect(screen, fill, r, border_radius=8)
        pygame.draw.rect(screen, edge, r, 2, border_radius=8)
        text(label, font_big if big else font_mid, ink, r.centerx, r.centery - (22 if big else 11), "center")
    return r


def tap_hint(key_text, touch_text):
    return touch_text if TOUCH["on"] else key_text


SLIDERS = {"MUSIC": "vm", "ENGINE": "ve", "EFFECTS": "vf"}


KULT = "VANDAL RACING CLUB"                     # the members' area (placeholder until the card site is connected)


def _score_levels():
    """the races that have boards to look at: every level that can be played"""
    return [n for n in sorted(LEVELS) if level_playable(n)]


def menu_items():
    sc = MENU["screen"]
    if sc == "main":
        its = ["START"] + (["SCORES"] if scores.enabled() else []) + ["OPTIONS"]
        its = its + [KULT]
        return its if sys.platform == "emscripten" else its + ["QUIT"]       # a browser tab cannot quit itself
    if sc == "pause":
        return ["RESUME", "RULEBOOK", "OPTIONS", "QUIT TO MENU"]
    if sc == "options":
        return ["HOW TO PLAY", "WINDOW:  " + ("FULLSCREEN" if SET["full"] else "WINDOWED"), "SCREEN:  " + ("PIXELATED" if SET["pixel"] else "LESS PIXELATED"),
                "MUSIC", "ENGINE", "EFFECTS", "BACK"]
    return []


_TBG = {}
_TBG_MOON = (520, 170)                  # (the loading page in web.tmpl is rendered with the moon further out to the right)


def _title_bg():
    """the title screen's backdrop, drawn once: a black night, a dull red moon, ridges and dead pines, and the empty road running
    into the glow of the fire"""
    if "s" in _TBG:
        return _TBG["s"]
    rng = random.Random(11)
    sf = pygame.Surface((W, H))
    hz = 330
    for y in range(H):
        k = min(1.0, y / float(hz))
        pygame.draw.line(sf, (int(8 + 34 * k * k), int(5 + 8 * k * k), int(10 + 10 * k)), (0, y), (W, y))
    for _ in range(90):                                                       # stars
        c = rng.randint(50, 110)
        sf.set_at((rng.randint(0, W - 1), rng.randint(0, hz - 60)), (c, c - 10, c - 20))
    mx, my = _TBG_MOON                                                        # a dull red moon with a halo
    for r in range(70, 36, -3):
        k = (70 - r) / 34.0
        pygame.draw.circle(sf, (int(16 + 22 * k), int(8 + 4 * k), int(14 + 4 * k)), (mx, my), r)
    pygame.draw.circle(sf, (150, 52, 40), (mx, my), 34)
    pygame.draw.circle(sf, (176, 70, 48), (mx - 6, my - 6), 26)
    for cx_, cy_, r_ in ((mx + 10, my + 8, 6), (mx - 12, my + 12, 4), (mx + 4, my - 14, 3)):
        pygame.draw.circle(sf, (132, 44, 36), (cx_, cy_), r_)
    for layer, (base, amp, col) in enumerate(((hz - 36, 34, (34, 15, 21)), (hz - 14, 22, (22, 10, 15)))):   # ridges
        pts = [(0, hz + 2)]
        ph = rng.uniform(0, 6)
        for x in range(0, W + 20, 20):
            pts.append((x, base - amp * (0.5 + 0.5 * math.sin(x / 90.0 + ph + layer)) - rng.randint(0, 8)))
        pts.append((W, hz + 2))
        pygame.draw.polygon(sf, col, pts)
    pygame.draw.rect(sf, (10, 6, 9), (0, hz, W, H - hz))                      # the ground
    vx = 350                                                                  # the road into the distance
    pygame.draw.polygon(sf, (30, 18, 18), [(vx - 3, hz), (vx + 3, hz), (vx + 230, H), (vx - 230, H)])
    for i in range(9):                                                        # centre line dashes
        t0, t1 = (i / 9.0) ** 2, ((i + 0.45) / 9.0) ** 2
        y0, y1 = hz + (H - hz) * t0, hz + (H - hz) * t1
        pygame.draw.polygon(sf, (74, 52, 24), [(vx - 1 - 4 * t0, y0), (vx + 1 + 4 * t0, y0), (vx + 1 + 4 * t1, y1), (vx - 1 - 4 * t1, y1)])
    for side in (-1, 1):                                                      # dead pines along the road
        for i in range(7):
            t = ((i + 0.6) / 7.0) ** 1.8
            y = hz + (H - hz) * t
            x = vx + side * (14 + 330 * t) + rng.randint(-6, 6)
            h = 18 + 140 * t
            wd = max(1, int(3 + 6 * t))
            pygame.draw.rect(sf, (6, 4, 7), (x - wd // 2, y - h, wd, h))
            for j in range(5):
                by = y - h + h * (0.12 + 0.16 * j)
                bl = (h * 0.28) * (1.0 - 0.1 * j)
                pygame.draw.polygon(sf, (6, 4, 7), [(x, by), (x + side * bl, by + bl * 0.5), (x + side * bl * 0.8, by + bl * 0.5 + 2), (x, by + 5)])
                pygame.draw.polygon(sf, (6, 4, 7), [(x, by), (x - side * bl * 0.8, by + bl * 0.45), (x - side * bl * 0.6, by + bl * 0.45 + 2), (x, by + 5)])
    glow = pygame.Surface((W, 220))                                           # firelight on everything near the bottom
    for y in range(220):
        k = (y / 220.0) ** 2
        pygame.draw.line(glow, (int(90 * k), int(34 * k), int(6 * k)), (0, y), (W, y))
    sf.blit(glow, (0, H - 220), special_flags=pygame.BLEND_RGB_ADD)
    _TBG["s"] = sf
    return sf


def _title_embers(frame):
    """sparks drifting up from the fire"""
    for i in range(34):
        r = (i * 7919 + 13) % 997
        x = (r * 37 + int(math.sin(frame / 50.0 + i) * 14)) % W
        y = H - ((frame * (0.5 + (r % 9) * 0.12) + r * 3) % (H - 150))
        c = 255 - int((H - y) / (H - 150.0) * 180)
        screen.fill((c, int(c * 0.5), int(c * 0.12)), (int(x), int(y), 2, 2))


def _title_fire():
    """doom fire along the bottom of the title screens"""
    tex = _fire_tex()
    fh = 150
    sf = pygame.transform.scale(tex.subsurface((0, 0, _FIRE_W, _FIRE_H - 3)), (W, fh))
    sf.set_alpha(190)
    screen.blit(sf, (0, H - fh))


LV_CARDS = [1, 2, None, None]            # level picker: level numbers, None = a "???" teaser for a level that is still coming
_CARD_IMG = {}


def _card_img(n, w, h):
    key = (n, w, h)
    if key not in _CARD_IMG:
        im = None
        try:
            im = pygame.image.load(os.path.join(os.path.dirname(_FONT_FILE), "card_%d.png" % n)).convert()
            im = pygame.transform.scale(im, (w, h))
        except Exception:
            im = None
        _CARD_IMG[key] = im
    return _CARD_IMG[key]


def level_playable(n):
    L = LEVELS.get(n)
    return L is not None and (DEV or not L.get("locked"))


def _card(n, rect, hot):
    """one card of the level picker: a real in-game frame, a padlock when locked, a question mark when it is still a secret"""
    x, y, w, h = rect
    L = LEVELS.get(n) if n else None
    if L is None:
        pygame.draw.rect(screen, (22, 16, 14), rect)
        rng = random.Random(n or 7)
        for _ in range(60):
            c_ = rng.randint(30, 52)
            pygame.draw.rect(screen, (c_, c_ - 6, c_ - 12), (x + rng.randint(0, w - 4), y + rng.randint(0, h - 4), rng.choice((2, 4, 6)), 2))
        q = font_title.render("?", True, (70, 54, 40))
        screen.blit(q, (x + w // 2 - q.get_width() // 2, y + h // 2 - q.get_height() // 2))
    else:
        im = _card_img(n, w, h)
        if im is not None:
            screen.blit(im, (x, y))
        else:
            pygame.draw.rect(screen, (60, 40, 26), rect)
        if L.get("locked") and not DEV:
            shade = pygame.Surface((w, h))
            shade.fill((6, 4, 10))
            shade.set_alpha(170)
            screen.blit(shade, (x, y))
            cx, cy = x + w // 2, y + h // 2 - 6
            pygame.draw.circle(screen, (200, 160, 60), (cx, cy - 16), 14, 5)
            pygame.draw.rect(screen, (230, 190, 70), (cx - 18, cy - 8, 36, 28), border_radius=4)
            pygame.draw.circle(screen, (60, 40, 10), (cx, cy + 5), 4)
            if w > 300:
                text(L.get("unlock_text", "LOCKED"), font_mid, (255, 214, 90), x + w // 2, y + h - 34, "center")
    pygame.draw.rect(screen, (255, 210, 70) if hot else (96, 70, 36), rect, 3 if hot else 2)
    if L is not None and L.get("new") and (DEV or not L.get("locked")):        # red NEW! tag (set new=True / remove it in the level file)
        bw_, bh_ = (74, 30) if w > 300 else (46, 20)
        br = pygame.Rect(x + w - bw_ - 8, y + 8, bw_, bh_)
        pygame.draw.rect(screen, (214, 36, 30), br, border_radius=6)
        pygame.draw.rect(screen, (255, 214, 190), br, 2, border_radius=6)
        text("NEW!", font_mid if w > 300 else font, (255, 255, 255), br.centerx, br.centery - (11 if w > 300 else 7), "center")


def _draw_levels():
    screen.fill((20, 13, 9))
    for i in range(0, H, 4):                                   # soft warm glow at the bottom
        k = max(0, i - 260) / 240.0
        if k > 0:
            pygame.draw.rect(screen, (int(20 + 40 * k), int(13 + 14 * k), 9), (0, i, W, 4))
    n = len(LV_CARDS)
    ci = max(0, min(n - 1, MENU.get("card", 0)))
    text("PICK LEVEL", font_big, (230, 190, 50), W // 2, 30, "center")
    for off, bw, bh in ((-1, 120, 52), (1, 120, 52)):
        j = ci + off
        if 0 <= j < n:
            bx = 12 if off < 0 else W - 12 - bw
            _card(LV_CARDS[j], (bx, 150, bw, bh), False)
            dimr = pygame.Surface((bw, bh))
            dimr.set_alpha(120)
            screen.blit(dimr, (bx, 150))
            button((bx - 8, 100, bw + 16, 190), pygame.K_LEFT if off < 0 else pygame.K_RIGHT)       # tall target: the arrow itself is tappable too
    num = LV_CARDS[ci]
    L = LEVELS.get(num) if num else None
    _card(num, (W // 2 - 210, 100, 420, 180), True)
    if ci > 0:
        text("<", font_big, (230, 190, 50), 72, 222, "center")
    if ci < n - 1:
        text(">", font_big, (230, 190, 50), W - 72, 222, "center")
    if L is None:
        text("LEVEL %d" % (ci + 1), font, (190, 140, 60), W // 2, 298, "center")
        text("???", font_big, (150, 112, 56), W // 2, 316, "center")
        text("SOMETHING IS COMING", font, (110, 84, 44), W // 2, 366, "center")
    else:
        text("LEVEL %d" % num, font, (190, 140, 60), W // 2, 296, "center")
        level_name(L, W // 2, 314)
        text(L["sub"], font, (190, 140, 60), W // 2, 356, "center")
        if level_playable(num):
            text(L["info"], font, (150, 112, 56), W // 2, 380, "center")
            b = BESTS.get(num)
            text("BEST  " + (fmt_time(b) if b is not None else "--"), font, (200, 160, 70), W // 2, 408, "center")
        else:
            text(L.get("unlock_text", "LOCKED"), font_mid, (255, 214, 90), W // 2, 386, "center")
    for i in range(n):
        pygame.draw.circle(screen, (255, 200, 60) if i == ci else (80, 60, 28), (W // 2 - (n - 1) * 8 + i * 16, 440), 4)
    if num and level_playable(num):
        button((W // 2 - 90, 450, 180, 44), pygame.K_RETURN, label="OK", hot=True)
    button((10, 10, 100, 36), pygame.K_ESCAPE, label="BACK")


_KULT_GLYPHS = {                       # hand-painted letters: strokes in a 1 x 1 box (y down)
    "V": [[(0, 0), (0.5, 1), (1, 0)]],
    "A": [[(0, 1), (0.5, 0), (1, 1)], [(0.2, 0.68), (0.8, 0.68)]],
    "N": [[(0, 1), (0, 0), (1, 1), (1, 0)]],
    "D": [[(0.05, 0), (0, 1)], [(0.05, 0), (0.75, 0.08), (1, 0.5), (0.8, 0.92), (0, 1)]],
    "L": [[(0, 0), (0.05, 1), (0.95, 0.95)]],
    "R": [[(0, 1), (0.05, 0), (0.8, 0.05), (0.92, 0.28), (0.6, 0.5), (0.05, 0.52)], [(0.5, 0.52), (1, 1)]],
    "C": [[(1, 0.12), (0.45, 0), (0.05, 0.35), (0, 0.7), (0.4, 1), (1, 0.88)]],
    "E": [[(1, 0.02), (0.05, 0), (0, 1), (1, 0.97)], [(0.05, 0.5), (0.75, 0.48)]],
    "U": [[(0, 0), (0.02, 0.7), (0.3, 1), (0.7, 1), (1, 0.7), (1, 0)]],
    "I": [[(0.5, 0), (0.48, 1)]],
    "G": [[(1, 0.12), (0.45, 0), (0.05, 0.35), (0, 0.7), (0.4, 1), (0.95, 0.9), (0.97, 0.55), (0.55, 0.55)]],
    "B": [[(0.05, 0), (0, 1)], [(0.05, 0), (0.8, 0.06), (0.88, 0.28), (0.05, 0.5)], [(0.05, 0.5), (0.9, 0.56), (1, 0.8), (0.8, 1), (0, 1)]],
}
_KULT_IMG = []


def _spray_text(layer, rng, word, cx, cy, lw, lh, col):
    """crude brush lettering: wobbly thick strokes, ragged edges, a few drips"""
    n = len(word.replace(" ", ""))
    gap = lw * 0.38
    total = len(word) * lw + (len(word) - 1) * gap
    x = cx - total / 2
    for ch in word:
        if ch != " ":
            gw, gh = lw * rng.uniform(0.9, 1.1), lh * rng.uniform(0.9, 1.1)
            oy = rng.uniform(-4, 4)
            rot = rng.uniform(-0.12, 0.12)
            for st in _KULT_GLYPHS[ch]:
                pts = []
                for (px_, py_) in st:
                    px_ += rng.uniform(-0.03, 0.03)
                    py_ += rng.uniform(-0.03, 0.03)
                    ux, uy = (px_ - 0.5) * gw, (py_ - 0.5) * gh
                    pts.append((x + gw / 2 + ux * math.cos(rot) - uy * math.sin(rot), cy + oy + ux * math.sin(rot) + uy * math.cos(rot)))
                for i in range(len(pts) - 1):
                    (x1, y1), (x2, y2) = pts[i], pts[i + 1]
                    steps = max(2, int(math.hypot(x2 - x1, y2 - y1) / 1.5))
                    for k in range(steps + 1):
                        u = k / float(steps)
                        r = lh * 0.098 * rng.uniform(0.9, 1.1)
                        pygame.draw.circle(layer, col, (int(x1 + (x2 - x1) * u + rng.uniform(-0.8, 0.8)), int(y1 + (y2 - y1) * u + rng.uniform(-0.8, 0.8))), max(2, int(r)))
                for (qx, qy) in (pts[0], pts[-1]):                           # ragged brush ends and a drip now and then
                    for _ in range(6):
                        pygame.draw.circle(layer, col, (int(qx + rng.uniform(-6, 6)), int(qy + rng.uniform(-6, 6))), rng.randint(1, 2))
                    if rng.random() < 0.28:
                        pygame.draw.line(layer, col, (int(qx), int(qy)), (int(qx + rng.uniform(-1, 1)), int(qy + rng.randint(10, 26))), 3)
        x += lw + gap


def _kult_scene():
    """the garage door scene, built once (the paint, the shadows and the wall are not redrawn every frame)"""
    sc_ = pygame.Surface((W, H))
    sc_.fill((12, 6, 8))
    cx, top, dw, dh = W // 2, 104, 290, 220
    x0 = cx - dw // 2
    for r_ in range(0, 250, 10):                                         # brick wall around it
        for c_ in range(-1, 20):
            bx = 90 + c_ * 30 + (15 if (r_ // 10) % 2 else 0)
            if x0 - 24 < bx + 28 and bx < x0 + dw + 24 and top - 6 < 98 + r_ < top + dh + 8:
                continue
            pygame.draw.rect(sc_, (26, 14, 14) if (r_ // 10 + c_) % 3 else (32, 18, 16), (bx, 98 + r_ - 6, 28, 8))
    pygame.draw.rect(sc_, (60, 56, 56), (x0 - 12, top - 12, dw + 24, dh + 12))              # concrete frame
    pygame.draw.rect(sc_, (20, 18, 20), (x0 - 12, top - 12, dw + 24, dh + 12), 3)
    gap = 14                                                              # the door is not quite shut: a red slit at the bottom
    pygame.draw.rect(sc_, (18, 4, 6), (x0, top, dw, dh))
    sl = 44                                                               # four tall panels, like a sectional garage door
    door = pygame.Surface((dw, dh - gap))
    door.fill((78, 74, 80))
    for i in range(0, dh - gap, sl):
        for px_ in range(8, dw - 40, 68):                                  # raised panel plates
            pygame.draw.rect(door, (88, 84, 90), (px_, i + 8, 56, sl - 16))
            pygame.draw.rect(door, (50, 46, 52), (px_, i + 8, 56, sl - 16), 2)
    rng = random.Random(11)
    for gx in range(10, dw - 10, 46):                                      # rust streaks
        pygame.draw.line(door, (96, 58, 40), (gx, rng.randint(0, 40)), (gx + rng.randint(-4, 4), rng.randint(70, 150)), 2)
    paint = pygame.Surface(door.get_size(), pygame.SRCALPHA)
    col = (214, 40, 36, 255)
    _spray_text(paint, rng, "VANDAL", dw // 2, 62, 32, 62, col)
    _spray_text(paint, rng, "RACING CLUB", dw // 2, 140, 17, 34, col)
    for _ in range(90):                                                    # overspray
        pygame.draw.circle(paint, (214, 40, 36, 90), (rng.randint(8, dw - 8), rng.randint(20, dh - gap - 20)), 1)
    door.blit(paint, (0, 0))
    seams = pygame.Surface(door.get_size(), pygame.SRCALPHA)               # the joints between the panels cut through the paint
    for i in range(sl, dh - gap, sl):
        pygame.draw.rect(seams, (14, 12, 16, 220), (0, i - 2, dw, 3))
        pygame.draw.rect(seams, (130, 126, 134, 90), (0, i + 1, dw, 1))
    for px_ in range(8, dw - 40, 68):                                      # and so do the plate edges
        for i in range(0, dh - gap, sl):
            pygame.draw.rect(seams, (14, 12, 16, 110), (px_, i + 8, 56, sl - 16), 1)
    door.blit(seams, (0, 0))
    sc_.blit(door, (x0, top))
    pygame.draw.rect(sc_, (30, 28, 30), (cx - 22, top + dh - gap - 14, 44, 8), border_radius=2)   # handle
    for k in range(8):                                                     # the red light leaking out under the door and onto the ground
        pygame.draw.rect(sc_, (200 - k * 8, 14 + k * 2, 18), (x0 + 4 + k * 3, top + dh - gap + k // 3 + 1, dw - 8 - k * 6, 3))
    for k in range(10):
        pygame.draw.rect(sc_, (150 - k * 14, 12, 14), (x0 - k * 4, top + dh + 2 + k * 2, dw + k * 8, 2))
    for lx_ in (x0 - 42, x0 + dw + 42):                                    # a caged red lamp on each side
        pygame.draw.rect(sc_, (40, 36, 40), (lx_ - 7, top + 10, 14, 30))
        pygame.draw.circle(sc_, (110, 14, 18), (lx_, top + 56), 20)
        pygame.draw.circle(sc_, (214, 40, 36), (lx_, top + 56), 12)
        pygame.draw.circle(sc_, (255, 170, 150), (lx_, top + 56), 4)
        for cy_ in (-7, 0, 7):
            pygame.draw.line(sc_, (30, 24, 28), (lx_ - 12, top + 56 + cy_), (lx_ + 12, top + 56 + cy_), 2)
    return sc_


def _draw_kult():
    """the club's door: a garage door with the name painted on it, shut, a red light leaking out underneath"""
    if not _KULT_IMG:
        _KULT_IMG.append(_kult_scene())
    screen.blit(_KULT_IMG[0], (0, 0))
    text("IMPATIENT, EH? SOON.", font_big, (255, 130, 112), W // 2, 372, "center")


def draw_menu(run, frame):
    sc = MENU["screen"]
    if sc is None:
        return
    del BUTTONS[:]
    if sc == "main":
        screen.blit(_title_bg(), (0, 0))                          # the title screen is its own: dark, with the fire underneath
    else:
        dim(190 if sc != "pause" else 150)
    if sc in ("main", "cars"):
        _title_fire()
    if sc == "main":
        _title_embers(frame)
    if sc == "main":
        text(config.TITLE, font_title, (230, 190, 50), W // 2, 70, "center")
    elif sc == "pause":
        text("PAUSED", font_big, (230, 190, 50), W // 2, 100, "center")
    elif sc == "options":
        text("OPTIONS", font_big, (230, 190, 50), W // 2, 70, "center")
    elif sc == "levels":
        _draw_levels()
        return
    elif sc == "scores":
        screen.fill((24, 16, 10))
        pg = MENU.get("sc_page", 0) % 3
        text("HIGH SCORES", font_big, (230, 190, 50), W // 2, 22, "center")
        button((40, 62, 70, 44), pygame.K_LEFT, label="<")
        button((W - 110, 62, 70, 44), pygame.K_RIGHT, label=">")
        text(("ALL CARS", "CAR CHAMPIONS", "HALL OF SHAME")[pg], font_mid, (240, 200, 70) if pg < 2 else (230, 90, 70), W // 2, 66, "center")
        sl_ = MENU.get("sc_lv", SET["level"])
        if sl_ not in LEVELS:
            sl_ = SET["level"]
        text(LEVELS[sl_]["name"], font, (240, 200, 70), W // 2, 92, "center")
        if len(_score_levels()) > 1:                                             # more than one race to look at: flip between them
            button((W // 2 - 190, 84, 56, 32), pygame.K_TAB, label="<")
            button((W // 2 + 134, 84, 56, 32), pygame.K_TAB, label=">")
        for d_ in range(3):
            pygame.draw.circle(screen, (255, 200, 60) if d_ == pg else (80, 60, 28), (W // 2 - 12 + d_ * 12, 114), 3)
        if pg == 0:
            st_ = scores.BOARD["status"]
            allr = scores.top(80)
            sub = _sub_page(len(allr))
            draw_board_rows(allr[sub * 5:sub * 5 + 5], None, 166, 42)
            _sub_buttons(sub, len(allr))
            empty = st_ == "ok" and not scores.BOARD["rows"]
        elif pg == 1:
            st_ = scores.CHAMPS["status"]
            draw_champs(166, 50)
            empty = False
        else:
            st_ = scores.SHAME["status"]
            allr = scores.top_shame(80)
            sub = _sub_page(len(allr))
            draw_shame_rows(allr[sub * 5:sub * 5 + 5], None, 166, 42)
            _sub_buttons(sub, len(allr))
            empty = st_ == "ok" and not scores.SHAME["rows"]
        if st_ == "loading":
            text("LOADING...", font_mid, (190, 140, 60), W // 2, 250, "center")
        elif st_ == "error":
            text("COULD NOT REACH THE SCOREBOARD", font_mid, (240, 100, 70), W // 2, 250, "center")
        elif empty:
            text("NO SCORES YET. BE THE FIRST.", font_mid, (190, 140, 60), W // 2, 250, "center")
        button((10, 10, 100, 36), pygame.K_ESCAPE, label="BACK")
        text(("fastest time wins. same time: fewer hits, then who was first", "the best run on each car", "those who did not make it, furthest first")[pg], font, (120, 92, 48), W // 2, 470, "center")
        return
    elif sc == "cars":
        text("PICK YOUR CAR", font_big, (230, 190, 50), W // 2, 34, "center")
        c = CARS[SET["car"] % len(CARS)]
        spr = car_sprite.get(False, 4, SET["car"])
        screen.blit(spr, (W // 2 - spr.get_width() // 2, 96))
        button((40, 150, 100, 110), pygame.K_LEFT, label="<", big=True)
        button((W - 140, 150, 100, 110), pygame.K_RIGHT, label=">", big=True)
        text(c["name"], font_mid, (240, 200, 70), W // 2, 232, "center")
        text(c["desc"], font, (190, 140, 60), W // 2, 268, "center")
        for i, (lab, key) in enumerate((("TOP SPEED", "top"), ("PULL", "pull"), ("GRIP", "grip"), ("BRAKES", "brake"))):
            yy = 292 + i * 22
            text(lab, font, (200, 160, 70), W // 2 - 170, yy)
            for k in range(5):
                pygame.draw.rect(screen, (255, 200, 60) if k < c[key] else (60, 44, 24), (W // 2 - 20 + k * 34, yy + 1, 28, 14))
        button((W // 2 - 120, 396, 240, 58), pygame.K_RETURN, label="GO", hot=True, big=True)
        button((10, 10, 100, 36), pygame.K_ESCAPE, label="BACK")
        button((W - 110, 10, 100, 36), pygame.K_F1, label="RULES")
        return
    elif sc == "kult":
        _draw_kult()
        button((W // 2 - 90, 440, 180, 44), pygame.K_ESCAPE, label="BACK", hot=True)
        return
    elif sc == "help":
        pages = MENU.get("pages") or TUTORIAL
        pg = MENU["page"] % len(pages)
        title, rows = pages[pg]
        text(title, font_big, (230, 190, 50), W // 2, 40, "center")
        yy = 104
        for icon, col, head, det in rows:
            pygame.draw.rect(screen, (30, 20, 12), (34, yy - 4, W - 68, 70), border_radius=6)
            pygame.draw.rect(screen, (90, 62, 28), (34, yy - 4, W - 68, 70), 1, border_radius=6)
            ic = _icon(icon)
            if ic is not None:
                screen.blit(ic, (50 + (62 - ic.get_width()) // 2, yy + 31 - ic.get_height() // 2))
            text(head, font_mid, col, 128, yy + 6)
            text(det, font, (200, 160, 70), 128, yy + 36)
            yy += 78
        text("%d / %d" % (pg + 1, len(pages)), font, (150, 112, 54), W // 2, 462, "center")
        button((40, 448, 110, 40), pygame.K_LEFT, label="<")
        racing_ = MENU.get("rb") == "race"
        button((W - 150, 448, 110, 40), pygame.K_RIGHT, label=">" if pg < len(pages) - 1 else ("GO" if racing_ else "DONE"), hot=racing_ and pg == len(pages) - 1)
        button((10, 10, 100, 36), pygame.K_ESCAPE, label="BACK")
        if racing_:
            button((W - 110, 10, 100, 36), pygame.K_TAB, label="SKIP")
        return
    items = menu_items()
    y0 = 214 if sc == "main" else 150
    wb = 300 if sc == "main" else (260 if sc != "options" else 400)
    for i, it in enumerate(items):
        if sc == "options":
            ry = 120 + i * 50
            if it in SLIDERS:
                hot = i == MENU["sel"]
                r = pygame.Rect(W // 2 - 200, ry, 400, 42)
                button(r, pygame.K_RETURN, sel=i)
                pygame.draw.rect(screen, (70, 46, 18) if hot else (36, 24, 14), r, border_radius=8)
                pygame.draw.rect(screen, (255, 210, 70) if hot else (120, 84, 40), r, 2, border_radius=8)
                text(it, font_mid, (255, 226, 100) if hot else (190, 140, 60), r.x + 16, r.y + 9)
                v_ = SET[SLIDERS[it]]
                for c_ in range(10):
                    pygame.draw.rect(screen, (255, 160, 40) if c_ < v_ else (66, 48, 26), (r.x + 168 + c_ * 19, r.y + 14, 15, 15))
                button((r.x + 124, r.y + 4, 36, 34), pygame.K_LEFT, sel=i, label="<")
                button((r.right - 40, r.y + 4, 36, 34), pygame.K_RIGHT, sel=i, label=">")
            else:
                button((W // 2 - 200, ry, 400, 42), pygame.K_RETURN, sel=i, label=it, hot=(i == MENU["sel"]))
            continue
        gap_ = 58 if len(items) <= 4 else 54
        button((W // 2 - wb // 2, y0 + i * gap_, wb, 46), pygame.K_RETURN, sel=i, label=it, hot=(i == MENU["sel"]), red=(it == KULT))
    if sc == "options":
        text(tap_hint("LEFT / RIGHT changes a setting", "tap a setting to change it"), font, (110, 84, 44), W // 2, 474, "center")


def apply_audio():
    if AUDIO is not None:
        AUDIO.set_music(SET["music"])
        AUDIO.set_sfx(SET["sfx"])
        AUDIO.set_levels(SET["vm"] / 8.0, SET["ve"] / 4.0, SET["vf"] / 6.0)


def menu_items_for_main():
    its = ["START"] + (["SCORES"] if scores.enabled() else []) + ["OPTIONS", KULT]
    return its


def _opt_sel(back):
    """index of OPTIONS in the menu we came from"""
    its = ["START"] + (["SCORES"] if scores.enabled() else []) + ["OPTIONS"] if back == "main" else ["RESUME", "OPTIONS"]
    return its.index("OPTIONS")


def menu_key(run, key):
    """returns a new Run to start, or None"""
    sc = MENU["screen"]
    if sc == "scores":
        if key == pygame.K_TAB:                                         # next race: its own boards
            lvs_ = _score_levels()
            if len(lvs_) > 1:
                cur_ = MENU.get("sc_lv", SET["level"])
                nxt_ = lvs_[(lvs_.index(cur_) + 1) % len(lvs_)] if cur_ in lvs_ else lvs_[0]
                MENU.update(sc_lv=nxt_, sc_sub=0)
                scores.load(nxt_)
                scores.load_champs(nxt_, len(CARS))
                scores.load_shame(nxt_)
            return None
        if key in (pygame.K_LEFT, pygame.K_RIGHT):
            MENU["sc_page"] = (MENU.get("sc_page", 0) + (1 if key == pygame.K_RIGHT else -1)) % 3
            MENU["sc_sub"] = 0
        elif key in (pygame.K_UP, pygame.K_DOWN):                       # more rows: five to a page, as many pages as there are scores
            MENU["sc_sub"] = max(0, MENU.get("sc_sub", 0) + (1 if key == pygame.K_DOWN else -1))
        elif key in (pygame.K_RETURN, pygame.K_ESCAPE):
            MENU.update(screen="main", sel=1)
        return None
    if sc == "levels":
        if "card" not in MENU or MENU.get("card_lv") != SET["level"]:
            MENU["card"] = LV_CARDS.index(SET["level"]) if SET["level"] in LV_CARDS else 0
        if key in (pygame.K_LEFT, pygame.K_RIGHT):
            MENU["card"] = max(0, min(len(LV_CARDS) - 1, MENU["card"] + (1 if key == pygame.K_RIGHT else -1)))
            c_ = LV_CARDS[MENU["card"]]
            if c_ and level_playable(c_) and c_ != SET["level"]:
                SET["level"] = c_
                build_world(c_)
            MENU["card_lv"] = SET["level"]
        elif key == pygame.K_RETURN:
            c_ = LV_CARDS[MENU["card"]]
            if c_ and level_playable(c_):
                save_settings()
                MENU.update(screen="cars")
        elif key == pygame.K_ESCAPE:
            save_settings()
            MENU.update(screen="main", sel=0)
        return None
    if sc == "cars":
        if key in (pygame.K_LEFT, pygame.K_RIGHT):
            SET["car"] = (SET["car"] + (1 if key == pygame.K_RIGHT else -1)) % len(CARS)
        elif key == pygame.K_RETURN:
            save_settings()
            if SET["level"] in SET["rules_seen"]:
                return "race"
            open_rules(SET["level"], "race")                            # first time on this road: the rulebook, then the countdown
        elif key == pygame.K_F1:
            open_rules(SET["level"], "cars")
        elif key == pygame.K_ESCAPE:
            save_settings()
            MENU.update(screen="levels", card=LV_CARDS.index(SET["level"]) if SET["level"] in LV_CARDS else 0, card_lv=SET["level"])
        return None
    if sc == "kult":
        if key in (pygame.K_ESCAPE, pygame.K_RETURN):
            MENU.update(screen="main", sel=menu_items_for_main().index(KULT))
        return None
    if sc == "help":
        pages = MENU.get("pages") or TUTORIAL
        rb = MENU.get("rb", "options")
        if key == pygame.K_LEFT:
            MENU["page"] = (MENU["page"] - 1) % len(pages)
        elif key == pygame.K_RIGHT or key == pygame.K_RETURN:
            if MENU["page"] >= len(pages) - 1:
                return rules_done(rb)
            MENU["page"] += 1
        elif key == pygame.K_TAB and rb == "race":                      # SKIP: straight to the countdown (and not shown again)
            return rules_done(rb)
        elif key == pygame.K_ESCAPE:
            MENU.update(screen="cars" if rb == "race" else rb, sel=0, page=0)
        return None
    items = menu_items()
    if key == pygame.K_p and sc == "pause":
        return "resume"
    if key == pygame.K_UP:
        MENU["sel"] = (MENU["sel"] - 1) % len(items)
    elif key == pygame.K_DOWN:
        MENU["sel"] = (MENU["sel"] + 1) % len(items)
    elif key == pygame.K_ESCAPE:
        if sc == "options":
            save_settings()
            MENU.update(screen=MENU["back"], sel=_opt_sel(MENU["back"]))
        elif sc == "pause":
            return "resume"
    elif key in (pygame.K_RETURN, pygame.K_LEFT, pygame.K_RIGHT):
        it = items[MENU["sel"]]
        enter = key == pygame.K_RETURN
        if sc == "main" and enter:
            if it == "START":                                   # START -> pick the race -> pick the car -> go
                MENU.update(screen="levels", card=LV_CARDS.index(SET["level"]) if SET["level"] in LV_CARDS else 0, card_lv=SET["level"])
            elif it == "SCORES":
                MENU.update(screen="scores", sc_page=0, sc_lv=SET["level"])
                scores.load(SET["level"])
                scores.load_champs(SET["level"], len(CARS))
                scores.load_shame(SET["level"])
            elif it == "OPTIONS":
                MENU.update(screen="options", sel=0, back="main")
            elif it == KULT:
                MENU.update(screen="kult")
            elif it == "QUIT":
                pygame.quit()
                sys.exit()
        elif sc == "pause" and enter:
            if it == "RESUME":
                return "resume"
            if it == "RULEBOOK":
                open_rules(LEVEL, "pause")
            elif it == "OPTIONS":
                MENU.update(screen="options", sel=0, back="pause")
            else:
                return "quit"
        elif sc == "options":
            if it == "HOW TO PLAY" and enter:
                open_rules(LEVEL if MENU["back"] == "pause" else SET["level"], "options")
            elif it.startswith("WINDOW"):
                set_fullscreen(not SET["full"])
                save_settings()
            elif it.startswith("SCREEN"):
                SET["pixel"] = not SET["pixel"]
            elif it in SLIDERS:
                k_ = SLIDERS[it]
                SET[k_] = (SET[k_] + (-1 if key == pygame.K_LEFT else 1)) % 11 if key == pygame.K_RETURN else max(0, min(10, SET[k_] + (-1 if key == pygame.K_LEFT else 1)))
                apply_audio()
                save_settings()
            elif it == "BACK" and enter:
                save_settings()
                MENU.update(screen=MENU["back"], sel=_opt_sel(MENU["back"]))
    return None


# ------------------------------------------------------------------ touch controls
TBTN = {"left": pygame.Rect(6, H - 112, 84, 106), "right": pygame.Rect(96, H - 112, 84, 106),
        "brake": pygame.Rect(W - 96, H - 112, 90, 106), "gas": pygame.Rect(W - 96, H - 236, 90, 118),
        "pause": pygame.Rect(W - 76, 60, 66, 50),
        "horn": pygame.Rect(W - 168, H - 64, 64, 58)}       # small button just left of BRAKE: the right thumb reaches it without leaving the pedals


def touch_held():
    """names of the driving buttons that a finger is on right now"""
    held = set()
    for pos in TOUCH["fingers"].values():
        for name in ("left", "right", "brake", "gas", "horn"):
            if TBTN[name].inflate(10, 10).collidepoint(pos) if name == "horn" else TBTN[name].collidepoint(pos):
                held.add(name)
    return held


class Keys:
    """keyboard and touch buttons answer to the same keys[...] lookups"""
    MAP = {pygame.K_LEFT: "left", pygame.K_RIGHT: "right", pygame.K_DOWN: "brake", pygame.K_UP: "gas", pygame.K_h: "horn"}

    def __init__(self, kb, held):
        self.kb, self.held = kb, held

    def __getitem__(self, k):
        return bool(self.kb[k]) or (self.MAP.get(k) in self.held)


_PORT = {"on": False, "t": 0}


def check_portrait():
    """browser on a phone held upright: the game is far too small, so ask for the phone to be turned"""
    if sys.platform != "emscripten":
        return
    _PORT["t"] += 1
    if _PORT["t"] % 20 != 1:
        return
    try:
        import platform
        w = platform.window
        _PORT["on"] = float(w.innerHeight) > float(w.innerWidth) * 1.05 and float(w.innerWidth) < 900
    except Exception:
        _PORT["on"] = False


def draw_portrait_hint():
    if not _PORT["on"]:
        return
    ov = pygame.Surface((W, H), pygame.SRCALPHA)
    ov.fill((8, 6, 16, 235))
    screen.blit(ov, (0, 0))
    tt = (pygame.time.get_ticks() // 40) % 40
    ph = pygame.Rect(0, 0, 70, 120)                                   # a little phone that tips over sideways
    ph.center = (W // 2, 170)
    surf = pygame.Surface((70, 120), pygame.SRCALPHA)
    pygame.draw.rect(surf, (255, 226, 120), (0, 0, 70, 120), 4, border_radius=10)
    pygame.draw.rect(surf, (255, 226, 120), (24, 106, 22, 4), border_radius=2)
    ang = 90.0 * min(1.0, tt / 20.0)
    rot = pygame.transform.rotate(surf, ang)
    screen.blit(rot, (W // 2 - rot.get_width() // 2, 170 - rot.get_height() // 2))
    text("TURN YOUR PHONE", font_big, (255, 226, 120), W // 2, 290, "center")
    text("SIDEWAYS", font_big, (255, 226, 120), W // 2, 336, "center")


def draw_touch(run):
    if not TOUCH["on"] or MENU["screen"] is not None or run.state not in ("countdown", "race"):
        return
    held = touch_held()
    ov = pygame.Surface((W, H), pygame.SRCALPHA)
    for name, lab in (("left", "<"), ("right", ">"), ("brake", "BRAKE"), ("gas", "GAS")):
        r = TBTN[name]
        on = name in held
        pygame.draw.rect(ov, (255, 210, 70, 120 if on else 55), r, border_radius=14)
        pygame.draw.rect(ov, (255, 226, 120, 190), r, 2, border_radius=14)
    r = TBTN["horn"]                                                   # horn: smaller; lights up while held
    pygame.draw.rect(ov, (255, 210, 70, 120 if "horn" in held else 55), r, border_radius=14)
    pygame.draw.rect(ov, (255, 226, 120, 190), r, 2, border_radius=14)
    r = TBTN["pause"]                                                  # pause: dark pill with two bars
    pygame.draw.rect(ov, (24, 14, 6, 190), r, border_radius=10)
    pygame.draw.rect(ov, (255, 226, 120, 255), r, 3, border_radius=10)
    for bx_ in (r.centerx - 11, r.centerx + 3):
        pygame.draw.rect(ov, (255, 226, 120, 255), (bx_, r.centery - 11, 8, 22), border_radius=2)
    screen.blit(ov, (0, 0))
    for name, lab in (("left", "<"), ("right", ">"), ("brake", "BRAKE"), ("gas", "GAS")):
        r = TBTN[name]
        text(lab, font_big if len(lab) == 1 else font_mid, (255, 236, 150), r.centerx, r.centery - (22 if len(lab) == 1 else 10), "center")
    r = TBTN["horn"]
    text("HORN", font, (255, 236, 150), r.centerx, r.centery - 8, "center")


def _tap_key(run, pos):
    """what a tap at pos means: a key press (or None)"""
    if MENU["screen"] is not None:
        for r, key, sel in reversed(BUTTONS):
            if r.collidepoint(pos):
                if sel is not None:
                    MENU["sel"] = sel
                return key
        return None
    if run.state in ("countdown", "race"):
        if RADIO_RECT[0].collidepoint(pos):
            return pygame.K_r
        return pygame.K_ESCAPE if TBTN["pause"].inflate(14, 14).collidepoint(pos) else None
    if run.state in ("finish", "over"):
        for r, key in END_BTNS:
            if r.collidepoint(pos):
                return key
        if run.sb_phase in ("name", "sending", "loading"):
            return None                                   # a stray tap must not skip the name box
        return pygame.K_RETURN
    return None


TAPT = [-1000, (0, 0)]
_ECHO = {"pre": None, "pt": -9999, "until": -9999}

_JSK = {"code": {"ArrowUp": pygame.K_UP, "ArrowDown": pygame.K_DOWN, "ArrowLeft": pygame.K_LEFT, "ArrowRight": pygame.K_RIGHT,
                 "Enter": pygame.K_RETURN, "NumpadEnter": pygame.K_RETURN, "Escape": pygame.K_ESCAPE, "KeyP": pygame.K_p,
                 "KeyF": pygame.K_f, "KeyR": pygame.K_r, "KeyH": pygame.K_h, "Backspace": pygame.K_BACKSPACE, "F11": pygame.K_F11, "F3": pygame.K_F3},
        "seen_k": False, "seen_p": False, "down": {}, "use_keys": False, "n_sdl": 0, "n_js": 0,
        "page_keys": False, "sdl_ok": False, "last_sdl": "-", "last_js": "-"}
BUILD = "input-test 4"


class _JSKB:
    """pressed-keys lookup fed by the page's own key events (only used if the engine gets none)"""
    def __getitem__(self, k):
        return bool(_JSK["down"].get(k))


def js_input(evl):
    """browser backup input: adds events only for the kinds (keys / pointer) the engine itself never delivered"""
    for e in evl:
        if e.type in (pygame.KEYDOWN, pygame.KEYUP):
            _JSK["seen_k"] = True
        elif e.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
            _JSK["seen_p"] = True
    out = []
    _JSK["n_sdl"] += sum(1 for e in evl if e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN))
    for e in evl:
        if e.type == pygame.KEYDOWN:
            _JSK["last_sdl"] = str(getattr(e, "key", "?"))
    sdl_keys = set(getattr(e, "key", None) for e in evl if e.type == pygame.KEYDOWN)
    for it in webtouch.poll():
        _JSK["n_js"] += 1
        kind = it[0]
        if kind in ("kd", "ku", "blur"):
            if kind == "kd":
                _JSK["last_js"] = str(it[1])
                if _JSK["code"].get(it[1]) is not None:
                    # Safari: the engine's own key events can be wrong, or stop coming after a while. The page's key events are
                    # reliable, so a key the page reports is always used, and the engine's copy of it (if any) is dropped.
                    _JSK["page_keys"] = True
                    _JSK["page_t"] = pygame.time.get_ticks()
            if kind == "blur":
                _JSK["down"].clear()
                continue
            k = _JSK["code"].get(it[1])
            if k is None:
                continue
            _JSK["use_keys"] = True
            _JSK["down"][k] = kind == "kd"
            if kind == "kd":
                out.append(types.SimpleNamespace(type=pygame.KEYDOWN, key=k))
        elif not _JSK["seen_p"]:
            _n, pid, ptype, x, y = it
            if ptype == "mouse":
                t = {"pointerdown": pygame.MOUSEBUTTONDOWN, "pointermove": pygame.MOUSEMOTION}.get(_n, pygame.MOUSEBUTTONUP)
                out.append(types.SimpleNamespace(type=t, pos=(x * W, y * H), button=1, touch=False))
            else:
                t = {"pointerdown": pygame.FINGERDOWN, "pointermove": pygame.FINGERMOTION}.get(_n, pygame.FINGERUP)
                out.append(types.SimpleNamespace(type=t, x=x, y=y, finger_id=pid))
    return out


# ------------------------------------------------------------------ main
async def main():
    global AUDIO
    BOOT[0]("settings")
    load_settings()
    if config.START_LEVEL in LEVELS:
        SET["level"] = config.START_LEVEL
    if SET["level"] not in LEVELS or (LEVELS[SET["level"]].get("locked") and not DEV):
        SET["level"] = 1
    BOOT[0]("building the world")
    build_world(SET["level"])
    BOOT[0]("starting audio")
    AUDIO = audio.Audio()
    AUDIO.station = SET.get("radio", 0) % len(audio.STATIONS)
    BOOT[0]("audio done")
    if sys.platform == "emscripten":
        pygame.display.set_caption("ROAD VANDAL  mixer %s" % (pygame.mixer.get_init(),))     # tab title shows the real sound format
    apply_audio()
    if SET["full"]:
        set_fullscreen(True)
    run = Run()
    MENU.update(screen="main", sel=0)
    BOOT[0]("menu")
    if sys.platform == "emscripten":
        webtouch.install()                                            # fit the canvas to the screen, go fullscreen/sideways on the first tap
    frame = 0
    acc = 0.0
    show_fps = False
    while True:
        acc = min(acc + clock.tick(60), 120.0 if sys.platform == "emscripten" else 60.0)
        frame += 1
        evs = []
        evl = list(pygame.event.get())
        if sys.platform == "emscripten":
            evl += js_input(evl)
        for e0 in evl:
            if e0.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            tap = None
            if e0.type in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
                if not TOUCH["on"] and sys.platform == "emscripten":
                    webtouch.go_landscape()                                   # first touch: ask the phone to go sideways
                TOUCH["on"] = TOUCH["fingers_seen"] = True
                pos = (e0.x * W, e0.y * H)
                if e0.type == pygame.FINGERUP:
                    TOUCH["fingers"].pop(e0.finger_id, None)
                else:
                    TOUCH["fingers"][e0.finger_id] = pos
                    if e0.type == pygame.FINGERDOWN:
                        tap = pos
            elif e0.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
                if getattr(e0, "touch", False):
                    if not TOUCH["on"] and sys.platform == "emscripten":
                        webtouch.go_landscape()
                    TOUCH["on"] = True
                    if TOUCH.get("fingers_seen"):
                        continue                              # the finger events already told us
                if e0.type == pygame.MOUSEBUTTONUP:
                    TOUCH["fingers"].pop("m", None)
                elif e0.type == pygame.MOUSEBUTTONDOWN and e0.button == 1:
                    TOUCH["fingers"]["m"] = e0.pos
                    tap = e0.pos
                elif e0.type == pygame.MOUSEMOTION and "m" in TOUCH["fingers"]:
                    TOUCH["fingers"]["m"] = e0.pos
            if tap is not None:                                # one finger can arrive as a mouse click AND a touch: count it once
                now_ = pygame.time.get_ticks()
                if now_ - TAPT[0] < 120 and abs(tap[0] - TAPT[1][0]) < 40 and abs(tap[1] - TAPT[1][1]) < 40:
                    tap = None
                else:
                    TAPT[0], TAPT[1] = now_, tap
            if tap is not None:
                k_ = _tap_key(run, tap)
                if k_ is not None:
                    evs.append(types.SimpleNamespace(type=pygame.KEYDOWN, key=k_))
            elif e0.type == pygame.KEYDOWN:
                if sys.platform == "emscripten" and getattr(e0, "key", None) in _JSK["code"].values() and type(e0).__name__ == "Event" \
                        and pygame.time.get_ticks() - _JSK.get("page_t", -99999) < 300:
                    continue                              # the page already reported this key press: do not act on it twice
                evs.append(e0)
        scores.poll()
        if run.state in ("finish", "over"):
            sb_tick(run)
        for ev in evs:
            now_ = pygame.time.get_ticks()                      # a touch can arrive twice (touch + emulated click): an event right after a screen change is such an echo, not a new press
            cur_ = (MENU["screen"], id(run))
            if _ECHO["pre"] is not None and cur_ != _ECHO["pre"] and now_ - _ECHO["pt"] < 250:
                _ECHO["until"] = _ECHO["pt"] + 250
            _ECHO["pre"] = cur_
            if now_ < _ECHO["until"]:
                continue
            _ECHO["pt"] = now_
            if ((run.state == "finish" and run.finish_frames > 60) or (run.state == "over" and run.over_frames > 40)) and MENU["screen"] is None and run.sb_phase != "idle" and sb_key(run, ev):
                continue                                    # typing a name: keys like F must not toggle fullscreen
            if ev.key in (pygame.K_F11, pygame.K_f) and not (MENU["screen"] == "cars"):
                set_fullscreen(not SET["full"])                 # F or F11 anywhere
                save_settings()
                continue
            if MENU["screen"] is not None:
                r = menu_key(run, pygame.K_ESCAPE if ev.key == pygame.K_BACKSPACE else ev.key)      # Backspace = back (Esc also leaves browser fullscreen)
                if r == "race":
                    if LEVEL != SET["level"]:
                        build_world(SET["level"])
                    AUDIO.track = THEME.get("music", "music")
                    AUDIO.dark_file = THEME.get("dark_file", "music")
                    run = Run()
                    run.start()
                    MENU["screen"] = None
                    AUDIO.resume()
                elif r == "resume":
                    MENU["screen"] = None
                    AUDIO.resume()
                elif r == "quit":
                    AUDIO.resume()
                    AUDIO.silence()
                    run = Run()
                    MENU.update(screen="main", sel=0)
                continue
            if ev.key == pygame.K_h:
                continue                                  # the horn is read from the held key / button (see below)
            if ev.key == pygame.K_r and run.state in ("countdown", "race"):
                SET["radio"] = AUDIO.next_station()
                save_settings()
                continue
            if ev.key in (pygame.K_p, pygame.K_ESCAPE) and run.state in ("countdown", "race"):
                MENU.update(screen="pause", sel=0, back="pause")
                AUDIO.pause()
                continue
            if ev.key == pygame.K_ESCAPE:
                AUDIO.silence()
                run = Run()
                MENU.update(screen="main", sel=0)
            elif ev.key == pygame.K_F3:
                show_fps = not show_fps
            elif ev.key == pygame.K_RETURN:
                if (run.state == "finish" and run.finish_frames > 60) or (run.state == "over" and run.over_frames > 40):
                    AUDIO.track = THEME.get("music", "music")
                    AUDIO.dark_file = THEME.get("dark_file", "music")
                    run = Run()
                    run.start()
        keys = Keys(_JSKB() if _JSK["use_keys"] else pygame.key.get_pressed(), touch_held() if MENU["screen"] is None else set())
        if MENU["screen"] is None:
            steps = 0
            while (acc >= 15.0 or steps == 0) and steps < (7 if sys.platform == "emscripten" else 3):   # a slow computer gets extra game steps, so the speed stays right
                update(run, keys)
                acc -= 16.667
                steps += 1
            acc = max(acc, 0.0)
            AUDIO.set_car(SET["car"])
            AUDIO.update(run, keys)
            hd = bool(keys[pygame.K_h]) and run.state == "race"        # the horn follows the key / finger: a tap is short, holding keeps it going
            if hd and not run.horn_on:
                run.horn_on, run.horn_t = True, 0
                honk(run)
            elif run.horn_on:
                run.horn_t += 1
                if run.state != "race" or (not hd and run.horn_t >= 10):
                    run.horn_on = False
                    getattr(AUDIO, "honk_off", lambda: None)()
        else:
            acc = 0.0
            if run.horn_on:
                run.horn_on = False
                getattr(AUDIO, "honk_off", lambda: None)()
        draw(run, keys, frame)
        draw_menu(run, frame)
        draw_touch(run)
        check_portrait()
        draw_portrait_hint()
        if show_fps or (sys.platform == "emscripten" and TOUCH["on"] and MENU["screen"] is None):
            text("FPS %d" % clock.get_fps(), font_mid, (255, 255, 255), 8, H - 26)
        pygame.display.flip()
        await asyncio.sleep(0)                              # lets the browser breathe (needed for the web version)

