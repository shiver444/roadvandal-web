"""Sound for the browser build.

pygame's mixer runs on the same thread as the game in a browser, so a slow frame starves it and the sound crackles.
Here the sounds are played by the browser's own audio system (Web Audio), which has its own audio thread.
The classes below look like the few pygame.mixer.Sound / Channel calls the game uses, so audio.py barely changes.
If anything fails, install() returns False and the game keeps using the normal pygame mixer.
"""
import array
import base64

try:
    import platform
    _win = platform.window
except Exception:                       # not running in a browser
    _win = None

_JS = r"""
(function () {
  if (window.RVA) return;
  var AC = window.AudioContext || window.webkitAudioContext;
  var ctx = new AC({latencyHint: 'interactive'});
  var out = ctx.createGain();
  out.connect(ctx.destination);
  var bufs = {}, pend = {}, ch = {}, once = {};

  function dec64(s) {
    var b = atob(s), n = b.length, u = new Uint8Array(n);
    for (var i = 0; i < n; i++) u[i] = b.charCodeAt(i);
    return u;
  }
  function whenReady(id, fn) {
    if (bufs[id]) fn(bufs[id]); else (pend[id] = pend[id] || []).push(fn);
  }
  function ready(id, b) {
    bufs[id] = b;
    var l = pend[id];
    if (l) { delete pend[id]; for (var i = 0; i < l.length; i++) l[i](b); }
  }
  function build(b, loop, fadeMs, gainv, frac) {
    var t = ctx.currentTime;
    var src = ctx.createBufferSource();
    src.buffer = b; src.loop = loop;
    var env = ctx.createGain();
    if (fadeMs > 0) { env.gain.setValueAtTime(0, t); env.gain.linearRampToValueAtTime(1, t + fadeMs / 1000); }
    var cg = ctx.createGain();
    cg.gain.value = gainv;
    src.connect(env); env.connect(cg); cg.connect(out);
    src.start(t, frac > 0 ? frac * b.duration : 0);
    return {src: src, env: env, cg: cg};
  }
  function fadeStop(o, ms) {
    var t = ctx.currentTime, g = o.env.gain;
    var cur = g.value;
    g.cancelScheduledValues(t);
    g.setValueAtTime(cur, t);
    g.linearRampToValueAtTime(0, t + Math.max(0.004, ms / 1000));
    try { o.src.stop(t + Math.max(0.004, ms / 1000) + 0.02); } catch (e) {}
  }

  window.RVA = {
    state: function () { return ctx.state; },
    resume: function () { try { ctx.resume(); } catch (e) {} return 1; },
    suspend: function () { try { ctx.suspend(); } catch (e) {} return 1; },
    pcm: function (id, b64, rate, nch) {
      var u = dec64(b64);
      var s = new Int16Array(u.buffer, 0, u.byteLength >> 1);
      var frames = (s.length / nch) | 0;
      var b = ctx.createBuffer(nch, frames, rate);
      for (var c = 0; c < nch; c++) {
        var d = b.getChannelData(c);
        for (var i = 0; i < frames; i++) d[i] = s[i * nch + c] / 32768;
      }
      ready(id, b);
      return 1;
    },
    file: function (id, b64) {
      var u = dec64(b64);
      ctx.decodeAudioData(u.buffer, function (b) { ready(id, b); }, function (e) { console.log('RVA: could not decode sound', id); });
      return 1;
    },
    once: function (id, vol, loops) {
      whenReady(id, function (b) {
        var o = build(b, loops < 0, 0, vol);
        (once[id] = once[id] || []).push(o);
        o.src.onended = function () { var l = once[id]; if (l) { var k = l.indexOf(o); if (k >= 0) l.splice(k, 1); } };
      });
      return 1;
    },
    cplay: function (cid, id, loops, vol, fadeMs, frac) {
      R.cstop(cid, 5);
      var c = ch[cid] = {vol: 1, sv: vol, id: id, dead: false, o: null};
      whenReady(id, function (b) {
        if (c.dead) return;
        c.o = build(b, loops < 0, fadeMs, c.sv * c.vol, frac || 0);
      });
      return 1;
    },
    cvol: function (cid, v) {
      var c = ch[cid];
      if (!c) return 0;
      c.vol = v;
      if (c.o) c.o.cg.gain.setTargetAtTime(c.sv * v, ctx.currentTime, 0.006);
      return 1;
    },
    cfade: function (cid, ms) {
      var c = ch[cid];
      if (!c) return 0;
      c.dead = true;
      if (c.o) fadeStop(c.o, ms);
      delete ch[cid];
      return 1;
    },
    cstop: function (cid, ms) {
      var c = ch[cid];
      if (!c) return 0;
      c.dead = true;
      if (c.o) fadeStop(c.o, ms || 5);
      delete ch[cid];
      return 1;
    },
    sfade: function (id, ms) {
      var l = once[id] || [];
      for (var i = 0; i < l.length; i++) fadeStop(l[i], ms);
      once[id] = [];
      for (var k in ch) { if (ch[k].id === id) R.cfade(k, ms); }
      return 1;
    }
  };
  var R = window.RVA;
})();
"""

_ok = False
_next = [0]


def install():
    """sets up the browser sound system; True if it works"""
    global _ok
    if _ok:
        return True
    if _win is None:
        return False
    try:
        s = _win.document.createElement("script")
        s.text = _JS
        _win.document.head.appendChild(s)
        _win.RVA.state()
        _ok = True
    except Exception as e:
        print("[audio] browser sound system not available:", e)
        _ok = False
    return _ok


def _b64(data):
    return base64.b64encode(data).decode("ascii")


class Sound:
    """pygame.mixer.Sound look-alike: pcm= 16-bit samples at `rate` (mono unless ch=2), or path= a sound file (wav/ogg/mp3)"""

    def __init__(self, path=None, pcm=None, rate=22050, ch=1):
        _next[0] += 1
        self.id = _next[0]
        self.vol = 1.0
        self.length = 0.0
        if pcm is not None:
            a = array.array("h", pcm)
            _win.RVA.pcm(self.id, _b64(a.tobytes()), rate, ch)
            self.length = len(a) / float(ch * rate)
        else:
            with open(path, "rb") as fh:
                _win.RVA.file(self.id, _b64(fh.read()))

    def set_volume(self, v):
        self.vol = float(v)

    def get_volume(self):
        return self.vol

    def get_length(self):
        return self.length

    def play(self, loops=0, fade_ms=0):
        _win.RVA.once(self.id, self.vol, -1 if loops < 0 else 0)

    def fadeout(self, ms):
        _win.RVA.sfade(self.id, int(ms))

    def stop(self):
        _win.RVA.sfade(self.id, 5)


class Channel:
    """pygame.mixer.Channel look-alike"""

    def __init__(self, i):
        self.i = i
        self.busy = False
        self.v = 1.0

    def play(self, snd, loops=0, fade_ms=0, frac=0.0):
        self.v = 1.0                                    # like pygame: a new sound starts at full channel volume
        self.busy = True
        _win.RVA.cplay(self.i, snd.id, -1 if loops < 0 else 0, snd.vol, int(fade_ms), float(frac))

    def set_volume(self, v):
        v = float(v)
        if abs(v - self.v) > 0.004:
            self.v = v
            _win.RVA.cvol(self.i, v)

    def get_volume(self):
        return self.v

    def stop(self):
        self.busy = False
        _win.RVA.cstop(self.i, 5)

    def fadeout(self, ms):
        self.busy = False
        _win.RVA.cfade(self.i, int(ms))

    def get_busy(self):
        return self.busy


def pause():
    _win.RVA.suspend()


def unpause():
    _win.RVA.resume()


def get_num_channels():
    return 16
