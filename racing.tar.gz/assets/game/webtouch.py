"""Phone helpers for the browser build: ask the phone to go sideways (Android) and tell whether it is held upright."""
try:
    import platform
    _win = platform.window
except Exception:
    _win = None

_JS = r"""
(function () {
  if (window.RVLAND) return;
  // backup input: some browsers (Safari) do not hand keys / clicks to the game engine, so we also catch them here
  var Q = [];
  function push(x) { Q.push(x); if (Q.length > 300) Q.shift(); }
  window.RVPOP = function () { if (!Q.length) return ""; var s = JSON.stringify(Q); Q = []; return s; };
  window.addEventListener('keydown', function (e) { push(['kd', e.code]); }, true);
  window.addEventListener('keyup', function (e) { push(['ku', e.code]); }, true);
  window.addEventListener('blur', function () { push(['blur']); }, true);
  ['pointerdown', 'pointermove', 'pointerup', 'pointercancel'].forEach(function (n) {
    window.addEventListener(n, function (e) {
      if (n == 'pointermove' && e.pointerType == 'mouse' && e.buttons === 0) return;
      var c = document.getElementById('canvas');
      if (!c) return;
      var r = c.getBoundingClientRect();
      push([n, e.pointerId, e.pointerType, (e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]);
    }, true);
  });
  var st = document.createElement('style');
  st.textContent = 'html,body{margin:0;background:#000;overflow:hidden;height:100%}' +
    'canvas#canvas{position:fixed!important;left:0;top:0;margin:0!important;border:0!important;padding:0!important;background:#000}';
  document.head.appendChild(st);
  function fit() {
    var c = document.getElementById('canvas');
    if (!c) return;
    var w = window.innerWidth, h = window.innerHeight, k = Math.min(w / 700, h / 500);
    var ch = Math.floor(500 * k), cw = Math.min(w, Math.floor(700 * k * 1.3));   // stretch sideways a little so wide phones fill up
    c.style.width = cw + 'px'; c.style.height = ch + 'px';
    c.style.left = Math.floor((w - cw) / 2) + 'px'; c.style.top = Math.floor((h - ch) / 2) + 'px';
  }
  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', function () { setTimeout(fit, 150); });
  setInterval(fit, 700);
  fit();
  var tried = 0;
  function go() {
    try {
      var e = document.documentElement;
      var f = e.requestFullscreen || e.webkitRequestFullscreen;
      var lock = function () { try { screen.orientation.lock('landscape').catch(function () {}); } catch (x) {} };
      if (f && !document.fullscreenElement && !document.webkitFullscreenElement) {
        var p = f.call(e);
        if (p && p.then) p.then(lock).catch(function () {}); else lock();
      } else { lock(); }
    } catch (x) {}
    setTimeout(fit, 300);
  }
  function tap() { if (window.__rvfs) return; if (tried++ < 3) go(); }
  document.addEventListener('touchend', tap, true);
  document.addEventListener('click', tap, true);
  window.RVLAND = go;
})();
"""

_ready = False


def install():
    global _ready
    if _win is None or _ready:
        return _ready
    try:
        s = _win.document.createElement("script")
        s.text = _JS
        _win.document.head.appendChild(s)
        _ready = True
    except Exception as e:
        print("[touch] helper not available:", e)
    return _ready


def go_landscape():
    """call from a touch (the browser only allows fullscreen / rotation lock after a tap)"""
    try:
        if install():
            _win.RVLAND()
    except Exception:
        pass


def is_portrait():
    try:
        return _win is not None and float(_win.innerHeight) > float(_win.innerWidth)
    except Exception:
        return False


def poll():
    """input the page caught itself (see _JS): a list of tuples, normally empty"""
    try:
        if _ready or install():
            raw = str(_win.RVPOP())
            if raw:
                import json
                return json.loads(raw)
    except Exception as e:
        ERR[0] = repr(e)[:60]
    return []


ERR = [""]
