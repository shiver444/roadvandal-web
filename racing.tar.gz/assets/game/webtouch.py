"""Phone helpers for the browser build: ask the phone to go sideways (Android) and tell whether it is held upright."""
try:
    import platform
    _win = platform.window
except Exception:
    _win = None

_JS = r"""
(function () {
  if (window.RVLAND) return;
  // backup input: some browsers (Safari) do not hand keys / clicks to the game engine, so we also catch them here
  var Q = [];
  function push(x) { Q.push(x); if (Q.length > 300) Q.shift(); }
  window.RVPOP = function () { if (!Q.length) return ""; var s = JSON.stringify(Q); Q = []; return s; };
  window.addEventListener('keydown', function (e) { if (e.code === 'Tab') e.preventDefault(); push(['kd', e.code]); }, true);
  window.addEventListener('keyup', function (e) { push(['ku', e.code]); }, true);
  window.addEventListener('blur', function () { push(['blur']); }, true);
  ['pointerdown', 'pointermove', 'pointerup', 'pointercancel'].forEach(function (n) {
    window.addEventListener(n, function (e) {
      if (n == 'pointermove' && e.pointerType == 'mouse' && e.buttons === 0) return;
      var c = document.getElementById('canvas');
      if (!c) return;
      var r = c.getBoundingClientRect();
      push([n, e.pointerId, e.pointerType, (e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]);
    }, true);
  });
  var st = document.createElement('style');
  st.textContent = 'html,body{margin:0;background:#000;overflow:hidden;height:100%}' +
    'canvas#canvas{position:fixed!important;left:0;top:0;margin:0!important;border:0!important;padding:0!important;background:#000}';
  document.head.appendChild(st);
  function fit() {
    var c = document.getElementById('canvas');
    if (!c) return;
    var w = window.innerWidth, h = window.innerHeight, k = Math.min(w / 700, h / 500);
    var ch = Math.floor(500 * k), cw = Math.min(w, Math.floor(700 * k * 1.3));   // stretch sideways a little so wide phones fill up
    c.style.width = cw + 'px'; c.style.height = ch + 'px';
    c.style.left = Math.floor((w - cw) / 2) + 'px'; c.style.top = Math.floor((h - ch) / 2) + 'px';
  }
  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', function () { setTimeout(fit, 150); });
  setInterval(fit, 700);
  fit();
  var tried = 0;
  function go() {
    try {
      var e = document.documentElement;
      var f = e.requestFullscreen || e.webkitRequestFullscreen;
      var lock = function () { try { screen.orientation.lock('landscape').catch(function () {}); } catch (x) {} };
      if (f && !document.fullscreenElement && !document.webkitFullscreenElement) {
        var p = f.call(e);
        if (p && p.then) p.then(lock).catch(function () {}); else lock();
      } else { lock(); }
    } catch (x) {}
    setTimeout(fit, 300);
  }
  function tap() { if (window.__rvfs) return; if (tried++ < 3) go(); }
  document.addEventListener('touchend', tap, true);
  document.addEventListener('click', tap, true);

  // tilt steering: the phone is turned like a steering wheel
  var T = window.RVT = {n: 0, b: 0, g: 0, on: false, st: '', box: null};
  function onori(e) { if (e.beta == null || e.gamma == null) return; T.n++; T.b = e.beta; T.g = e.gamma; }
  function startTilt() {
    if (T.on) return;
    T.on = true;
    var D = window.DeviceOrientationEvent;
    function add() { window.addEventListener('deviceorientation', onori, true); T.st = 'ok'; }
    try {
      if (D && typeof D.requestPermission === 'function') {
        D.requestPermission().then(function (r) { if (r === 'granted') add(); else { T.st = 'denied'; T.on = false; } })
          .catch(function () { T.st = 'denied'; T.on = false; });
      } else { add(); }
    } catch (x) { T.st = 'denied'; T.on = false; }
  }
  window.RVTILT = startTilt;
  function tiltTap(x, y) {   // iOS only allows the permission question inside a real tap: hit-test the box Python gave us
    var b = T.box, c = document.getElementById('canvas');
    if (!b || !c || T.on) return;
    var r = c.getBoundingClientRect(), nx = (x - r.left) / r.width, ny = (y - r.top) / r.height;
    if (nx >= b[0] && nx <= b[2] && ny >= b[1] && ny <= b[3]) startTilt();
  }
  document.addEventListener('touchend', function (e) { var t = e.changedTouches && e.changedTouches[0]; if (t) tiltTap(t.clientX, t.clientY); }, true);
  document.addEventListener('click', function (e) { tiltTap(e.clientX, e.clientY); }, true);
  window.RVWHEEL = function () {   // how far the phone is turned like a wheel, in degrees (clockwise +); 999 = no data yet, 998 = lying flat
    if (!T.n) return 999;
    var b = T.b * Math.PI / 180, g = T.g * Math.PI / 180;
    var ux = -Math.sin(g) * Math.cos(b), uy = Math.sin(b);
    var a = ((screen.orientation && screen.orientation.angle != null) ? screen.orientation.angle : (window.orientation || 0)) * Math.PI / 180;
    var v = ux * Math.sin(a) + uy * Math.cos(a), r = ux * Math.cos(a) - uy * Math.sin(a);
    if (Math.sqrt(v * v + r * r) < 0.25) return 998;
    return -Math.atan2(r, v) * 180 / Math.PI;
  };
  window.RVTBOX = function (a, b, c, d) { T.box = a < 0 ? null : [a, b, c, d]; };
  window.RVCOARSE = function () { try { return window.matchMedia('(pointer: coarse)').matches && (navigator.maxTouchPoints || 0) > 0; } catch (x) { return false; } };
  window.RVLAND = go;
})();
"""

_ready = False


def install():
    global _ready
    if _win is None or _ready:
        return _ready
    try:
        s = _win.document.createElement("script")
        s.text = _JS
        _win.document.head.appendChild(s)
        _ready = True
    except Exception as e:
        print("[touch] helper not available:", e)
    return _ready


def go_landscape():
    """call from a touch (the browser only allows fullscreen / rotation lock after a tap)"""
    try:
        if install():
            _win.RVLAND()
    except Exception:
        pass


def is_portrait():
    try:
        return _win is not None and float(_win.innerHeight) > float(_win.innerWidth)
    except Exception:
        return False


def poll():
    """input the page caught itself (see _JS): a list of tuples, normally empty"""
    try:
        if _ready or install():
            raw = str(_win.RVPOP())
            if raw:
                import json
                return json.loads(raw)
    except Exception as e:
        ERR[0] = repr(e)[:60]
    return []


ERR = [""]


def is_coarse():
    """a phone / tablet (touch is the main pointer)"""
    try:
        if _ready or install():
            return bool(_win.RVCOARSE())
    except Exception:
        pass
    return False


def tilt_start():
    try:
        if _ready or install():
            _win.RVTILT()
    except Exception:
        pass


def tilt_box(box):
    """screen part (x0, y0, x1, y1 as fractions) where a tap may start the sensor (iOS asks permission only inside a tap); None = nowhere"""
    try:
        if _ready or install():
            _win.RVTBOX(-1, 0, 0, 0) if box is None else _win.RVTBOX(*[float(v) for v in box])
    except Exception:
        pass


def wheel_deg():
    """phone turned like a wheel, degrees, clockwise +; 999 = no sensor data (yet), 998 = lying flat"""
    try:
        if _ready or install():
            return float(_win.RVWHEEL())
    except Exception:
        pass
    return 999.0
