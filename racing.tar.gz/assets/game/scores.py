"""Online high scores through Supabase (a small free database). Nothing here blocks the game:
a request runs in the background (a thread on the PC, the browser's fetch on the web) and poll() collects the answer.

Set SB_URL and SB_KEY in config.py. While they are empty the scoreboard is simply switched off."""
import json
import os
import sys
import threading

from . import config

WEB = sys.platform == "emscripten"
NAME_OK = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 _.!-"
NAME_MAX = 10

try:
    import platform
    _win = platform.window if WEB else None
except Exception:
    _win = None

_JS = r"""
(function () {
  if (window.RVSB) return;
  var res = {};
  function h(key, extra) {
    var o = { apikey: key };
    if (key.indexOf('eyJ') === 0) o.Authorization = 'Bearer ' + key;     // only the old JWT-style keys go in Authorization; sb_publishable_ keys do not
    for (var k in extra) o[k] = extra[k];
    return o;
  }
  window.RVSB = {
    get: function (id, url, key) {
      fetch(url, { headers: h(key, {}) })
        .then(function (r) { return r.ok ? r.text() : Promise.reject('HTTP ' + r.status); })
        .then(function (t) { res[id] = 'OK' + t; })
        .catch(function (e) { res[id] = 'ERR ' + e; });
    },
    post: function (id, url, key, body) {
      fetch(url, { method: 'POST', headers: h(key, { 'Content-Type': 'application/json', Prefer: 'return=minimal' }), body: body })
        .then(function (r) { res[id] = r.ok ? 'OK' : 'ERR HTTP ' + r.status; })
        .catch(function (e) { res[id] = 'ERR net'; });
    },
    take: function (id) { var v = res[id]; if (v === undefined) return ''; delete res[id]; return v; }
  };
})();
"""
_ready = [False]

# what the game reads
BOARD = {"key": None, "status": "idle", "rows": [], "age": 0}     # status: idle / loading / ok / error
SHAME = {"status": "idle", "rows": [], "age": 0}           # the Hall of Shame: furthest runs that did not finish
CHAMPS = {"status": "idle", "best": {}, "left": 0, "age": 0}    # the best run of each car
SEND = {"status": "idle", "age": 0}                               # status: idle / sending / ok / error
_pending = {}                                                      # request id -> kind ("board" / "send")
_seq = [0]
_lock = threading.Lock()
_done = {}                                                         # desktop threads put their answers here


def local_web():
    """True when the web build is served from this PC / home network (pygbag test server): private testing, never the public site"""
    try:
        h = str(_win.location.hostname) if WEB and _win is not None else ""
    except Exception:
        return False
    return h in ("localhost", "127.0.0.1") or h.startswith(("192.168.", "10."))


def preview():
    """the live site opened with ?preview=pinetrip: locked levels can be tried (no scores are sent). Not a security feature, just a private door."""
    try:
        return bool(WEB and _win is not None and "preview=pinetrip" in str(_win.location.search))
    except Exception:
        return False


def enabled():
    if local_web() or preview():
        return False
    if os.environ.get("RV_DEV"):                    # developer mode: test runs must never reach the live scoreboard
        return False
    return bool(getattr(config, "SB_URL", "") and getattr(config, "SB_KEY", ""))


def clean_name(s):
    s = "".join(ch for ch in str(s or "").upper() if ch in NAME_OK)
    return " ".join(s.split())[:NAME_MAX].strip()


def _install():
    if not WEB or _win is None:
        return False
    if _ready[0]:
        return True
    try:
        el = _win.document.createElement("script")
        el.text = _JS
        _win.document.head.appendChild(el)
        _ready[0] = True
    except Exception as e:
        print("[scores] page helper not available:", e)
    return _ready[0]


def _url(path):
    return config.SB_URL.rstrip("/") + "/rest/v1/" + path


def _start(kind, url, body=None):
    _seq[0] += 1
    rid = "r%d" % _seq[0]
    _pending[rid] = kind
    if WEB:
        if not _install():
            _finish(rid, "ERR no page helper")
            return rid
        try:
            if body is None:
                _win.RVSB.get(rid, url, config.SB_KEY)
            else:
                _win.RVSB.post(rid, url, config.SB_KEY, body)
        except Exception as e:
            _finish(rid, "ERR " + repr(e)[:40])
    else:
        threading.Thread(target=_thread, args=(rid, url, body), daemon=True).start()
    return rid


def _thread(rid, url, body):
    import urllib.request
    try:
        req = urllib.request.Request(url, data=body.encode("utf-8") if body is not None else None)
        req.add_header("apikey", config.SB_KEY)
        if config.SB_KEY.startswith("eyJ"):                 # only the old JWT-style keys go in Authorization
            req.add_header("Authorization", "Bearer " + config.SB_KEY)
        if body is not None:
            req.add_header("Content-Type", "application/json")
            req.add_header("Prefer", "return=minimal")
        with urllib.request.urlopen(req, timeout=10) as r:
            txt = r.read().decode("utf-8", "replace")
        out = "OK" + (txt if body is None else "")
    except Exception as e:
        out = "ERR " + repr(e)[:60]
    with _lock:
        _done[rid] = out


def _finish(rid, out):
    kind = _pending.pop(rid, None)
    ok = out.startswith("OK")
    if kind == "board":
        if ok:
            try:
                BOARD["rows"] = json.loads(out[2:])
                BOARD["status"] = "ok"
            except Exception:
                BOARD["status"] = "error"
        else:
            BOARD["status"] = "error"
            print("[scores] board:", out)
    elif kind == "shame":
        if ok:
            try:
                SHAME["rows"] = json.loads(out[2:])
                SHAME["status"] = "ok"
            except Exception:
                SHAME["status"] = "error"
        else:
            SHAME["status"] = "error"
            print("[scores] shame:", out)
    elif kind and kind.startswith("champ"):
        car = int(kind[5:])
        CHAMPS["left"] = max(0, CHAMPS["left"] - 1)
        if ok:
            try:
                rows = json.loads(out[2:])
                CHAMPS["best"][car] = rows[0] if rows else None
            except Exception:
                CHAMPS["status"] = "error"
        else:
            CHAMPS["status"] = "error"
        if CHAMPS["left"] == 0 and CHAMPS["status"] == "loading":
            CHAMPS["status"] = "ok"
    elif kind == "send":
        SEND["status"] = "ok" if ok else "error"
        if not ok:
            print("[scores] send:", out)


def poll():
    """call every frame"""
    if BOARD["status"] == "loading":
        BOARD["age"] += 1
        if BOARD["age"] > 60 * 12:
            BOARD["status"] = "error"
    if SHAME["status"] == "loading":
        SHAME["age"] += 1
        if SHAME["age"] > 60 * 12:
            SHAME["status"] = "error"
    if CHAMPS["status"] == "loading":
        CHAMPS["age"] += 1
        if CHAMPS["age"] > 60 * 12:
            CHAMPS["status"] = "error"
    if SEND["status"] == "sending":
        SEND["age"] += 1
        if SEND["age"] > 60 * 12:
            SEND["status"] = "error"
    if not _pending:
        return
    if WEB:
        for rid in list(_pending):
            try:
                v = str(_win.RVSB.take(rid))
            except Exception:
                v = ""
            if v:
                _finish(rid, v)
    else:
        with _lock:
            got = dict(_done)
            _done.clear()
        for rid, out in got.items():
            if rid in _pending:
                _finish(rid, out)


def load(level):
    """ask for the general board of a level: every car together (the rows come back through BOARD)"""
    if not enabled():
        return
    BOARD.update(key=level, status="loading", rows=[], age=0)
    q = "scores?select=name,car,time_ms,hits,created_at&level=eq.%d&order=time_ms.asc,hits.asc,created_at.asc&limit=80" % level
    _start("board", _url(q))


def load_shame(level):
    """the furthest runs that did not finish"""
    if not enabled():
        return
    SHAME.update(status="loading", rows=[], age=0)
    q = "shame?select=name,car,dist_m,cause,created_at&level=eq.%d&order=dist_m.desc,created_at.asc&limit=80" % level
    _start("shame", _url(q))


def send_shame(name, car, level, dist_m, cause):
    if not enabled():
        return
    SEND.update(status="sending", age=0)
    body = json.dumps({"name": clean_name(name), "car": int(car), "level": int(level), "dist_m": int(dist_m), "cause": clean_cause(cause)})
    _start("send", _url("shame"), body)


def clean_cause(s):
    s = "".join(ch for ch in str(s or "").upper() if ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 !.,'-")
    return " ".join(s.split())[:24].strip() or "WRECKED"


def top_shame(n=5):
    """(rank, name, dist_m, cause, car): each name once, with its furthest run"""
    seen, out = set(), []
    for r in SHAME["rows"]:
        nm = str(r.get("name", ""))
        k = nm.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append((len(out) + 1, nm, int(r.get("dist_m", 0)), str(r.get("cause", "")), int(r.get("car", 0))))
        if len(out) >= n:
            break
    return out


def shame_rank_of(name):
    seen = []
    for r in SHAME["rows"]:
        k = str(r.get("name", "")).lower()
        if k in seen:
            continue
        seen.append(k)
        if k == clean_name(name).lower():
            return len(seen)
    return 0


def load_champs(level, ncars):
    """ask for the best run of every car"""
    if not enabled():
        return
    CHAMPS.update(status="loading", best={}, left=ncars, age=0)
    for car in range(ncars):
        q = "scores?select=name,car,time_ms,hits,created_at&level=eq.%d&car=eq.%d&order=time_ms.asc,hits.asc,created_at.asc&limit=1" % (level, car)
        _start("champ%d" % car, _url(q))


def send(name, car, level, time_ms, hits):
    if not enabled():
        return
    SEND.update(status="sending", age=0)
    body = json.dumps({"name": clean_name(name), "car": int(car), "level": int(level), "time_ms": int(time_ms), "hits": int(hits)})
    _start("send", _url("scores"), body)


def top(n=10):
    """the board as (rank, name, time_ms, hits, car) rows: each name appears once (its best run, on any car)"""
    seen, out = set(), []
    for r in BOARD["rows"]:
        nm = str(r.get("name", ""))
        k = nm.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append((len(out) + 1, nm, int(r.get("time_ms", 0)), int(r.get("hits", 0)), int(r.get("car", 0))))
        if len(out) >= n:
            break
    return out


def rank_of(name, time_ms):
    """1-based place of this name on the (de-duplicated) board, or 0 when it is not in the fetched rows"""
    seen = []
    for r in BOARD["rows"]:
        k = str(r.get("name", "")).lower()
        if k in seen:
            continue
        seen.append(k)
        if k == clean_name(name).lower():
            return len(seen)
    return 0
