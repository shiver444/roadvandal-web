"""Procedural sound for the racer: no sound files needed, everything is synthesised at start-up.

    import audio
    a = audio.Audio()            # safe to create even when there is no sound card (it just stays silent)
    a.update(run, keys)          # call once per frame
    a.crash(0.7)                 # 0..1 severity
    a.chime()                    # checkpoint

Music: drop a file called music.ogg / music.mp3 / music.wav next to the game and it will loop in the background.
Keys handled by the game: M toggles all sound.
"""
import array
import math
import os
import threading
import time
import sys
import random

import pygame

try:
    from . import webaudio as WA
except Exception:
    WA = None

RATE = 22050
WEB = sys.platform == "emscripten"
SLOW_CONVERT = False
WEBA = False                        # True in the browser when the browser's own audio system (webaudio.py) is in use
NOTE = lambda msg: None             # main.py replaces this to show start-up progress on the loading screen
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "assets")      # music, engine loops, sfx live here (files in the project folder itself or any sub-folder are found too)
_SKIP = {"game", "venv", ".venv", ".git", ".idea", "__pycache__", "tools", "build"}


def _walk_all():
    """(folder, files) for assets/ first, then the whole project folder, a few levels deep"""
    for base in (ASSETS, ROOT):
        for root, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if d not in _SKIP]
            if root[len(base):].count(os.sep) > 3:
                dirs[:] = []
            yield root, files


_FOUND = {}


def _find_file(name):
    if name in _FOUND:
        return _FOUND[name]
    for root, files in _walk_all():
        if name in files:
            _FOUND[name] = os.path.join(root, name)
            return _FOUND[name]
    return None


ENGINE_FILE = "engine_loops.wav"      # 48 seamless loops cut from the reference engine recording
ENGINE_LENS = [6597, 6606, 6540, 6600, 6616, 6568, 6572, 6582, 6680, 6639, 6633, 6567, 6644, 6556, 6600, 6560, 6579, 6647, 6583, 6606, 6563, 6604, 6584, 6627, 6641, 6661, 6651, 6563, 6605, 6586, 6554, 6553, 6571, 6541, 6560, 6550, 6582, 6642, 6660, 6672, 6564, 6578, 6592, 6600, 6640, 6564, 6654, 6574]


ENGINE_YUGO_FILE = "engine_yugo.wav"  # the Yuggo's own engine: loops cut from its acceleration recording
ENGINE_YUGO_LENS = [6615, 6615, 6533, 6643, 6557, 6658, 6578, 6671, 6596, 6682, 6611, 6546, 6625, 6563, 6637, 6578, 6648, 6591, 6657, 6604, 6666, 6615, 6668, 6625, 6583, 6643, 6603, 6661, 6622, 6584, 6639, 6602, 6655, 6619, 6585, 6635, 6602, 6650, 6617, 6586, 6632, 6601, 6646, 6616, 6587, 6629, 6601, 6642]
ENGINE_ZAPPO_FILE = "engine_zappo.wav"  # the little electric car: loops cut from a golf-cart acceleration recording
ENGINE_ZAPPO_LENS = [6615, 6615, 6615, 6615, 6533, 6582, 6627, 6669, 6568, 6609, 6647, 6556, 6594, 6629, 6662, 6581, 6614, 6644, 6571, 6601, 6630, 6657, 6590, 6617, 6643, 6581, 6606, 6630, 6654, 6597, 6620, 6642, 6588, 6610, 6631, 6580, 6601, 6621, 6641, 6594, 6613, 6631, 6587, 6605, 6623, 6640, 6598, 6615]
ENGINE_NOCT_FILE = "engine_nocturnal.wav"  # the NOCTURNAL GT: loops cut from a V8 sports-car acceleration recording
ENGINE_NOCT_LENS = [6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6600, 6168, 5739, 5322, 4925]
ENGINES = [(ENGINE_FILE, ENGINE_LENS, 7, (40, 40)), (ENGINE_YUGO_FILE, ENGINE_YUGO_LENS, 7, (40, 40)), (ENGINE_ZAPPO_FILE, ENGINE_ZAPPO_LENS, 7, (40, 40)), (ENGINE_FILE, ENGINE_LENS, 7, (40, 40), 1.32), (ENGINE_YUGO_FILE, ENGINE_YUGO_LENS, 7, (40, 40), 1.22), (ENGINE_NOCT_FILE, ENGINE_NOCT_LENS, 7, (40, 40))]      # per car (same order as CARS): file, loop lengths, frames a loop plays before the next may take over, crossfade ms
ENGINE_DWELL = 7                 # frames a loop plays before the next one may take over (faster switching stutters)

MIX_RATE = 44100
HOLD_T = 14                      # frames the engine takes to come back up after a hit
CRASH_CUT = 22                   # frames of silence after a hit before the engine restarts
ALL_STATIONS = [("DARK.FM", "MianN - Never Alone", "music"), ("NOISE RADIO", "Fuck The Facts - L'abandon", "ftf_labandon"), ("HAUNTED RADIO", "Nothing but screaming", "haunted_radio"),
                ("OVERPLAYED.FM", "Miss Artificial - Intelligence", "overplayed"), ("BEACH RADIO", "Generic Ska Punks - We are lame", "beach_radio")]     # every station there is: (station, track shown, file name without extension)
STATIONS = ALL_STATIONS[:3]                                      # the ones on the dial in the current level (see use_stations)


def use_stations(files):
    """the dial of a level: a list of track file names (a level without a list keeps the first three stations)"""
    STATIONS[:] = [st for f in files for st in ALL_STATIONS if st[2] == f] if files else ALL_STATIONS[:3]

TRACK_SECS = {"vicious_dance": 262.5, "music": 196.1, "ftf_labandon": 127.5, "haunted_radio": 100.0, "overplayed": 177.5, "quick_fix": 272.6, "beach_radio": 115.9}      # lengths, so every station can keep "broadcasting" while you listen to another
TRACK_PARTS = {"beach_radio": [(0.0, "ADVERTS"), (2.8, None), (98.4, "ADVERTS")]}                        # (from second, title shown): the song, then the ads after it
EVENT_TRIM = {"tyre_screech": 0.30, "tyre_screech_uw": 0.43, "car_annoyed1": 0.36, "car_annoyed2": 0.35, "car_annoyed3": 0.33,
              "car_annoyed_uw1": 0.65, "car_annoyed_uw2": 0.67, "car_annoyed_uw3": 0.58,
              "gull_flock": 0.8, "gull_angry": 0.8, "splash_marlin": 0.9, "splash_fish": 0.7, "divers": 0.9, "splash_car": 0.9, "fish_slap": 0.8, "foghorn": 0.7, "wall_scrape": 0.8, "coconut_hit": 0.9, "surfer_taunt": 0.9, "surfer_hit": 0.9, "crab_click": 0.7, "ball_bounce": 0.7, "kid_shout": 0.8, "thunder": 0.9}      # loudness-matched: music loudest, effects in the middle, engine quietest
MUSIC_VOL = 0.68                 # background track: the loudest thing in the mix (music.mp3 / .ogg / .wav next to the game)
ENGINE_GAIN = 0.30               # the engine sits well under the music and the effects (the engine slider scales this, 7 = this mix)


def _load_sfx(path):
    """a sound file as a Sound. In the browser the mixer runs at 48000 Hz and the files are 44100 Hz: convert them here, carefully,
    instead of leaving it to the browser's own (rough) converter"""
    if WEBA:
        return WA.Sound(path=path)
    if not WEB:
        return pygame.mixer.Sound(path)
    try:
        with open(path, "rb") as fh:
            blob = fh.read()
        f = blob.find(b"fmt ")
        ch = int.from_bytes(blob[f + 10:f + 12], "little")
        rate = int.from_bytes(blob[f + 12:f + 16], "little")
        bits = int.from_bytes(blob[f + 22:f + 24], "little")
        d = blob.find(b"data")
        size = int.from_bytes(blob[d + 4:d + 8], "little")
        if bits != 16 or ch not in (1, 2) or rate == MIX_RATE:
            return pygame.mixer.Sound(path)
        pcm = array.array("h")
        pcm.frombytes(blob[d + 8:d + 8 + size - size % (2 * ch)])
        frames = len(pcm) // ch
        m = int(round(frames * MIX_RATE / float(rate)))
        step = frames / float(m)
        sides = []
        for c in range(ch):
            src = pcm[c::ch]
            vals = []
            last = frames - 1
            for j in range(m):
                q = j * step
                i = int(q)
                a = src[i]
                vals.append(int(a + (src[i + 1 if i < last else last] - a) * (q - i)))
            sides.append(array.array("h", vals))
        out = array.array("h", bytes(m * 4))
        out[0::2] = sides[0]
        out[1::2] = sides[-1]
        return pygame.mixer.Sound(buffer=out.tobytes())
    except Exception as e:
        print("[audio] own conversion failed for", path, e)
        return pygame.mixer.Sound(path)


def _sync_rate():
    """sounds are built for whatever rate the mixer really runs at"""
    global MIX_RATE
    got = pygame.mixer.get_init()
    if got and got[0] > 0:
        MIX_RATE = got[0]


def _sound(samples):
    """samples are 22050 Hz mono; convert to the mixer's 44100 Hz stereo (linear interpolation)"""
    n = len(samples)
    if WEBA:
        return WA.Sound(pcm=samples, rate=RATE, ch=1)
    if MIX_RATE != 44100:                           # the browser runs its sound at 48000 Hz: build the buffer for the rate the mixer really has
        m = max(1, int(round(n * MIX_RATE / float(RATE))))
        step = n / float(m)
        vals = []
        for j in range(m):
            q = j * step
            i = int(q)
            a = samples[i]
            vals.append(int(a + (samples[(i + 1) % n] - a) * (q - i)))
        v = array.array("h", vals)
        out = array.array("h", bytes(m * 4))
        out[0::2] = v
        out[1::2] = v
        return pygame.mixer.Sound(buffer=out.tobytes())
    if SLOW_CONVERT:                                # plain loop, kept in case the fast conversion misbehaves somewhere (slower to start, but the way that was known to work there)
        out = array.array("h", bytes(n * 8))
        for i in range(n):
            a = samples[i]
            b = (a + samples[(i + 1) % n]) // 2
            j = i * 4
            out[j] = out[j + 1] = a
            out[j + 2] = out[j + 3] = b
    else:
        a = array.array("h", samples)
        b = array.array("h", [(a[i] + a[(i + 1) % n]) // 2 for i in range(n)])
        out = array.array("h", bytes(n * 8))
        out[0::4] = a                                   # slice copies: far cheaper than a Python loop per sample (matters in the browser)
        out[1::4] = a
        out[2::4] = b
        out[3::4] = b
    return pygame.mixer.Sound(buffer=out.tobytes())


def _clip(v):
    return max(-32000, min(32000, int(v)))


def _engine_loop(freq, cycles_len=0.25, grit=0.0):
    """one seamless engine loop: fundamental plus harmonics so it growls rather than whines"""
    n = int(RATE * cycles_len)
    cycles = max(1, round(freq * cycles_len))
    f = cycles / cycles_len                      # exact integer number of cycles -> loops without a click
    rnd = random.Random(int(freq * 10))
    out = []
    weights = (1.0, 0.75, 0.62, 0.5, 0.34, 0.26, 0.18, 0.12)
    for i in range(n):
        t = i / RATE
        v = 0.0
        for h, w in enumerate(weights, start=1):
            v += w * math.sin(2 * math.pi * f * h * t + h * 0.6)
        # firing pulses: a low square-ish rumble at half the frequency
        v += 0.5 * math.sin(2 * math.pi * f * 0.5 * t)
        v += grit * (rnd.random() - 0.5)
        out.append(_clip(v * 2600))
    return _sound(out)


def _noise(seconds, lowpass=0.0, gain=1.0, seed=1):
    n = int(RATE * seconds)
    rnd = random.Random(seed)
    out = []
    y = 0.0
    for _ in range(n):
        x = rnd.random() * 2 - 1
        y = y + (x - y) * (1.0 - lowpass) if lowpass else x
        out.append(_clip(y * 9000 * gain))
    # crossfade the ends so the loop is seamless
    k = int(RATE * 0.03)
    for i in range(k):
        a = i / k
        out[i] = _clip(out[i] * a + out[n - k + i] * (1 - a))
    return _sound(out[: n - k])


def _crash(seconds=0.55):
    n = int(RATE * seconds)
    rnd = random.Random(7)
    out = []
    for i in range(n):
        t = i / RATE
        env = math.exp(-t * 7.0)
        thump = math.sin(2 * math.pi * (70 - 40 * t) * t) * env * 1.0
        crunch = (rnd.random() * 2 - 1) * math.exp(-t * 11.0) * 0.8
        out.append(_clip((thump + crunch) * 22000))
    return _sound(out)


def _tone(freqs, seconds, vol=0.35, decay=3.0):
    n = int(RATE * seconds)
    out = []
    for i in range(n):
        t = i / RATE
        v = sum(math.sin(2 * math.pi * f * t) for f in freqs) / len(freqs)
        out.append(_clip(v * math.exp(-t * decay) * 32000 * vol))
    return _sound(out)


def _chime():
    notes = (660, 880, 1320)
    seg = int(RATE * 0.12)
    out = []
    for k, f in enumerate(notes):
        for i in range(seg * 2 if k == len(notes) - 1 else seg):
            t = i / RATE
            out.append(_clip(math.sin(2 * math.pi * f * t) * math.exp(-t * 6) * 14000))
    return _sound(out)


def _engine_from_file(fname=ENGINE_FILE, lens=ENGINE_LENS, slow=1.0):
    """the loops (rising rev) cut from a reference recording; None if the file is missing"""
    path = _find_file(fname)
    if not path:
        return None
    with open(path, "rb") as fh:                      # plain 16-bit mono wav: find the "data" chunk (no wave module: the web build can't install it)
        blob = fh.read()
    i = blob.find(b"data")
    n_bytes = int.from_bytes(blob[i + 4:i + 8], "little")
    raw = blob[i + 8:i + 8 + n_bytes]
    samples = array.array("h")
    samples.frombytes(raw)
    out, pos = [], 0
    for n in lens:
        loop = list(samples[pos:pos + n])
        if slow != 1.0:                                    # a deeper engine: stretch every loop (lower pitch), loop by loop so the joins stay seamless
            m = int(n * slow)
            loop = [loop[min(n - 1, int(i / slow))] for i in range(m)]
        out.append(_sound(loop))
        pos += n
    return out


def _ev_engine(levels=40, seconds=0.30):
    """the electric car: no engine, just a motor whine that climbs with speed (built in code, no recording needed)"""
    out = []
    rnd = random.Random(77)
    for i in range(levels):
        f = 190.0 + 1150.0 * (i / float(levels - 1)) ** 1.15
        k = max(1, round(seconds * f))                       # whole cycles per loop, so it repeats without a click
        n = int(round(k * RATE / f))
        fe = k * RATE / float(n)
        buf = []
        for j in range(n):
            t = j / RATE
            v = (math.sin(2 * math.pi * fe * t) + 0.34 * math.sin(2 * math.pi * 2 * fe * t + 0.6) + 0.12 * math.sin(2 * math.pi * 3 * fe * t + 1.9)
                 + 0.16 * math.sin(2 * math.pi * 5 * fe * t + 0.2))
            buf.append(_clip(v * 3400))
        out.append(_sound(buf))
    return out


def _bell():
    """level-crossing bell: two dings per second"""
    n = RATE
    out = [0] * n
    for start in (0, n // 2):
        for i in range(int(RATE * 0.45)):
            t = i / RATE
            v = (math.sin(2 * math.pi * 1760 * t) + 0.6 * math.sin(2 * math.pi * 2637 * t + 1) +
                 0.3 * math.sin(2 * math.pi * 3520 * t)) * math.exp(-t * 7.0)
            out[(start + i) % n] += _clip(v * 9000)
    return _sound([_clip(v) for v in out])


def _spook(seconds=1.1):
    """a cold 'wooOOoo' for driving through a ghost: falling pitch, wobble, a breath of noise"""
    n = int(RATE * seconds)
    out = []
    rnd = random.Random(12)
    ph = 0.0
    for i in range(n):
        t = i / RATE
        f = 620.0 * math.exp(-t * 1.1) + 150.0 + 18.0 * math.sin(2 * math.pi * 6.0 * t)
        ph += 2 * math.pi * f / RATE
        env = math.sin(math.pi * min(1.0, t / seconds)) ** 0.7
        v = (math.sin(ph) + 0.4 * math.sin(2 * ph + 0.7) + 0.25 * (rnd.random() * 2 - 1)) * env
        out.append(_clip(v * 7500))
    return _sound(out)


def _thunder(seconds=2.6):
    """a rolling clap: a crack, then a low rumble that dies away"""
    n = int(RATE * seconds)
    rnd = random.Random(11)
    out = []
    y = 0.0
    for i in range(n):
        t = i / RATE
        x = rnd.random() * 2 - 1
        lp = 0.80 if t < 0.12 else 0.985
        y = y + (x - y) * (1.0 - lp)
        env = (1.0 if t < 0.1 else 0.55 + 0.45 * math.sin(t * 7.0) ** 2) * (1.0 - t / seconds) ** 1.6
        gain = 2.2 if t < 0.12 else 9.0
        out.append(_clip(y * 9000 * gain * env))
    return _sound(out)


def _squeak(seconds=0.3):
    """a bat hitting the windscreen: a couple of high chirps and a flutter"""
    n = int(RATE * seconds)
    out = []
    rnd = random.Random(5)
    ph = 0.0
    for i in range(n):
        t = i / RATE
        f = (4200.0 - 2600.0 * ((t * 9.0) % 1.0)) * (1.0 - 0.3 * t / seconds)
        ph += 2 * math.pi * f / RATE
        env = (1.0 - t / seconds) ** 1.3 * (0.6 + 0.4 * math.sin(2 * math.pi * 28 * t))
        out.append(_clip((math.sin(ph) * 0.8 + 0.2 * (rnd.random() * 2 - 1)) * env * 8000))
    return _sound(out)


def _horn(seconds=1.3):
    n = int(RATE * seconds)
    out = []
    for i in range(n):
        t = i / RATE
        env = min(1.0, t / 0.05) * (1.0 if t < seconds - 0.25 else max(0.0, (seconds - t) / 0.25))
        v = 0.0
        for f in (233.0, 293.7, 349.2):                              # a heavy minor-ish triad
            ph = (f * t) % 1.0
            v += (2 * ph - 1) * 0.7 + math.sin(2 * math.pi * f * t) * 0.5
        out.append(_clip(v * env * 5200))
    return _sound(out)


HIT_FILES = ("cone", "barrier", "person", "animal", "cat", "car", "sideswipe", "tree", "sign", "boar", "piglet")
HIT_FALLBACK = {"tree": "barrier", "sign": "cone", "boar": "animal", "piglet": "boar"}      # used until hit_tree / hit_sign exist
HIT_GAIN = {"cone": 0.75, "tree": 1.0, "sign": 0.9, "barrier": 1.0, "person": 0.95, "animal": 0.40, "cat": 0.27, "car": 1.0, "sideswipe": 0.41, "boar": 0.34, "piglet": 0.32}      # (the animal / cat / boar / piglet / sideswipe recordings are very hot: trimmed so effects sit under the music)
HIT_KIND = {"zombie": "cone", "bat": "cat", "tomb": "barrier", "ghoul": "person", "costume": "person", "coffin": "barrier", "pumpkin": "cone", "gravestone": "tree", "witch": "person",
            "cone": "cone", "barrier": "barrier", "worker": "person", "smoker": "person", "sleeper": "person",
            "ped": "person", "kid": "person", "deer": "animal", "cat": "cat", "train": "barrier",
            "rear": "car", "side": "sideswipe", "pine": "tree", "deadtree": "tree", "rock": "tree", "log": "tree",
            "lamp": "sign", "sign": "sign", "xcar": "car", "faltree": "tree", "maple": "tree", "boar": "boar", "piglet": "piglet", "emv": "car", "gull": "cat", "diver": "person", "marlin": "animal", "crab": "cone", "surfer": "person", "ball": "cone", "bkid": "person", "umbr": "cone"}


def _load_ghost_train():
    """the ghostly whisper laid over the train: any wav with 'ghost_train' in its name, next to the game / in sfx / below"""
    for root, files in _walk_all():
        for fn in files:
            low = fn.lower()
            if "ghost_train" in low and low.endswith((".wav", ".ogg")):
                try:
                    snd = WA.Sound(path=os.path.join(root, fn)) if WEBA else pygame.mixer.Sound(os.path.join(root, fn))
                    print("[audio] ghost train overlay loaded:", fn)
                    return snd
                except Exception as e:
                    print("[audio] could not load", fn, e)
    print("[audio] no ghost_train*.wav found - the ghost train runs without its whisper")
    return None


def _load_hits():
    """finds hit_<name>.wav / .ogg next to the game, in an sfx folder, or anywhere below the game folder"""
    found = {}
    for root, files in _walk_all():
        for fn in files:
            low = fn.lower()
            if low.startswith("hit_") and low.endswith((".wav", ".ogg")):
                name = low[4:].rsplit(".", 1)[0]
                if name in HIT_FILES and name not in found:
                    found[name] = os.path.join(root, fn)
    out = {}
    for name, path in found.items():
        try:
            out[name] = _load_sfx(path)
        except Exception as e:
            print("[audio] could not load", path, e)
    print("[audio] hit sounds loaded: %d/%d  %s" % (len(out), len(HIT_FILES), sorted(out)))
    return out


def _load_trip_voices():
    """voices that drift in while you are tripping: trip_voice1.ogg ... trip_voice8.ogg (or .wav) anywhere in the assets.
    each one is loaded three times so its echoes can play over the original"""
    out = []
    for i in range(1, 9):
        for ext in (".ogg", ".wav"):
            path = _find_file("trip_voice%d%s" % (i, ext))
            if path:
                try:
                    out.append(tuple(_load_sfx(path) for _ in range(3)))
                except Exception as e:
                    print("[audio] trip voice failed", path, e)
                break
    print("[audio] trip voices loaded: %d" % len(out))
    return out


def _load_named(name):
    """one sound file by name (.ogg or .wav) from the assets, or None"""
    for ext in (".ogg", ".wav"):
        path = _find_file(name + ext)
        if path:
            try:
                return _load_sfx(path)
            except Exception as e:
                print("[audio] could not load", name, e)
    print("[audio] %s not found" % name)
    return None


class _Loop:
    """browser build: a looping effect channel that only plays while it is audible (silent loops cost mixing time and can leak noise)"""
    def __init__(self, ch):
        self.ch, self.snd, self.on = ch, None, False

    def play(self, snd, loops=-1):
        self.snd = snd                                # remembered; it starts when the volume goes up

    def set_volume(self, v):
        if v <= 0.01:
            if self.on:
                self.ch.stop()
                self.on = False
            return
        if not self.on and self.snd is not None:
            self.ch.set_volume(v)
            self.ch.play(self.snd, loops=-1)
            self.on = True
        self.ch.set_volume(v)

    def stop(self):
        self.set_volume(0.0)

    def fadeout(self, ms):
        self.set_volume(0.0)

    def get_busy(self):
        return self.on


def _mxchan(i):
    return WA.Channel(i) if WEBA else pygame.mixer.Channel(i)


def _chan(i):
    ch = WA.Channel(i) if WEBA else pygame.mixer.Channel(i)
    return _Loop(ch) if WEB else ch


class Audio:
    VARIANTS = len(ENGINE_LENS)          # replaced per instance by the number of loops of the chosen car

    def __init__(self):
        global WEBA
        WEBA = bool(WEB and WA is not None and WA.install())      # in the browser: use the browser's own audio system
        if WEB:
            NOTE("browser audio: %s" % ("on" if WEBA else "off, using pygame"))
        self.ok = False
        self.muted = False                # game sounds off
        self.music_off = False
        self.cur = -1
        self.chan_i = 0
        try:
            # pygame.init() may already have opened the mixer in another format; reopen it the way we synthesise
            if WEB and pygame.mixer.get_init():                       # browser: keep the stream it already opened (reopening it with any buffer but 512 crashes the page)
                pass
            elif pygame.mixer.get_init() != (MIX_RATE, -16, 2):
                pygame.mixer.quit()
                pygame.mixer.init(MIX_RATE, -16, 2, 512)             # (bigger buffers crash the browser build)
            _sync_rate()
            print("[audio] mixer format (rate, bits, channels):", pygame.mixer.get_init())
            NOTE("mixer %s" % (pygame.mixer.get_init(),))
            pygame.mixer.set_num_channels(15)
            pygame.mixer.set_reserved(9)                  # channels 0-7 are ours (engine, loops, rain), 8 is the web music; one-shots use 9+
            self._build()
            self.ok = True
            if not WEB:
                threading.Thread(target=self._preload, daemon=True).start()
        except Exception:
            self.ok = False

    def _build(self):
        NOTE("audio: engine 1")
        self.engines = [None] * len(ENGINES)           # built when a car is first used (loading all three takes long in a browser)
        self.engine = None
        self.engine0 = self._load_engine(0)
        if self.engine0 is None:                      # no engine_loops.wav next to the game: fall back to synthesis
            self.engine0 = [_engine_loop(36 + 11.5 * i, grit=0.5) for i in range(16)]
        self.engines[0] = self.engine0
        self.VARIANTS = len(self.engine0)
        self.set_car(0)
        NOTE("audio: engine ok, building sounds")
        self.gravel = _noise(1.0, lowpass=0.35, gain=0.9, seed=3)
        self.wind = _noise(1.0, lowpass=0.88, gain=1.6, seed=4)
        self.screech = _noise(0.5, lowpass=0.0, gain=0.45, seed=5)
        self.crash_snd = _crash()
        self.beep = _tone((880,), 0.18, 0.3, 8)
        self.go_beep = _tone((1320,), 0.5, 0.35, 3)
        self.tick = _tone((1100,), 0.06, 0.3, 40)
        self.chime_snd = _chime()
        self.pop = _tone((180,), 0.07, 0.4, 30)
        self.chans = [_mxchan(0), _mxchan(1)]
        self.c_gravel = _chan(2)
        self.c_wind = _chan(3)
        self.c_screech = _chan(4)
        self.c_gravel.play(self.gravel, loops=-1)
        self.c_wind.play(self.wind, loops=-1)
        self.c_screech.play(self.screech, loops=-1)
        for c in (self.c_gravel, self.c_wind, self.c_screech):
            c.set_volume(0.0)
        NOTE("audio: effects ok, loading hit sounds")
        self.last_cd = -1
        self.last_gear = 0
        self.last_tick = -1
        self.hits = _load_hits()
        self.trip_voices = _load_trip_voices()
        self.trip_spirit = _load_named("trip_spirit")        # the spiritual bed: starts when the mushroom kicks in, loops until the trip ends
        self.trip_police = _load_named("trip_police")        # police radio chatter around the police stop just outside the tunnel
        self.rain_snd = _load_named("storm_rain")             # island storm: rain and wind loops, louder as the storm builds
        self.wind_snd = _load_named("wind_gust")
        self.rain_on = self.wind_on = False
        self.tunnel_snd = _load_named("tunnel_loop")           # the roar inside the tunnel, looped while you are in it
        self.events = {}                                      # one-shot level sounds by name (tree_fall, log_fall, car_annoyed1..3)
        for n_ in ("tree_fall", "log_fall", "car_annoyed1", "car_annoyed2", "car_annoyed3", "car_annoyed_uw1", "car_annoyed_uw2", "car_annoyed_uw3", "tyre_screech", "tyre_screech_uw", "tractor_horn", "tractor_horn_uw", "gull_flock", "gull_angry", "splash_marlin", "splash_fish", "divers", "splash_car", "fish_slap", "foghorn", "wall_scrape", "coconut_hit", "surfer_taunt", "surfer_hit", "crab_click", "ball_bounce", "kid_shout", "thunder", "bridge_crack", "bridge_fall", "sand_whoosh", "treasure_pickup", "gull_hit", "marlin_hit"):
            self.events[n_] = _load_named(n_)
        self.hit_trip = _load_named("hit_trip")             # while tripping every crash and knock is this one echoing, woozy sound
        self.tun_on = False
        self.tractor_snd = _load_named("tractor_loop")        # a tractor's engine, looped while one is near
        self.tractor_on = False
        self.spirit_on = False
        self.radio_on = False
        self.radio_done = False
        self.n_ch = 15
        self.tv_next = 0
        self.tv_echo = []
        self.bell = _bell()
        self.horn = _horn()
        self.spook_snd = _spook()
        self.squeak_snd = _squeak()
        self.rumble = _noise(1.0, lowpass=0.93, gain=2.2, seed=9)
        self.c_bell = _chan(5)
        self.c_rumble = _chan(6)
        self.c_bell.play(self.bell, loops=-1)
        self.c_rumble.play(self.rumble, loops=-1)
        self.c_bell.set_volume(0.0)
        self.c_rumble.set_volume(0.0)
        self.rain_snd = _noise(1.5, lowpass=0.55, gain=0.7, seed=21)
        self.thunder_snd = _thunder()
        self.c_rain = _chan(7)
        self.c_rain.play(self.rain_snd, loops=-1)
        self.c_rain.set_volume(0.0)
        NOTE("audio: more sounds ok, ghost train")
        self.horned = False
        self.ghost_snd = _load_ghost_train()
        self.ghost_on = False
        self.ghost_ch = None
        self.last_hit = ""
        self.rev = 0.0
        self.dip = 0
        self.duck = 0.0
        self.hold = 0.0
        self.pre = 0.0
        self.holdt = 0
        self.sw = 99
        self.go_played = False
        self.dwell, self.fade = ENGINES[0][2:4]
        NOTE("audio: ready")
        self.music_started = False
        self.music_ended = False
        self.track = "music"                 # file name (without extension) of the current level's music

    def _load_engine(self, i):
        e = ENGINES[i]
        return _ev_engine() if e[0] == "synth:ev" else _engine_from_file(e[0], e[1], e[4] if len(e) > 4 else 1.0)

    def set_car(self, i):
        """each car has its own engine loops"""
        if not getattr(self, "engines", None):
            return
        i %= len(self.engines)
        if self.engines[i] is None:
            self.engines[i] = self._load_engine(i) or self.engine0      # a missing recording falls back to the first car's
        eng = self.engines[i]
        if eng is not self.engine or self.VARIANTS != len(eng):
            self.engine = eng
            self.VARIANTS = len(eng)
            self.dwell, self.fade = ENGINES[i % len(ENGINES)][2:4]
            self.cur = -1

    # ---- background music. In the browser pygame's music player is unreliable, so there the track is a normal Sound on its own channel
    _msnd = {}

    def _music_sound(self, path):
        """decoded track, kept in memory (the PC decodes all stations in the background at start, so switching is instant)"""
        if path not in self._msnd:
            self._msnd[path] = WA.Sound(path=path) if WEBA else pygame.mixer.Sound(path)
        return self._msnd[path]

    dark_file = "music"                               # what DARK.FM plays: set per level by the engine
    music_uw = False
    tripping = False

    def _preload(self):
        for name in [st[-1] for st in ALL_STATIONS] + ["vicious_dance", "quick_fix"] + ([] if WEB else ["music_uw", "vicious_dance_uw", "overplayed_uw"]):
            for e in (".ogg", ".mp3", ".wav"):
                p = _find_file(name + e)
                if p:
                    try:
                        self._music_sound(p)
                    except Exception:
                        pass
                    break

    def radio_secs(self, key):
        """how many seconds into its track a station is right now (for titles that change inside one file)"""
        return self._radio_frac(key + ".ogg") * (TRACK_SECS.get(key) or 100.0)

    def _radio_frac(self, path):
        """where this station is in its track right now (0..1): every station keeps playing in the background, like a real radio"""
        key = os.path.splitext(os.path.basename(path))[0]
        if key.endswith("_uw"):                            # the underwater version of a track is the same broadcast
            key = key[:-3]
        if not hasattr(self, "_r0"):
            self._r0, self._t0 = {}, time.monotonic()
        if key not in self._r0:
            self._r0[key] = random.random()
        secs = TRACK_SECS.get(key) or 100.0
        return (self._r0[key] + (time.monotonic() - self._t0) / secs) % 1.0

    def _m_play(self, path):
        if True:                                           # music plays as an ordinary sound on its own channel (instant to switch)
            self.music_snd = self._music_sound(path)
            self.music_ch = _mxchan(8)
            frac = self._radio_frac(path)
            if WEBA:
                self.music_ch.play(self.music_snd, loops=-1, frac=frac)
            else:
                # start in the middle of the track (the same track, rotated). Copying the whole decoded song takes a moment,
                # so it is done in a background thread and the music joins in as soon as it is ready: no hitch in the game
                self._mtok = getattr(self, "_mtok", 0) + 1
                tok, src, ch = self._mtok, self.music_snd, self.music_ch

                def _rot():
                    snd = src
                    try:
                        raw = src.get_raw()
                        fr, fmt, chs = pygame.mixer.get_init()
                        fb = chs * (abs(fmt) // 8)
                        n = int(frac * (len(raw) // fb)) * fb
                        snd = pygame.mixer.Sound(buffer=raw[n:] + raw[:n])
                    except Exception:
                        pass
                    if tok != self._mtok:                  # another station was picked (or the music stopped) meanwhile
                        return
                    self.music_snd = snd
                    ch.play(snd, loops=-1)
                    ch.set_volume(0.0 if self.music_off else self._mvol())
                import threading
                threading.Thread(target=_rot, daemon=True).start()
                self.music_on = True
                return
            self.music_ch.set_volume(0.0 if self.music_off else self._mvol())       # (after play: play starts at full volume)
        else:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(0.0 if self.music_off else self._mvol())
            pygame.mixer.music.play(-1)
        self.music_on = True

    def _m_stop(self):
        if not getattr(self, "music_on", False):
            return
        self.music_on = False
        self._mtok = getattr(self, "_mtok", 0) + 1                  # cancels a track that is still being prepared
        if True:
            self.music_ch.stop()
        else:
            pygame.mixer.music.stop()

    def _m_vol(self, v):
        if True:
            if getattr(self, "music_ch", None) is not None:
                self.music_ch.set_volume(v)
        else:
            pygame.mixer.music.set_volume(v)

    def _m_fade(self, ms):
        if not getattr(self, "music_on", False):
            return
        self.music_on = False
        if True:
            self.music_snd.fadeout(ms)
        else:
            pygame.mixer.music.fadeout(ms)

    station = 0

    def next_station(self):
        """radio button: switch to the next track (only a track change, the rest of the sound stays)"""
        self.station = (self.station + 1) % len(STATIONS)
        if self.ok and getattr(self, "music_started", False):
            try:
                self._m_stop()
                self._music(True)
            except Exception:
                pass
        return self.station

    def _music(self, start):
        self.track = STATIONS[self.station % len(STATIONS)][2]
        if self.track == "music":                          # DARK.FM plays a different song in each level
            self.track = self.dark_file
        names = [self.track + e for e in (".ogg", ".mp3", ".wav")] + ["music.ogg", "music.mp3", "music.wav"]
        if self.music_uw:                                  # tripping: the muffled, echoing, wobbling underwater version of the same track (falls back to the normal one)
            names = [self.track + "_uw.ogg"] + names
        for name in names:
            path = _find_file(name)
            if path:
                try:
                    self._m_play(path)
                except Exception:
                    pass
                return

    v_music = v_fx = 1.0                             # the three volume sliders (1.0 = the default mix: music loudest, then effects, then engine)
    v_engine = ENGINE_GAIN

    def _mvol(self):
        return min(1.0, MUSIC_VOL * self.v_music)

    def set_levels(self, music, engine, fx):
        self.v_music, self.v_engine, self.v_fx = music, engine * ENGINE_GAIN, fx
        if self.ok and not self.music_off and not self.muted:
            try:
                self._m_vol(self._mvol())
            except Exception:
                pass

    def set_music(self, on):
        self.music_off = not on
        if self.ok:
            try:
                self._m_vol(0.0 if self.music_off else self._mvol())
            except Exception:
                pass

    def set_sfx(self, on):
        self.muted = not on
        if self.muted and self.ok:
            for c in self.chans + [self.c_gravel, self.c_wind, self.c_screech, self.c_bell, self.c_rumble, self.c_rain]:
                c.set_volume(0.0)

    def pause(self):
        if getattr(self, "_pz", None) is None:
            self._pz = time.monotonic()                      # the radio "broadcast" stands still while the sound is paused (see resume)
        if self.ok:
            try:
                (WA.pause if WEBA else pygame.mixer.pause)()
                if not WEB:
                    pygame.mixer.music.pause()
            except Exception:
                pass

    def resume(self):
        if getattr(self, "_pz", None) is not None:           # the paused time does not count: the title on the radio display stays in step with what you hear
            if hasattr(self, "_t0"):
                self._t0 += time.monotonic() - self._pz
            self._pz = None
        if self.ok:
            try:
                (WA.unpause if WEBA else pygame.mixer.unpause)()
                if not WEB:
                    pygame.mixer.music.unpause()
            except Exception:
                pass

    def silence(self):
        """everything off: used when the game goes back to the main menu"""
        if not self.ok:
            return
        try:
            (WA.unpause if WEBA else pygame.mixer.unpause)()
            for c in self.chans:
                c.fadeout(120)
            for c in (self.c_gravel, self.c_wind, self.c_screech, self.c_bell, self.c_rumble, self.c_rain):
                c.set_volume(0.0)
            if self.ghost_ch is not None:
                self.ghost_ch.stop()
            self.ghost_on = False
            _mxchan(11).stop()
            _mxchan(10).stop()
            self.tun_on = self.tractor_on = self.rain_on = self.wind_on = False
            self._m_stop()
        except Exception:
            pass
        self.cur = -1
        self.rev = 0.0
        self.dip = 0
        self.duck = 0.0
        self.hold = 0.0
        self.pre = 0.0
        self.holdt = 0
        self.music_started = False
        self.music_ended = False

    def toggle_mute(self):
        self.muted = not self.muted
        if not self.ok:
            return
        try:
            self._m_vol(0.0 if self.muted else self._mvol())
        except Exception:
            pass
        self.music_off = self.muted
        if self.muted:
            for c in self.chans + [self.c_gravel, self.c_wind, self.c_screech, self.c_bell, self.c_rumble, self.c_rain]:
                c.set_volume(0.0)

    # ---- one-shots
    def audition(self, i):
        """title screen: keys 1-9 play hit_cone, hit_barrier, hit_person ... one by one, and the screen says which"""
        name = HIT_FILES[i] if i < len(HIT_FILES) else None
        if name is None or not self.ok:
            return
        snd = self.hits.get(name)
        self.last_hit = ("test: hit_%s.wav" % name) if snd else ("test: hit_%s.wav NOT FOUND" % name)
        print("[audio]", self.last_hit)
        if snd:
            snd.set_volume(min(1.0, (0.9) * self.v_fx))
            snd.play()

    def hit_status(self):
        n = len(self.hits)
        return "hit sounds: %d/%d loaded" % (n, len(HIT_FILES)) if n else "hit sounds: none found (put hit_*.wav in an sfx folder next to the game)"

    def hit(self, kind, severity=0.7):
        """kind: cone barrier worker smoker sleeper ped kid deer cat train rear side"""
        key = HIT_KIND.get(kind, "barrier")
        snd = self.hits.get(key) or self.hits.get(HIT_FALLBACK.get(key, ""))
        self.last_hit = ("sfx: hit_%s.wav" % (key if key in self.hits else HIT_FALLBACK.get(key))) if snd else "sfx: synthesized fallback (file not found)"
        print("[audio] hit", kind, "->", self.last_hit)
        if snd is None:
            self.crash(severity, cut=(kind != "cone"))
            return
        if kind != "cone":                              # a light cone knock doesn't stall the engine
            self._cut()
        if self.ok and not self.muted:
            if self.tripping and getattr(self, "hit_trip", None) is not None:       # tripping: one universal echoing, mushroom-y crash for everything
                snd = self.hit_trip
                snd.set_volume(min(1.0, 0.95 * (0.6 + 0.4 * max(0.0, min(1.0, severity))) * self.v_fx))
                snd.play()
                return
            snd.set_volume(min(1.0, (min(1.0, HIT_GAIN.get(key, 0.9) * (0.6 + 0.4 * max(0.0, min(1.0, severity))))) * self.v_fx))
            snd.play()

    def _cut(self):
        if self.holdt <= 0:                             # engine keeps running: one small step back in revs, then straight back up
            self.pre = self.rev
        self.hold = max(0.0, (self.rev if self.holdt <= 0 else self.hold) - 0.12)   # hits in a row step back further
        self.holdt = HOLD_T
        self.rev = self.hold

    def rail(self, signals, train, closeness, ghost=False):
        """level crossing: bell while the lights flash, rumble while the train is on screen (closeness 0..1)"""
        if not self.ok or self.muted:
            return
        c = max(0.0, min(1.0, closeness))
        self.c_bell.set_volume(min(1.0, (0.55 * c if signals else 0.0) * self.v_fx))
        self.c_rumble.set_volume(min(1.0, (0.8 * c if train else 0.0) * self.v_fx))
        if train and not self.horned:
            self.horned = True
            self.horn.set_volume(min(1.0, (0.45 + 0.4 * c) * self.v_fx))
            self.horn.play()
        if ghost and train and self.ghost_snd is not None and not self.ghost_on:      # whisper overlay on top of the normal train sounds
            self.ghost_on = True
            self.ghost_ch = _mxchan((WA.get_num_channels() if WEBA else pygame.mixer.get_num_channels()) - 1)
            self.ghost_ch.play(self.ghost_snd)
        if self.ghost_on:
            if train and self.ghost_ch is not None:
                self.ghost_ch.set_volume(min(1.0, (0.55 + 0.45 * c) * self.v_fx))
            elif not train:
                if self.ghost_ch is not None:
                    self.ghost_ch.fadeout(1400)
                self.ghost_ch = None
                self.ghost_on = False
        if not train and not signals:
            self.horned = False

    def crash(self, severity, cut=True):
        if cut:
            self._cut()
        if self.ok and not self.muted:
            self.crash_snd.set_volume(min(1.0, (0.35 + 0.65 * max(0.0, min(1.0, severity))) * self.v_fx))
            self.crash_snd.play()

    def spook(self):
        if self.ok and not self.muted:
            self.spook_snd.set_volume(min(1.0, (0.7) * self.v_fx))
            self.spook_snd.play()

    def thunder(self, vol=1.0):
        if self.ok and not self.muted:
            snd = self.events.get("thunder") or self.thunder_snd
            snd.set_volume(min(1.0, (0.9) * vol * self.v_fx))
            snd.play()

    def bat(self):
        if self.ok and not self.muted:
            self.squeak_snd.set_volume(min(1.0, (0.8) * self.v_fx))
            self.squeak_snd.play()

    def chime(self):
        if self.ok and not self.muted:
            self.chime_snd.play()

    HORN_FILES = ["horn_improza.ogg", "horn_yuggo.ogg", "horn_zappo.ogg", "horn_valvo.ogg", "horn_corpse.ogg", "horn_nocturnal.ogg"]   # per car, same order as CARS
    _horns = {}

    _hcur = None
    _warmq = None
    _warmkey = None
    _warmn = 0

    def _warm_horn(self):
        if "trip" not in self._horns:
            path = _find_file("horn_trip.ogg")
            self._horns["trip"] = _load_sfx(path) if path else None

    def warm(self):
        """load the trip sounds (the muffled radio, the trip horn) a little at a time while you drive, so eating the mushroom does not stall the game"""
        key = (tuple(st[2] for st in STATIONS), self.dark_file)
        if self._warmkey != key:
            self._warmkey = key
            self._warmq = [self._warm_horn]
            for st in STATIONS:
                p = _find_file(("%s_uw.ogg" % (self.dark_file if st[2] == "music" else st[2])))
                if p and WEB:                                       # (the PC loads its tracks in a background thread at start)
                    self._warmq.append(lambda p=p: self._music_sound(p))
        self._warmn += 1
        if self._warmq and self._warmn % 25 == 0:
            f = self._warmq.pop(0)
            try:
                f()
            except Exception:
                pass

    def honk(self, car):
        """the car's own horn: starts on press and keeps sounding while the key / button is held (8 s at most)"""
        if not self.ok or self.muted:
            return
        i = "trip" if (self.tripping and _find_file("horn_trip.ogg")) else int(car) % len(self.HORN_FILES)     # while tripping every car has the same weird, echoing honk
        snd = self._horns.get(i)
        if snd is None and i not in self._horns:
            path = _find_file("horn_trip.ogg" if i == "trip" else self.HORN_FILES[i])
            try:
                snd = _load_sfx(path) if path else None
            except Exception as e:
                print("[audio] horn failed:", e)
                snd = None
            self._horns[i] = snd
        if snd:
            if self._hcur is not None:
                try:
                    self._hcur.stop()
                except Exception:
                    pass
            snd.set_volume(min(1.0, 0.85 * self.v_fx))
            snd.play()
            self._hcur = snd

    def event(self, name, vol=1.0):
        """a one-shot scene sound (the tree coming down, a log hitting the road, an annoyed driver): vol 0..1 by distance"""
        if not self.ok or self.muted:
            return
        if name == "tyre_screech" and self.tripping:               # tripping: the same muffled, echoing underwater version
            name = "tyre_screech_uw"
        snd = self.events.get(name)
        vol *= EVENT_TRIM.get(name, 1.0)
        if snd is not None and vol > 0.02:
            try:
                snd.set_volume(min(1.0, vol * self.v_fx))
                snd.play()
            except Exception:
                pass

    def stop_event(self, name):
        """cut a long one-shot short (the wall grinding stops when you leave the wall)"""
        snd = self.events.get(name)
        if snd is not None:
            try:
                snd.fadeout(120)
            except Exception:
                pass

    def warm_step(self):
        """browser: decode the other stations of this level in the background, one every few seconds, so that switching the radio is instant (a long track takes seconds to decode)"""
        if not WEB or not self.ok:
            return
        key = (self.dark_file, tuple(st[2] for st in STATIONS))
        if getattr(self, "_warm_key", None) != key:
            self._warm_key = key
            self._warm_q = [self.dark_file if st[2] == "music" else st[2] for st in STATIONS]
            self._warm_t = 0
        self._warm_t += 1
        if self._warm_q and self._warm_t >= 150:
            self._warm_t = 0
            name = self._warm_q.pop(0)
            for e in (".ogg", ".mp3", ".wav"):
                p = _find_file(name + e)
                if p:
                    try:
                        self._music_sound(p)
                    except Exception:
                        pass
                    break

    def annoyed(self, vol=0.9, kind=None):
        if kind == "tractor":                                       # a tractor answers with its own horn
            self.event("tractor_horn_uw" if self.tripping else "tractor_horn", vol)
            return
        self.event(random.choice(("car_annoyed_uw1", "car_annoyed_uw2", "car_annoyed_uw3") if self.tripping else ("car_annoyed1", "car_annoyed2", "car_annoyed3")), vol)

    def honk_off(self):
        """key / button let go: the horn dies away quickly"""
        if self._hcur is not None:
            try:
                self._hcur.fadeout(600 if self.tripping else 70)               # the trip horn lets its echo ring out
            except Exception:
                pass
            self._hcur = None

    # ---- per frame
    def update(self, run, keys):
        if not self.ok:
            return
        if run.state == "title":
            self.music_started = False
            self.music_ended = False
            try:
                self._m_stop()
            except Exception:
                pass
        elif run.state in ("finish", "over"):           # level over: the music fades out
            if not self.music_ended:
                self.music_ended = True
                try:
                    self._m_fade(1500)
                except Exception:
                    pass
        elif not self.music_started or self.music_ended:    # the track starts with the countdown
            self.music_started = True
            self.music_ended = False
            self._music(True)
        if self.muted:
            if self.spirit_on or self.radio_on or self.tun_on or self.tractor_on or self.rain_on or self.wind_on:
                _mxchan(13).stop()
                _mxchan(12).stop()
                _mxchan(11).stop()
                _mxchan(10).stop()
                self.spirit_on = self.radio_on = self.tun_on = self.tractor_on = self.rain_on = self.wind_on = False
            return
        if run.state != "race":
            self.c_bell.set_volume(0.0)
            self.c_rumble.set_volume(0.0)
            self.horned = False
        if run.state in ("countdown", "race"):
            try:
                self.warm_step()
            except Exception:
                pass
        try:
            self._update(run, keys)
        except Exception:
            self.ok = False

    def _update(self, run, keys):
        racing = run.state == "race"
        rolling = run.state in ("countdown", "race", "finish", "over")
        # countdown beeps
        if run.state == "countdown":
            self.go_played = False
            n = (run.cd - 41) // 50 + 1
            if n != self.last_cd and run.cd > 41:
                self.last_cd = n
                self.beep.play()
        elif racing and run.go > 0 and not self.go_played:
            self.go_played = True
            self.go_beep.play()
        # engine: the reference recording's rev sweep (idle -> top speed) played against road speed
        engine_on = run.state in ("countdown", "race") or (rolling and run.speed > 0.02)     # a stopped car after the finish / a wreck goes quiet
        if not engine_on:
            if self.cur != -1:
                for c in self.chans:
                    c.fadeout(300)
                self.cur = -1
                self.rev = 0.0
        else:
            throttle = keys[pygame.K_UP] and racing
            self.duck = max(0.0, self.duck - 1.0 / CRASH_CUT)
            if True:                                    # after a hit: revs step back and dip briefly, then climb again (no restart)
                target = 0.0 if (run.speed < 0.02 and not throttle) else run.speed
                climb = 0.018
                if self.holdt > 0:
                    self.holdt -= 1
                    if run.speed > 0.02 and throttle:             # still rolling on the gas: revs come back up fast, not with the car's speed
                        target = max(target, self.hold + (self.pre - self.hold) * (1.0 - self.holdt / float(HOLD_T)))
                        climb = 0.06
                if target > self.rev:
                    self.rev = min(target, self.rev + climb)      # loads up
                else:
                    self.rev = max(target, self.rev - 0.03)       # drops quicker than it climbs
                tf = 0.0                                                # how deep in the mushroom trip: the engine sinks to a slow, wobbly hum, like under water
                if racing and getattr(run, "trip_t", 0) > 0:
                    tf = min(1.0, run.trip_t / 240.0)
                    tf = tf if run.trip else tf * max(0.0, run.untrip / 100.0)
                rv = max(0.0, min(1.0, self.rev))
                if tf > 0.0:
                    rv = rv * (1.0 - 0.5 * tf) * (1.0 + 0.1 * tf * math.sin(run.frames * 0.045))
                idx = int(round(rv * (self.VARIANTS - 1)))
                vol = min(1.0, (0.62 if throttle else 0.5) * self.v_engine * (1.0 - 0.3 * tf))
                self.sw += 1
                if idx != self.cur and (self.cur < 0 or self.sw >= self.dwell):
                    self.sw = 0
                    new = self.chans[self.chan_i]
                    old = self.chans[1 - self.chan_i]
                    new.play(self.engine[idx], loops=-1, fade_ms=self.fade[0])
                    old.fadeout(self.fade[1])
                    self.chan_i = 1 - self.chan_i
                    self.cur = idx
                self.chans[1 - self.chan_i].set_volume(vol)
        if run.state in ("countdown", "race"):
            self.warm()
        tripping = racing and getattr(run, "trip", False)
        self.tripping = tripping
        if tripping != self.music_uw:                                         # swap the radio to its underwater version (same place in the song) and back
            self.music_uw = tripping
            if getattr(self, "music_on", False):
                try:
                    self._music(True)
                except Exception:
                    pass
        if self.trip_spirit is not None:                                      # the spiritual bed fades in with the mushroom and out again with the cure
            if tripping and not self.spirit_on:
                self.spirit_on = True
                ch = _mxchan(13)
                ch.play(self.trip_spirit, loops=-1, fade_ms=2500)
                ch.set_volume(min(1.0, 0.55 * self.v_fx))
            elif self.spirit_on and not tripping:
                self.spirit_on = False
                _mxchan(13).fadeout(1500)
            elif self.spirit_on:
                _mxchan(13).set_volume(min(1.0, 0.55 * self.v_fx))
        tk = getattr(run, "tun_k", 0.0) if racing else 0.0                    # inside the tunnel: a roar that swells over the first metres and fades at the far mouth
        if self.tunnel_snd is not None:
            if tk > 0.02 and not self.tun_on:
                self.tun_on = True
                _mxchan(11).play(self.tunnel_snd, loops=-1)
            elif self.tun_on and tk <= 0.02:
                self.tun_on = False
                _mxchan(11).fadeout(500)
            if self.tun_on:
                _mxchan(11).set_volume(min(1.0, 0.7 * tk * self.v_fx))
        sa_ = getattr(run, "storm_amb", 0.0) if racing else 0.0               # the storm on the island: rain and gusts of wind
        if self.rain_snd is not None:
            if sa_ > 0.02 and not self.rain_on:
                self.rain_on = True
                _mxchan(11).play(self.rain_snd, loops=-1, fade_ms=1500)
            elif self.rain_on and sa_ <= 0.02:
                self.rain_on = False
                _mxchan(11).fadeout(800)
            if self.rain_on:
                _mxchan(11).set_volume(min(1.0, 0.55 * sa_ * self.v_fx))
        wa_ = getattr(run, "wind_amb", 0.0) if racing else 0.0
        if self.wind_snd is not None:
            if wa_ > 0.02 and not self.wind_on:
                self.wind_on = True
                _mxchan(10).play(self.wind_snd, loops=-1, fade_ms=1500)
            elif self.wind_on and wa_ <= 0.02:
                self.wind_on = False
                _mxchan(10).fadeout(800)
            if self.wind_on:
                _mxchan(10).set_volume(min(1.0, 0.6 * wa_ * self.v_fx))
        td = getattr(run, "tractor_d", None) if racing else None             # a tractor close by: its engine fades in as you come up to it and out behind you
        if self.tractor_snd is not None:
            tv = 0.0 if td is None else max(0.0, 1.0 - td / 260.0) ** 1.4
            if tv > 0.02 and not self.tractor_on:
                self.tractor_on = True
                _mxchan(10).play(self.tractor_snd, loops=-1)
            elif self.tractor_on and tv <= 0.02:
                self.tractor_on = False
                _mxchan(10).fadeout(400)
            if self.tractor_on:
                _mxchan(10).set_volume(min(1.0, 0.25 * tv * self.v_fx))
        rs = getattr(run, "radio_s", None)
        if self.trip_police is not None and rs is not None:                  # police radio: starts as you near the stop, loudest beside it, gone behind you
            d = rs - run.pos
            if run.pos < rs - 700:
                self.radio_on = self.radio_done = False
            if racing and not self.radio_on and not self.radio_done and 0 < d < 420:
                self.radio_on = True
                ch = _mxchan(12)
                ch.play(self.trip_police)
            if self.radio_on:
                if d < -420 or not racing:
                    self.radio_on = False
                    self.radio_done = True
                    _mxchan(12).stop()
                else:
                    _mxchan(12).set_volume(min(1.0, 0.85 * max(0.0, 1.0 - abs(d) / 420.0) ** 1.2 * self.v_fx))
        elif rs is None:
            self.radio_on = False
        if racing and self.trip_voices and getattr(run, "trip", False):      # while tripping, voices drift in now and then, each one followed by two fading echoes
            self.tv_next -= 1
            if self.tv_next <= 0:
                self.tv_next = random.randint(300, 800)
                tv = random.choice(self.trip_voices)
                tv[0].set_volume(min(1.0, 0.7 * self.v_fx))
                tv[0].play()
                self.tv_echo = [[16, tv[1], 0.38], [34, tv[2], 0.2]]
        elif not getattr(run, "trip", False):
            self.tv_next = 240
        for ec in list(self.tv_echo):
            ec[0] -= 1
            if ec[0] <= 0:
                ec[1].set_volume(min(1.0, ec[2] * self.v_fx))
                ec[1].play()
                self.tv_echo.remove(ec)
        self.c_rain.set_volume(min(1.0, (min(0.55, getattr(run, "rain", 0.0) * 0.55) if rolling else 0.0) * self.v_fx))
        # surface noises
        self.c_wind.set_volume(min(1.0, (min(1.0, run.speed ** 1.5 * 0.9)) * self.v_fx))
        self.c_gravel.set_volume(min(1.0, (min(1.0, run.speed * 1.1) if (run.off and run.speed > 0.03) else 0.0) * self.v_fx))
        braking = keys[pygame.K_DOWN] and run.speed > 0.45
        self.c_screech.set_volume(min(1.0, (min(0.55, run.brake * run.speed * 0.8) if braking else 0.0) * self.v_fx))
        # low-time warning ticks
        if racing:
            tl = int(run.time_left())
            if 0 <= tl < 10 and tl != self.last_tick:
                self.last_tick = tl
                self.tick.play()
