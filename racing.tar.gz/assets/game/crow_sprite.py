"""the crow that waits next to the car at the start: a crow (pitch black, a faint bluish sheen on the feathers), drawn
in code at low resolution and scaled up crisp. It faces left."""
import pygame

BLACK = (10, 10, 14)
INK = (40, 42, 56)          # black feathers' highlights
GREY = (24, 25, 34)         # pitch-black body, only a bluish sheen tells the shapes apart
GREY_D = (15, 15, 21)
GREY_L = (50, 53, 70)
BEAK = (28, 28, 34)
BEAK_L = (84, 86, 104)
EYE = (255, 40, 30)
LEG = (52, 46, 44)
_CACHE = {}


def _build():
    w, h = 34, 34
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    P = pygame.draw.polygon
    E = pygame.draw.ellipse
    L = pygame.draw.line
    # legs and toes first (behind the body)
    for lx in (14, 20):
        L(s, LEG, (lx, 27), (lx, 31))
        L(s, LEG, (lx + 1, 27), (lx + 1, 31))
        L(s, LEG, (lx, 31), (lx - 3, 32))
        L(s, LEG, (lx, 31), (lx - 1, 32))
        L(s, LEG, (lx, 31), (lx + 2, 32))
    # tail (black), long, sloping down behind
    P(s, BLACK, [(24, 22), (33, 30), (31, 33), (28, 33), (21, 27)])
    # body: grey breast and belly
    P(s, GREY, [(8, 14), (16, 10), (26, 15), (28, 23), (23, 29), (14, 29), (9, 23)])
    E(s, GREY_L, (8, 14, 8, 8))                       # lighter breast
    E(s, GREY_D, (12, 23, 12, 6))                     # shaded belly
    # folded wing: black, over the back, running down into the tail
    E(s, GREY, (12, 9, 14, 9))                        # grey mantle across the back
    P(s, BLACK, [(15, 16), (23, 15), (30, 23), (31, 29), (27, 28), (19, 27), (15, 22)])
    for i in range(5):                                # feather edges
        L(s, INK, (17 + i * 2, 18 + i // 2), (21 + i * 2, 26 + i // 2))
    # head and bib: black
    E(s, BLACK, (6, 3, 12, 11))
    E(s, BLACK, (8, 11, 8, 6))
    # beak: thick, curved, dark grey with a pale ridge
    P(s, BEAK, [(8, 6), (4, 8), (1, 12), (3, 12), (7, 12), (9, 10)])
    L(s, BEAK_L, (3, 8), (8, 6))
    s.set_at((11, 6), BLACK)
    # the eye
    s.set_at((11, 7), EYE)
    s.set_at((12, 7), EYE)
    s.set_at((11, 8), (170, 20, 16))
    return s


def get(scale=3):
    if scale not in _CACHE:
        s = _build()
        _CACHE[scale] = pygame.transform.scale(s, (s.get_width() * scale, s.get_height() * scale))
    return _CACHE[scale]


EYE_XY = (11.5, 7.2)        # eye position in sprite pixels (for the red glow)
FEET_XY = (17, 33)          # where it stands


# ---- the portrait shown beside the countdown: the crow's head, facing the road
_PORT = {}


def portrait(scale=2):
    """a framed bust of the crow (44x44 pixels, scaled), moonlit, with a red eye"""
    if scale in _PORT:
        return _PORT[scale]
    n = 44
    s = pygame.Surface((n, n))
    for y in range(n):                                       # night backdrop
        k = y / n
        pygame.draw.line(s, (34 - int(14 * k), 24 - int(12 * k), 54 - int(22 * k)), (0, y), (n, y))
    pygame.draw.circle(s, (62, 54, 92), (6, 6), 8)           # a pale moon, top left
    pygame.draw.circle(s, (100, 92, 138), (6, 6), 5)
    P = pygame.draw.polygon
    E = pygame.draw.ellipse
    L = pygame.draw.line
    E(s, BLACK, (-6, 28, 40, 26))                            # shoulders
    for i in range(7):                                       # ruffled neck feathers
        L(s, INK, (4 + i * 4, 31 + (i % 2)), (8 + i * 4, 38 + (i % 3)))
    P(s, BLACK, [(12, 24), (26, 24), (30, 34), (8, 34)])     # throat
    E(s, BLACK, (6, 6, 26, 26))                              # head
    P(s, BLACK, [(10, 8), (24, 5), (30, 12), (14, 14)])      # crown
    # beak: heavy, with a slight hook, pointing right
    P(s, (52, 52, 64), [(28, 14), (36, 14), (43, 19), (42, 22), (37, 23), (29, 24)])
    L(s, (128, 130, 154), (29, 15), (38, 15))
    L(s, (128, 130, 154), (38, 15), (42, 19))
    L(s, (36, 36, 46), (30, 23), (40, 22))
    L(s, BLACK, (30, 21), (40, 21))                          # the gape line
    # rim light from the moon on the back of the head and the neck
    for (x, y) in ((9, 11), (8, 14), (8, 17), (11, 8), (14, 6), (18, 5), (21, 5), (5, 31), (6, 34), (9, 28), (10, 25)):
        s.set_at((x, y), GREY_L)
    # the eye: a hard brow over a red eye
    E(s, (150, 20, 16), (22, 12, 7, 6))
    E(s, EYE, (23, 13, 5, 4))
    s.set_at((24, 14), (255, 220, 200))
    P(s, BLACK, [(20, 10), (31, 10), (31, 13), (28, 13), (20, 12)])   # brow, slanting down toward the beak
    L(s, INK, (20, 9), (30, 11))
    big = pygame.transform.scale(s, (n * scale, n * scale))
    glow = pygame.Surface(big.get_size(), pygame.SRCALPHA)
    for r in range(9, 2, -1):                                # soft red glow around the eye
        pygame.draw.circle(glow, (255, 40, 30, 9), (25 * scale, 15 * scale), r * scale)
    big.blit(glow, (0, 0))
    eye = pygame.Surface((5 * scale, 4 * scale))
    eye.fill(EYE)
    big.blit(eye, (23 * scale, 13 * scale))
    pygame.draw.rect(big, (255, 220, 200), (24 * scale, 14 * scale, scale, scale))
    pygame.draw.rect(big, (122, 36, 44), big.get_rect(), 3)  # frame
    pygame.draw.rect(big, (20, 10, 16), big.get_rect().inflate(-6, -6), 1)
    _PORT[scale] = big
    return big
