"""Project-wide settings. Change TITLE here and it changes everywhere (window title, menu)."""
TITLE = "ROAD VANDAL"
VERSION = "0.1.0"
LS = 1.5                    # level length scale
START_LEVEL = None          # set to 2 for a Halloween-only edition that starts right on the Halloween level

# online high scores (Supabase). Leave both empty to switch the scoreboard off.
SB_URL = "https://seadveryzhowlejdqfvn.supabase.co"                 # e.g. "https://abcdefgh.supabase.co"
SB_KEY = "sb_publishable_e55TUNTBSYxcm4vryeMvDg_j1Ml2IX3"                 # the "anon public" key (it is meant to be public)
