"""Pixel-art car sprites for the racer, drawn in code so there are no image files to ship.

Current car: black Subaru Impreza WRX STI sedan (2003-05 'blobeye'), seen from behind,
big roof-height wing, round-ish tail lights, twin exhausts, dark diffuser.

Usage:
    import car_sprite
    surf = car_sprite.get(braking=False, scale=2)   # cached pygame.Surface with per-pixel alpha
"""
import math

import pygame

PW, PH = 37, 30      # sprite size in art pixels (mirrored around the centre column)

PAL = {
    "K": (22, 22, 28),      # body black
    "B": (58, 60, 76),      # body highlight
    "b": (38, 40, 52),      # body mid
    "D": (8, 8, 10),        # deep shadow / diffuser
    "G": (26, 34, 46),      # glass
    "g": (78, 98, 120),     # glass glint
    "R": (214, 28, 20),     # tail light
    "r": (120, 14, 12),     # tail light dark
    "A": (238, 150, 30),    # amber indicator
    "W": (222, 222, 208),   # plate
    "w": (150, 150, 140),   # plate shade
    "S": (172, 172, 180),   # exhaust chrome
    "s": (92, 92, 100),     # exhaust dark
    "T": (14, 14, 16),      # tyre
    "t": (44, 44, 48),      # tyre highlight
    "Y": (206, 162, 52),    # gold wheel (peeks out under the arch)
    "L": (6, 6, 8),         # contact shadow
}

BRAKE_RED = (255, 74, 52)
BRAKE_GLOW = (255, 150, 120)


def _build(braking):
    g = [["."] * PW for _ in range(PH)]
    cx = PW // 2

    def px(x, y, c):
        if 0 <= x < PW and 0 <= y < PH:
            g[y][x] = c

    def rect(x0, y0, x1, y1, c):
        """filled rect given for the LEFT half (x <= cx); mirrored automatically"""
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                px(x, y, c)
                px(PW - 1 - x, y, c)

    def hline_half(y, x0, x1, c):
        rect(x0, y, x1, y, c)

    # ---- wing: flat blade, end plates hang BELOW the blade line (never poke above it)
    rect(4, 0, cx, 0, "B")                # blade top edge highlight
    rect(4, 1, cx, 2, "K")                # blade body
    rect(4, 3, cx, 3, "D")                # shadow under the blade
    rect(4, 0, 5, 4, "K")                 # end plates
    rect(4, 0, 4, 0, "B")
    rect(10, 3, 11, 9, "K")               # uprights

    # ---- cabin: roof, rear window, C-pillars
    rect(7, 4, cx, 4, "b")
    rect(6, 5, cx, 5, "K")
    rect(6, 6, 6, 9, "K")
    rect(7, 6, cx, 9, "G")                # rear glass
    rect(8, 6, 9, 6, "g")                 # glints
    rect(9, 7, 10, 7, "g")
    rect(10, 8, 10, 8, "g")
    rect(10, 3, 11, 9, "K")               # uprights again over the glass
    rect(5, 10, cx, 10, "D")              # parcel shelf shadow

    # ---- trunk lid
    rect(3, 11, cx, 11, "B")
    rect(2, 12, cx, 13, "b")
    rect(2, 14, cx, 14, "K")
    rect(cx, 11, cx, 14, "B")

    # ---- body flanks / rear quarter
    rect(1, 12, 2, 24, "K")
    rect(1, 12, 1, 14, "b")

    # ---- tail lights (wide wraparound clusters)
    rc = BRAKE_RED if braking else None
    rect(3, 15, 12, 18, "R")
    rect(3, 15, 3, 15, "r")
    rect(4, 18, 12, 18, "r")
    rect(3, 15, 6, 15, "A")               # indicator strip on the outer top
    rect(9, 16, 10, 17, "R")
    rect(1, 16, 2, 18, "R")               # wraps round the corner
    rect(13, 15, cx, 18, "D")             # boot lock panel between the lights
    rect(13, 14, cx, 14, "K")

    # ---- bumper, plate, diffuser
    rect(2, 19, cx, 20, "K")
    rect(3, 19, cx, 19, "b")
    rect(2, 21, cx, 24, "K")
    rect(4, 22, cx, 24, "D")              # diffuser / lower valance
    rect(cx - 5, 19, cx + 5, 22, "W")     # numberplate (center, so not mirrored)
    for x in range(cx - 5, cx + 6):
        px(x, 22, "w")
    for x in (cx - 3, cx - 1, cx + 1, cx + 3):
        px(x, 20, "D")
        px(x, 21, "D")
    px(cx, 17, "S")                       # little badge
    px(cx - 1, 17, "S")
    px(cx + 1, 17, "S")

    # ---- twin exhaust tips
    rect(8, 24, 10, 26, "s")
    rect(9, 25, 10, 26, "S")
    rect(9, 25, 9, 25, "D")
    rect(10, 25, 10, 25, "D")

    # ---- tyres (side, slightly wider than body) with gold rims peeking
    rect(0, 17, 1, 27, "T")
    rect(0, 18, 0, 25, "t")
    rect(2, 25, 3, 27, "T")
    rect(4, 26, 4, 27, "T")
    rect(1, 24, 2, 24, "Y")
    rect(5, 25, cx, 26, "D")              # underbody

    # ---- contact shadow under everything
    rect(2, 28, cx, 29, "L")
    rect(0, 27, 1, 28, "L")

    surf = pygame.Surface((PW, PH), pygame.SRCALPHA)
    for y in range(PH):
        for x in range(PW):
            c = g[y][x]
            if c == ".":
                continue
            col = PAL[c]
            if braking and c == "R":
                col = BRAKE_RED
            surf.set_at((x, y), (*col, 255))
    if braking:
        # glow pixels around the lamps
        for (x0, x1) in ((2, 13),):
            for x in range(x0, x1 + 1):
                for xx in (x, PW - 1 - x):
                    if surf.get_at((xx, 14))[3] == 0 or True:
                        pass
    return surf


PAL_Y = dict(PAL)
PAL_Y.update({
    "O": (214, 132, 30),    # mustard body
    "o": (176, 100, 24),    # body shade
    "H": (240, 176, 78),    # body highlight
    "X": (120, 66, 28),     # rust
    "C": (150, 120, 70),    # crate / cardboard
    "c": (104, 80, 44),     # crate shade
    "E": (212, 206, 190),   # rope
    "M": (226, 222, 206),   # mattress ticking
    "N": (248, 246, 236),   # mattress top edge
    "m": (104, 134, 178),   # mattress blue stripe
    "n": (150, 150, 160),   # mattress underside
})


def _build_yuggo(braking):
    """the other car: a boxy mustard hatchback with a mattress on the roof"""
    g = [["."] * PW for _ in range(PH)]
    cx = PW // 2

    def px(x, y, c):
        if 0 <= x < PW and 0 <= y < PH:
            g[y][x] = c

    def rect(x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                px(x, y, c)
                px(PW - 1 - x, y, c)

    rect(3, 0, cx, 3, "M")                 # mattress tied to the roof: wider than the car, striped ticking
    rect(3, 0, cx, 0, "N")
    for x in range(3, cx + 1, 4):
        rect(x, 1, x + 1, 2, "m")          # bold stripes
    rect(3, 3, cx, 3, "n")                 # underside / shadow
    rect(cx, 1, cx, 2, "n")                # button tuft
    rect(cx - 8, 1, cx - 8, 2, "n")
    px(3, 0, "."); px(PW - 4, 0, ".")      # rounded corners
    rect(9, 0, 9, 3, "E")                  # ropes
    rect(15, 0, 15, 3, "E")
    rect(5, 4, cx, 5, "O")                 # roof
    rect(5, 4, cx, 4, "H")
    rect(4, 6, 5, 13, "o")                 # pillars
    rect(6, 6, cx, 12, "G")                # big upright rear window
    rect(7, 7, 8, 8, "g")
    rect(8, 9, 9, 9, "g")
    rect(6, 10, 7, 10, "X")                # rust blooming at the glass edge
    rect(3, 13, cx, 14, "O")               # tailgate
    rect(3, 13, cx, 13, "H")
    rect(2, 14, 2, 22, "o")
    rect(2, 15, cx, 15, "o")
    rect(2, 15, 6, 18, "R")                # small tail lamps
    rect(2, 15, 2, 15, "r")
    rect(3, 17, 6, 18, "r")
    rect(2, 16, 3, 16, "A")
    rect(5, 16, 5, 17, "R")
    rect(7, 15, cx, 18, "O")
    rect(10, 16, cx, 17, "X")              # rust patch on the hatch
    rect(1, 19, cx, 20, "S")               # chrome bumper
    rect(1, 19, cx, 19, "W")
    rect(2, 21, cx, 23, "o")
    rect(3, 21, cx, 22, "X")
    rect(cx - 4, 16, cx + 4, 18, "W")      # plate on the tailgate
    rect(cx - 4, 18, cx + 4, 18, "w")
    rect(10, 23, 11, 25, "s")              # single exhaust, off to one side
    rect(10, 24, 11, 25, "S")
    rect(0, 17, 1, 27, "T")
    rect(0, 18, 0, 25, "t")
    rect(2, 24, 4, 27, "T")
    rect(5, 24, cx, 25, "D")
    rect(2, 28, cx, 29, "L")
    rect(0, 27, 1, 28, "L")
    surf = pygame.Surface((PW, PH), pygame.SRCALPHA)
    for y in range(PH):
        for x in range(PW):
            c = g[y][x]
            if c == ".":
                continue
            col = PAL_Y[c]
            if braking and c == "R":
                col = BRAKE_RED
            surf.set_at((x, y), (*col, 255))
    return surf


PAL_E = dict(PAL)
PAL_E.update({
    "M": (120, 214, 176),   # mint body
    "m": (84, 170, 134),    # body shade
    "H": (176, 240, 214),   # body highlight
    "Q": (250, 214, 40),    # yellow (lightning bolt, plug)
    "F": (244, 120, 28),    # roof flag
    "P": (40, 44, 52),      # charging cable
})
EV_HALF = 11.5               # half the car's width in art pixels (it is a small car)


def _build_ev(braking):
    """a tiny electric egg: mint green, round rear window, a flag on the roof and its charging cable still plugged in"""
    g = [["."] * PW for _ in range(PH)]
    cx = PW // 2

    def px(x, y, c):
        if 0 <= x < PW and 0 <= y < PH:
            g[y][x] = c

    def rect(x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                px(x, y, c)
                px(PW - 1 - x, y, c)

    for y in range(0, 6):                  # antenna with a little orange flag
        px(cx, y, "S" if y > 1 else "K")
    for x, y in ((cx + 1, 0), (cx + 2, 0), (cx + 3, 1), (cx + 1, 1), (cx + 2, 1), (cx + 1, 2)):
        px(x, y, "F")
    rect(11, 5, cx, 5, "H")                # roof, rounded
    rect(10, 6, cx, 7, "M")
    rect(9, 8, cx, 8, "m")
    rect(9, 9, cx, 14, "M")                # rear body
    rect(11, 9, cx, 13, "G")               # big round rear window
    rect(12, 9, cx - 2, 9, "G")
    rect(12, 10, 13, 10, "g")
    rect(13, 11, 14, 11, "g")
    rect(8, 15, cx, 22, "M")
    rect(8, 15, cx, 15, "H")
    rect(8, 21, cx, 22, "m")
    rect(8, 16, 11, 19, "R")               # big round tail lamps
    rect(8, 16, 8, 16, "r")
    rect(11, 19, 11, 19, "r")
    px(cx, 16, "Q")                        # lightning bolt on the tailgate
    px(cx - 1, 17, "Q")
    px(cx, 18, "Q")
    px(cx - 1, 19, "Q")
    rect(cx - 3, 20, cx + 3, 21, "W")      # plate
    rect(cx - 3, 21, cx + 3, 21, "w")
    rect(8, 23, cx, 24, "S")               # bumper
    rect(8, 23, cx, 23, "W")
    rect(6, 20, 8, 27, "T")                # small wheels
    rect(6, 21, 6, 26, "t")
    rect(8, 25, cx, 26, "D")               # underbody shadow
    for y in range(24, 29):                # the charging cable, still plugged in and trailing
        px(cx + 4, y, "P")
    px(cx + 5, 28, "P")
    px(cx + 6, 28, "Q")
    px(cx + 7, 28, "Q")
    rect(6, 28, cx, 29, "L")
    surf = pygame.Surface((PW, PH), pygame.SRCALPHA)
    for y in range(PH):
        for x in range(PW):
            c = g[y][x]
            if c == ".":
                continue
            col = PAL_E[c]
            if braking and c == "R":
                col = BRAKE_RED
            surf.set_at((x, y), (*col, 255))
    return surf


PAL_V = dict(PAL)
PAL_V.update({
    "V": (30, 84, 58),      # forest green body
    "v": (64, 130, 92),     # body highlight
    "u": (18, 54, 38),      # body shade
    "N": (200, 204, 210),   # roof rail / skid plate silver
    "O": (236, 236, 226),   # reversing light
})
V_HALF = 19.5               # a big car: a wider hit box than the others


def _build_valvo(braking):
    """VALVO: a tall, boxy, sturdy Scandinavian SUV from behind: roof rails, upright tail lights, mud flaps, lifted on chunky tyres"""
    g = [["."] * PW for _ in range(PH)]
    cx = PW // 2

    def px(x, y, c):
        if 0 <= x < PW and 0 <= y < PH:
            g[y][x] = c

    def rect(x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                px(x, y, c)
                px(PW - 1 - x, y, c)

    rect(5, 0, 9, 0, "N")                  # roof rails
    rect(5, 1, 5, 1, "N")
    rect(8, 1, 9, 1, "s")
    rect(4, 2, cx, 2, "v")                 # flat roof edge
    rect(3, 3, cx, 3, "V")
    rect(3, 3, 5, 10, "V")                 # thick C-pillars
    rect(3, 3, 3, 10, "u")
    rect(6, 4, cx, 10, "G")                # big square rear window
    rect(7, 4, 9, 4, "g")                  # glints
    rect(8, 5, 10, 5, "g")
    rect(9, 6, 10, 6, "g")
    rect(6, 9, cx, 9, "K")                 # rear wiper arm
    px(cx, 8, "K")
    rect(2, 11, cx, 11, "v")               # top of the tailgate
    rect(2, 12, cx, 20, "V")               # tailgate
    rect(1, 11, 2, 22, "u")                # side shade
    rect(2, 21, cx, 21, "u")
    rect(1, 11, 4, 17, "R")                # tall vertical tail lights
    rect(1, 18, 4, 19, "A")
    rect(1, 20, 4, 21, "O")
    rect(1, 11, 1, 21, "r")
    rect(5, 11, 5, 21, "K")                # light surround
    rect(cx - 3, 10, cx + 3, 10, "r")      # high-mounted third brake light (lit when braking)
    rect(cx - 2, 13, cx + 2, 14, "u")      # tailgate handle recess
    px(cx, 15, "S")                        # little badge
    px(cx - 1, 15, "S")
    px(cx + 1, 15, "S")
    rect(1, 22, cx, 25, "K")               # chunky plastic bumper
    rect(2, 22, cx, 22, "b")
    rect(cx - 5, 17, cx + 5, 20, "W")      # numberplate on the tailgate
    for x in range(cx - 5, cx + 6):
        px(x, 20, "w")
    rect(6, 23, cx, 24, "D")
    rect(cx - 1, 23, cx + 1, 24, "S")      # tow hook
    px(cx, 24, "D")
    rect(5, 25, cx, 25, "N")               # skid plate
    rect(4, 26, 6, 27, "K")                # mud flaps
    rect(5, 26, cx, 27, "D")               # underbody: lifted, you can see under it
    rect(0, 15, 3, 16, "K")                # wheel-arch flares
    rect(0, 17, 3, 28, "T")                # big chunky tyres
    rect(0, 18, 0, 27, "t")
    rect(1, 17, 1, 17, "t")
    rect(2, 24, 2, 25, "N")
    rect(2, 28, cx, 29, "L")               # contact shadow
    rect(0, 28, 1, 28, "L")
    surf = pygame.Surface((PW, PH), pygame.SRCALPHA)
    for y in range(PH):
        for x in range(PW):
            c = g[y][x]
            if c == ".":
                continue
            col = PAL_V[c]
            if braking and (c == "R" or (c == "r" and y == 10)):
                col = BRAKE_RED
            surf.set_at((x, y), (*col, 255))
    return surf


PAL_C = dict(PAL)
PAL_C.update({
    "C": (92, 52, 30),      # coffin wood
    "c": (138, 86, 50),     # wood highlight
    "x": (52, 28, 16),      # wood shade / inside of the box
    "Q": (222, 180, 62),    # brass
    "q": (150, 112, 36),    # brass shade
    "E": (255, 214, 90),    # candle flame
    "e": (255, 150, 40),    # flame edge
    "z": (150, 178, 142),   # corpse skin (a bit green)
    "Z": (112, 138, 106),   # skin shade
    "P": (210, 60, 70),     # striped sock red
    "p": (232, 232, 224),   # striped sock white
    "k": (36, 24, 26),      # old shoe
    "n": (206, 206, 190),   # candle wax
    "h": (120, 120, 126),   # exhaust smoke
})
C_HALF = 18.0


def _build_coffin(braking, lid=0):
    """a casket on wheels: dark wood, brass handles, candle tail lights, a crooked R.I.P. plate.
    lid 0: lid on.  lid 1: the lid is gone and the corpse's thigh and knee lie over the rim; the shin swings separately (get_leg)."""
    lid_off = lid > 0
    g = [["."] * PW for _ in range(PH)]
    cx = PW // 2

    def px(x, y, c):
        if 0 <= x < PW and 0 <= y < PH:
            g[y][x] = c

    def rect(x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                px(x, y, c)
                px(PW - 1 - x, y, c)

    if not lid_off:
        rect(11, 1, cx, 1, "c")                # the lid: a peaked, tapering hexagon
        rect(10, 2, cx, 2, "C")
        rect(8, 3, cx, 4, "C")
        rect(8, 3, cx, 3, "c")
        rect(6, 5, cx, 7, "C")
        rect(6, 5, cx, 5, "c")
        rect(4, 8, cx, 9, "C")
        rect(4, 8, cx, 8, "c")
        rect(cx - 1, 2, cx + 1, 7, "Q")        # brass cross on the lid
        rect(cx - 3, 4, cx + 3, 5, "Q")
        rect(cx - 1, 7, cx - 1, 7, "q")
        for y in (3, 6):                       # rope that ties the lid down
            px(5, y + 2, "n")
            px(PW - 6, y + 2, "n")
    else:
        rect(4, 8, cx, 8, "x")                 # open box: the lid is gone, only splinters are left on the rim
        rect(4, 9, cx, 9, "C")
        for x in (4, 6, 9):
            px(x, 7, "C")
            px(PW - 1 - x, 7, "C")
            px(x, 6, "x") if x == 4 else None
        for x in range(cx - 7, cx + 8):         # inside of the box behind the legs
            if g[8][x] == ".":
                px(x, 8, "x")
    # the box: back panel
    rect(2, 10, cx, 20, "C")
    rect(2, 10, cx, 10, "c")
    rect(2, 11, 2, 20, "x")
    rect(3, 11, cx, 11, "x")
    # brass handles on the sides
    for y in (13, 17):
        rect(0, y, 1, y, "Q")
        rect(0, y + 1, 0, y + 1, "q")
    # panels on the back
    rect(5, 13, cx - 3, 18, "x")
    rect(6, 14, cx - 4, 17, "C")
    # "R.I.P." plate, hanging crooked on one screw
    rect(cx - 5, 13, cx + 5, 19, "W")
    rect(cx - 5, 19, cx + 5, 19, "w")
    glyphs = ("###", "#.#", "##.", "#.#"), (), ()
    R = ["###", "#.#", "###", "##.", "#.#"]
    I = ["#", "#", "#", "#", "#"]
    Pp = ["###", "#.#", "###", "#..", "#.."]
    x0 = cx - 4
    for letter, w in ((R, 3), (I, 1), (Pp, 3)):
        for ry, row in enumerate(letter):
            for rx, ch in enumerate(row):
                if ch == "#":
                    px(x0 + rx, 14 + ry, "D")
        x0 += w + 1
    px(cx - 5, 20, "W")                    # the plate hangs crooked: one screw has come out
    # tail lights: two candles in tin holders; the flame turns red-hot when braking
    rect(3, 11, 5, 12, "E" if not braking else "R")
    rect(4, 10, 4, 10, "e" if not braking else "A")
    rect(3, 13, 5, 17, "n")
    rect(2, 18, 6, 19, "s")
    rect(2, 19, 6, 19, "S")
    # bumper: a plank
    rect(1, 21, cx, 22, "C")
    rect(1, 21, cx, 21, "c")
    rect(1, 22, cx, 22, "x")
    # exhaust pipe with a puff of smoke
    rect(cx - 8, 23, cx - 6, 25, "s")
    px(cx - 7, 25, "S")
    px(cx - 7, 26, "h")
    px(cx - 6, 27, "h")
    if lid_off:                            # one leg of the corpse hangs over the rim and dangles down the right side, from the knee
        leg = {}
        for y in range(3, 8):              # thigh coming up out of the box
            for x in range(PW - 6 - (y - 3) // 2, PW - 3 - (y - 3) // 2):
                leg[(x, y)] = "z"
            leg[(PW - 3 - (y - 3) // 2, y)] = "Z"
        for y in range(7, 10):             # the knee over the rim
            for x in range(PW - 7, PW - 2):
                leg[(x, y)] = "z"
            leg[(PW - 2, y)] = "Z"
        leg[(PW - 7, 7)] = "Z"
        for (x, y), c in leg.items():      # (the shin, sock and shoe are a separate swinging layer, see _leg_layer)
            px(x, y, c)
    # wheels: mismatched, chunky
    rect(0, 17, 1, 27, "T")
    rect(0, 18, 0, 26, "t")
    rect(2, 24, 3, 27, "T")
    rect(4, 25, cx, 26, "D")
    rect(1, 24, 1, 24, "Y")
    rect(2, 28, cx, 29, "L")
    rect(0, 27, 1, 28, "L")
    surf = pygame.Surface((PW, PH), pygame.SRCALPHA)
    for y in range(PH):
        for x in range(PW):
            c = g[y][x]
            if c == ".":
                continue
            surf.set_at((x, y), (*PAL_C[c], 255))
    return surf


def _leg_layer():
    """the corpse's shin, striped sock and old shoe, hanging from the knee: a separate layer so it can swing"""
    g = pygame.Surface((PW, PH), pygame.SRCALPHA)

    def px(x, y, c):
        g.set_at((x, y), (*PAL_C[c], 255))
    for y in range(10, 22):
        for x in range(PW - 6, PW - 3):
            px(x, y, "z")
        px(PW - 3, y, "Z")
    for y in range(15, 19):
        for x in range(PW - 6, PW - 2):
            px(x, y, "P" if y % 2 else "p")
    for y in range(21, 25):
        for x in range(PW - 7, PW - 1):
            px(x, y, "k")
    g.set_at((PW - 7, 24), (0, 0, 0, 0))
    g.set_at((PW - 7, 21), (0, 0, 0, 0))
    return g


LEG_PIVOT = (PW - 4.5, 9.5)          # the knee, in art pixels
_leg_cache = {}


def get_leg(scale, angle):
    """(surface, dx, dy): the swinging shin rotated by `angle` degrees (positive = foot swings right) about the knee,
    and where to blit it relative to the car sprite's top-left corner"""
    a = int(round(angle / 2.0)) * 2
    key = (scale, a)
    if key not in _leg_cache:
        base = pygame.transform.scale(_leg_layer(), (PW * scale, PH * scale))
        px_, py_ = LEG_PIVOT[0] * scale, LEG_PIVOT[1] * scale
        th = math.radians(-a)                             # pygame rotates counter-clockwise
        rot = pygame.transform.rotate(base, -a)
        w, h = base.get_size()
        w2, h2 = rot.get_size()
        vx, vy = px_ - w / 2.0, py_ - h / 2.0
        qx = w2 / 2.0 + vx * math.cos(th) + vy * math.sin(th)
        qy = h2 / 2.0 - vx * math.sin(th) + vy * math.cos(th)
        _leg_cache[key] = (rot, int(round(px_ - qx)), int(round(py_ - qy)))
    return _leg_cache[key]


_cache = {}


PAL_G = dict(PAL)
PAL_G.update({
    "K": (30, 20, 44),      # night-violet body
    "B": (104, 76, 142),    # body highlight
    "b": (58, 40, 82),      # body mid
    "D": (9, 6, 14),        # deep shadow
    "G": (22, 18, 36),      # glass
    "g": (118, 104, 150),   # glint
    "S": (176, 172, 190),   # chrome
    "Y": (150, 150, 168),   # silver rim
})
G_TOP = 4                    # the roof starts lower than the others (a low car)


def _build_gt(braking):
    """NOCTURNAL GT: a low, wide night-violet sports car from behind: short cabin, ducktail lip, one long LED tail bar, quad exhausts"""
    g = [["."] * PW for _ in range(PH)]
    cx = PW // 2

    def px(x, y, c):
        if 0 <= x < PW and 0 <= y < PH:
            g[y][x] = c

    def rect(x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                px(x, y, c)
                px(PW - 1 - x, y, c)

    # ---- low cabin: roof, steeply raked rear glass
    rect(9, 5, cx, 5, "b")
    rect(8, 6, cx, 6, "K")
    rect(7, 7, 7, 10, "K")
    rect(8, 7, cx, 10, "G")
    rect(9, 7, 11, 7, "g")
    rect(10, 8, 11, 8, "g")
    rect(8, 11, cx, 11, "D")              # shadow under the glass
    # ---- ducktail lip + rear deck
    rect(3, 11, 7, 11, "K")
    rect(3, 12, cx, 12, "B")              # the lip catches the light
    rect(2, 13, cx, 14, "b")
    rect(2, 15, cx, 15, "K")
    # ---- body flanks, wide haunches
    rect(1, 13, 2, 25, "K")
    rect(1, 13, 1, 15, "b")
    # ---- one long LED tail bar
    rc = "R"
    rect(2, 16, cx, 17, rc)
    rect(2, 18, cx, 18, "r")
    rect(1, 16, 1, 18, "R")               # wraps round the corner
    rect(cx - 3, 16, cx + 3, 17, "D")     # a dark notch for the badge in the middle
    px(cx, 16, "S")
    # ---- bumper, plate, diffuser with fins
    rect(2, 19, cx, 20, "K")
    rect(3, 19, cx, 19, "b")
    rect(2, 21, cx, 25, "K")
    rect(4, 22, cx, 25, "D")
    rect(cx - 4, 19, cx + 4, 22, "W")
    for x in range(cx - 4, cx + 5):
        px(x, 22, "w")
    for x in (cx - 2, cx, cx + 2):
        px(x, 20, "D")
        px(x, 21, "D")
    for x in (5, 8, 11, 14):               # diffuser fins
        rect(x, 23, x, 25, "K")
    # ---- quad exhaust tips
    rect(6, 24, 7, 26, "s")
    rect(6, 25, 7, 26, "S")
    rect(11, 24, 12, 26, "s")
    rect(11, 25, 12, 26, "S")
    px(6, 25, "D"); px(12, 25, "D")
    # ---- wide low tyres with silver rims
    rect(0, 17, 1, 27, "T")
    rect(0, 18, 0, 25, "t")
    rect(2, 25, 3, 27, "T")
    rect(4, 26, 4, 27, "T")
    rect(1, 24, 2, 24, "Y")
    rect(5, 26, cx, 26, "D")
    rect(2, 28, cx, 29, "L")
    rect(0, 27, 1, 28, "L")

    surf = pygame.Surface((PW, PH), pygame.SRCALPHA)
    for y in range(PH):
        for x in range(PW):
            c = g[y][x]
            if c == ".":
                continue
            col = PAL_G[c]
            if braking and c == "R":
                col = BRAKE_RED
            surf.set_at((x, y), (*col, 255))
    return surf


def get(braking=False, scale=2, model=0, lid=0):
    key = (bool(braking), scale, model, lid)
    if key not in _cache:
        s = _build_coffin(braking, lid) if model == 4 else (_build, _build_yuggo, _build_ev, _build_valvo, None, _build_gt)[model](braking)
        _cache[key] = pygame.transform.scale(s, (PW * scale, PH * scale))
    return _cache[key]


if __name__ == "__main__":
    import os
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    pygame.init()
    pygame.display.set_mode((10, 10))
    sheet = pygame.Surface((PW * 8 * 2 + 30, PH * 8 + 20))
    sheet.fill((110, 70, 45))
    sheet.blit(get(False, 8), (10, 10))
    sheet.blit(get(True, 8), (PW * 8 + 20, 10))
    pygame.image.save(sheet, "car_preview.png")
    print("saved car_preview.png")
