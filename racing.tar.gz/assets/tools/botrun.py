"""Headless regression test: a bot drives a whole level and prints how it ended.   python tools/botrun.py 2"""
import os,collections,sys,math
os.environ["SDL_VIDEODRIVER"]="dummy"; os.environ["SDL_AUDIODRIVER"]="dummy"
import pygame
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from game import engine as m
class A:
    def __init__(s): s.calls=collections.Counter(); s.last_hit=""
    def __getattr__(s,n):
        def f(*a,**k): s.calls[n+":"+(a[0] if a and isinstance(a[0],str) else "")]+=1
        return f
a=A(); m.AUDIO=a
lv=int(sys.argv[1]); m.build_world(lv)
def K(**kw):
    d=collections.defaultdict(bool)
    for k,v in kw.items(): d[getattr(pygame,"K_"+k.upper())]=v
    return d
r=m.Run();r.start();r.state="race";f=0
msgs=collections.Counter()
while r.state in ("race","countdown") and f<80000:
    r.speed=min(r.speed+0.01,0.55);r.car_x=350+math.sin(f/70.0)*190;r.bonus_time=max(r.bonus_time,500);r.damage=0
    m.update(r,K()); f+=1
    if r.crash==49: msgs[r.crash_msg]+=1
    if f%7==0: m.draw(r,K(),f)
print("level",lv,"end state",r.state,"pos",int(r.pos),"frames",f,"hits",r.hits)
print(dict(msgs)); print({k:v for k,v in a.calls.items() if "hit" in k or "spook" in k})
