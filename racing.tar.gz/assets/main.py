"""Start the game:  python main.py     (the web build uses the same file)"""
import asyncio
import os
import sys
import time
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


async def boot():
    import pygame
    if sys.platform == "emscripten":
        try:
            pygame.mixer.pre_init(48000, -16, 2, 2048)         # browser: set the sound buffer before anything opens the mixer (reopening it crashes)
        except Exception:
            pass
    pygame.init()
    scr = pygame.display.set_mode((700, 500), pygame.SCALED)              # show something at once: loading the game takes a while in a browser
    scr.fill((10, 8, 20))
    f = pygame.font.Font(None, 44)
    t = f.render("ROAD VANDAL  -  LOADING...", True, (230, 190, 50))
    scr.blit(t, (350 - t.get_width() // 2, 230))
    pygame.display.flip()
    await asyncio.sleep(0.2)
    lines = []

    def note(msg):                                         # progress lines under the title (shows where it stops if something goes wrong)
        print("[boot]", msg)
        lines.append(msg)
        scr.fill((10, 8, 20), (0, 270, 700, 230))
        sm = pygame.font.Font(None, 22)
        for i, l in enumerate(lines[-9:]):
            scr.blit(sm.render(l, True, (150, 150, 170)), (60, 280 + i * 22))
        pygame.display.flip()

    t0 = time.time()
    print("[boot] loading game code...")
    note("loading game code")
    try:
        from game import engine
        note("game code ready in %.1fs" % (time.time() - t0))
        from game import audio
        engine.BOOT[0] = note
        audio.NOTE = note
        await engine.main()
    except SystemExit:
        raise
    except BaseException:                                  # show the real error on screen (the browser only says "Error occurred")
        tb = traceback.format_exc()
        print(tb)
        scr = pygame.display.get_surface()
        scr.fill((20, 0, 0))
        small = pygame.font.Font(None, 20)
        y = 8
        for line in tb.splitlines()[-24:]:
            scr.blit(small.render(line[:110], True, (255, 220, 200)), (8, y))
            y += 19
        pygame.display.flip()
        while True:
            await asyncio.sleep(1)


asyncio.run(boot())
