@echo off
rem Developer mode: Pine Road (level 2) is playable and nothing is sent to the live scoreboard. Does NOT touch the website.
cd /d "%~dp0"
set RV_DEV=1
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" main.py
) else if exist "venv\Scripts\python.exe" (
  "venv\Scripts\python.exe" main.py
) else (
  python main.py
)
echo.
echo (the game closed - if there is an error above, copy it to Claude)
pause
