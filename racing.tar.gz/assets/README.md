# RACING (working title)

Road Rash style pseudo-3D arcade racer in pygame. Heavy car, slippery roads, a clock that only gives you time at checkpoints.

**Levels**
1. PINE ROAD: forest, mountain pass, factory town
2. HALLOWEEN NIGHT: dead hollow, graveyard in the mud and rain, haunted hill in thickening fog. Ghosts, zombie bowling, bats, spiders, a burning ghost train, good witches, a pumpkin-throwing man in black and pumpkin guts on the road

## Run it (Windows)
```
pip install -r requirements.txt
python main.py
```
or double-click `run.bat`.

Controls: UP gas, DOWN brake, LEFT/RIGHT steer, ENTER start, ESC/P pause, F fullscreen, F3 FPS.

## Project layout
```
main.py             start the game
game/engine.py      road, car handling, hazards, HUD, menus
game/levels/        one file per level: zones, events, theme (pure data)
game/config.py      TITLE, version, START_LEVEL
game/audio.py       engine, music, sfx, ghost train whisper
game/sprites.py     all pixel sprites, drawn in code
assets/             music.mp3, engine_loops.wav, ghost_train.wav (put hit_*.wav here too)
tools/botrun.py     headless test: a bot drives a level   (python tools/botrun.py 2)
```

## Add a level
1. Copy `game/levels/halloween.py` to `game/levels/mylevel.py` and change zones, events and theme.
2. Add it to `ORDER` in `game/levels/__init__.py`.
3. Set `locked=True` in its LEVEL dict to keep it out of the level picker until you unlock it.

## Halloween-only edition
Set `START_LEVEL = 2` in `game/config.py`.

## Web / phone (planned)
The engine is already async-ready (`await asyncio.sleep(0)` in the loop). With pygbag:
```
pip install pygbag
pygbag .
```
Still to do: touch controls and a performance pass for phones.

## Licence
Code: MIT (see LICENSE). Music, sounds and character art in `assets/` and `game/master_sprite.py`: all rights reserved, Crith Labs.
